import { createOpenAI } from "@ai-sdk/openai";
import { convertToModelMessages, streamText, type UIMessage } from "ai";
import { createClient } from "@supabase/supabase-js";
import type { Database, Json } from "@/integrations/supabase/types";
import { attachGilbertRunId, createGilbertRunIdFetch } from "./gilbert-run-id.server";

const SYSTEM_PROMPT = `You are GilbertOne, MyThuso's calm patient health guide. Explain health information in plain language, be warm and concise, and suggest appropriate next steps. You are not a doctor and must never diagnose, prescribe, change medication, or claim to replace professional care. For emergencies or severe symptoms, clearly direct the patient to call South African emergency services on 112 or 10177. Encourage contacting their care team when clinical judgment is needed. Never claim access to patient records that were not included in the conversation.`;

function authenticatedClient(request: Request) {
  const url = process.env['SUPABASE_URL'];
  const key = process.env['SUPABASE_PUBLISHABLE_KEY'];
  const authorization = request.headers.get("authorization");
  if (!url || !key) throw new Error("GilbertOne secure storage is unavailable.");
  if (!authorization?.startsWith("Bearer ")) return null;
  return createClient<Database>(url, key, {
    global: { headers: { Authorization: authorization } },
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

export async function handleGilbertChat(request: Request) {
  const supabase = authenticatedClient(request);
  if (!supabase) return Response.json({ message: "Sign in to your patient passport to chat with GilbertOne." }, { status: 401 });
  const { data: claims, error: authError } = await supabase.auth.getClaims(request.headers.get("authorization")?.slice(7));
  const userId = claims?.claims?.sub;
  if (authError || !userId) return Response.json({ message: "Your patient passport session has expired. Please sign in again." }, { status: 401 });

  const body = await request.json() as { messages?: UIMessage[] };
  if (!Array.isArray(body.messages) || body.messages.length === 0 || body.messages.length > 100) {
    return Response.json({ message: "The conversation could not be read." }, { status: 400 });
  }
  const messages = body.messages;
  const userMessage = [...messages].reverse().find((message) => message.role === "user");
  if (!userMessage) return Response.json({ message: "Please enter a message." }, { status: 400 });

  const { error: userSaveError } = await supabase.from("gilbert_chat_messages").upsert({
    user_id: userId,
    ai_message_id: userMessage.id,
    role: "user",
    parts: userMessage.parts as Json,
  }, { onConflict: "user_id,ai_message_id" });
  if (userSaveError) return Response.json({ message: "Your message could not be saved securely." }, { status: 500 });

  const apiKey = process.env['LOVABLE_API_KEY'];
  if (!apiKey) return Response.json({ message: "GilbertOne is not configured yet." }, { status: 503 });
  const runId = createGilbertRunIdFetch(request.headers.get("X-Lovable-AIG-Run-ID") ?? undefined);
  const provider = createOpenAI({
    baseURL: "https://ai.gateway.lovable.dev/v1",
    apiKey,
    headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    fetch: runId.fetch,
  });
  const result = streamText({
    model: provider.responses("openai/gpt-6-astra"),
    system: SYSTEM_PROMPT,
    messages: await convertToModelMessages(messages),
    abortSignal: request.signal,
    providerOptions: { openai: { forceReasoning: true, reasoningEffort: "low", reasoningSummary: "auto", store: false, include: ["reasoning.encrypted_content"] } },
  });
  const response = result.toUIMessageStreamResponse({
    originalMessages: messages,
    sendReasoning: true,
    onFinish: async ({ responseMessage, isAborted }) => {
      if (isAborted) return;
      const { error } = await supabase.from("gilbert_chat_messages").upsert({
        user_id: userId,
        ai_message_id: responseMessage.id,
        role: "assistant",
        parts: responseMessage.parts as Json,
      }, { onConflict: "user_id,ai_message_id" });
      if (error) console.error("GilbertOne assistant message save failed", error.message);
    },
  });
  return attachGilbertRunId(response, runId);
}