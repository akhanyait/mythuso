import { forwardRef } from "react";
import type { HTMLAttributes } from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../lib/utils";
export interface DividerProps extends HTMLAttributes<HTMLHRElement> { orientation?: "horizontal" | "vertical"; }
export const Divider = forwardRef<HTMLHRElement, DividerProps>(({ orientation = "horizontal", className, ...props }, ref) => <hr ref={ref} aria-orientation={orientation} className={cn("shrink-0 border-0 bg-border", orientation === "horizontal" ? "h-px w-full" : "h-full w-px", className)} {...props} />); Divider.displayName = "Divider";
const spinnerVariants = cva("animate-spin rounded-full border-2 border-muted border-t-current", { variants: { size: { sm: "size-4", md: "size-6", lg: "size-8" }, tone: { primary: "text-primary", accent: "text-accent", current: "text-current" } }, defaultVariants: { size: "md", tone: "primary" } });
export interface SpinnerProps extends HTMLAttributes<HTMLSpanElement>, VariantProps<typeof spinnerVariants> { label?: string; }
export const Spinner = forwardRef<HTMLSpanElement, SpinnerProps>(({ size, tone, label = "Loading", className, ...props }, ref) => <span ref={ref} role="status" className={cn(spinnerVariants({ size, tone }), className)} {...props}><span className="sr-only">{label}</span></span>); Spinner.displayName = "Spinner";
