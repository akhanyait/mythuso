import { forwardRef, type SVGProps } from "react";
import { cn } from "../lib/utils";

export interface MyThusoIconProps extends SVGProps<SVGSVGElement> {
  /** Adds a subtle signal animation for live or time-sensitive actions. */
  animated?: boolean;
}

type IconDrawing = (props: MyThusoIconProps) => React.ReactNode;

function createMyThusoIcon(displayName: string, drawing: IconDrawing) {
  const Icon = forwardRef<SVGSVGElement, MyThusoIconProps>(({ animated = false, className, ...props }, ref) => (
    <svg
      ref={ref}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={cn("mythuso-icon", animated && "mythuso-icon--animated", className)}
      aria-hidden={props["aria-label"] ? undefined : true}
      {...props}
    >
      {drawing({ animated })}
    </svg>
  ));
  Icon.displayName = displayName;
  return Icon;
}

const frame = <path d="M4.25 9.2 12 3.4l7.75 5.8v9.05a2 2 0 0 1-2 2H6.25a2 2 0 0 1-2-2V9.2Z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" />;
const signal = <circle className="mythuso-icon__signal fill-highlight stroke-primary" cx="18.6" cy="5.4" r="2.05" strokeWidth="1" />;

export const MyThusoDashboardIcon = createMyThusoIcon("MyThusoDashboardIcon", () => <>{frame}<path className="stroke-accent" d="M8 15.5v-3m4 3V9.8m4 5.7v-4.2" strokeWidth="2" strokeLinecap="round" />{signal}</>);
export const MyThusoHealthIcon = createMyThusoIcon("MyThusoHealthIcon", () => <><path d="M12 20s-7.5-4.2-7.5-10.1A4.35 4.35 0 0 1 12 6.8a4.35 4.35 0 0 1 7.5 3.1C19.5 15.8 12 20 12 20Z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" /><path className="stroke-accent" d="M7.8 12h2.1l1.1-2.3 2 4.7 1.2-2.4h2" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />{signal}</>);
export const MyThusoVisitIcon = createMyThusoIcon("MyThusoVisitIcon", () => <><rect x="4" y="5.5" width="16" height="14" rx="3" stroke="currentColor" strokeWidth="1.8" /><path d="M8 3.8v3.4m8-3.4v3.4M4 9.5h16" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" /><path className="stroke-accent" d="M12 12v4m-2-2h4" strokeWidth="2" strokeLinecap="round" />{signal}</>);
export const MyThusoQuickIcon = createMyThusoIcon("MyThusoQuickIcon", () => <><path d="M13.3 2.8 5.8 13h5l-1 8.2L18.4 10h-5.2l.1-7.2Z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" /><path className="stroke-accent" d="m8.1 16.9-2.2 1.5m10-12.8 2.2-1.5" strokeWidth="1.8" strokeLinecap="round" />{signal}</>);
export const MyThusoResultsIcon = createMyThusoIcon("MyThusoResultsIcon", () => <><path d="M8 3.5h8v5.2l3.2 7.1a3.2 3.2 0 0 1-2.9 4.5H7.7a3.2 3.2 0 0 1-2.9-4.5L8 8.7V3.5Z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" /><path d="M7.1 14.2h9.8" stroke="currentColor" strokeWidth="1.8" /><path className="stroke-accent" d="M9.2 17.1h5.6" strokeWidth="2" strokeLinecap="round" />{signal}</>);
export const MyThusoMedicationIcon = createMyThusoIcon("MyThusoMedicationIcon", () => <><path d="m5.4 11.2 5.8-5.8a4.3 4.3 0 0 1 6.1 6.1l-5.8 5.8a4.3 4.3 0 1 1-6.1-6.1Z" stroke="currentColor" strokeWidth="1.8" /><path d="m8.3 8.3 7.4 7.4" stroke="currentColor" strokeWidth="1.8" /><path className="stroke-accent" d="m6.4 14.8 2.8 2.8" strokeWidth="2" strokeLinecap="round" />{signal}</>);
export const MyThusoMindIcon = createMyThusoIcon("MyThusoMindIcon", () => <><path d="M9.2 19.4H8a3 3 0 0 1-2.7-4.3A3.6 3.6 0 0 1 6.6 8.6a4.2 4.2 0 0 1 8-1.3 3.6 3.6 0 0 1 2.8 6.5 3.2 3.2 0 0 1-2.9 5.6h-1.2" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" /><path className="stroke-accent" d="M9 13.2c1.5 1.5 4.5 1.5 6 0M12 10.8v9.3" strokeWidth="1.8" strokeLinecap="round" />{signal}</>);
export const MyThusoMessagesIcon = createMyThusoIcon("MyThusoMessagesIcon", () => <><path d="M4 6.2A2.2 2.2 0 0 1 6.2 4h11.6A2.2 2.2 0 0 1 20 6.2v8.1a2.2 2.2 0 0 1-2.2 2.2H11l-4.5 3v-3h-.3A2.2 2.2 0 0 1 4 14.3V6.2Z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" /><path className="stroke-accent" d="M8 9.2h8M8 12.5h5" strokeWidth="1.8" strokeLinecap="round" />{signal}</>);
export const MyThusoFamilyIcon = createMyThusoIcon("MyThusoFamilyIcon", () => <><circle cx="9" cy="8" r="3" stroke="currentColor" strokeWidth="1.8" /><circle cx="16.5" cy="9.5" r="2.3" stroke="currentColor" strokeWidth="1.8" /><path d="M3.8 19c.5-3.3 2.3-5.1 5.2-5.1s4.7 1.8 5.2 5.1m-.8-3.4c.8-1.1 1.8-1.6 3.1-1.6 2.1 0 3.4 1.4 3.7 4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" /><path className="stroke-accent" d="M7.2 8h3.6" strokeWidth="1.6" strokeLinecap="round" />{signal}</>);
export const MyThusoSettingsIcon = createMyThusoIcon("MyThusoSettingsIcon", () => <><path d="M12 4.2 13.4 3l2.2 1.3.4 1.8 1.8.7 1.4-1 1.8 1.8-1 1.5.7 1.7 1.8.4v2.6l-1.8.4-.7 1.7 1 1.5-1.8 1.8-1.4-1-1.8.7-.4 1.8h-2.6l-.4-1.8-1.8-.7-1.4 1-1.8-1.8 1-1.5-.7-1.7-1.8-.4v-2.6l1.8-.4.7-1.7-1-1.5 1.8-1.8 1.4 1 1.8-.7.4-1.8H12Z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" /><circle className="stroke-accent" cx="12" cy="12" r="3" strokeWidth="1.8" />{signal}</>);