import { forwardRef } from "react";
import type { HTMLAttributes, ReactNode } from "react";
import { AlertCircle, CheckCircle2, Info, TriangleAlert } from "lucide-react";
import { cn } from "../lib/utils";
const icons = { info: Info, success: CheckCircle2, warning: TriangleAlert, danger: AlertCircle };
export interface AlertProps extends HTMLAttributes<HTMLDivElement> { variant?: keyof typeof icons; title: string; icon?: ReactNode; }
export const Alert = forwardRef<HTMLDivElement, AlertProps>(({ variant = "info", title, icon, children, className, ...props }, ref) => { const Icon = icons[variant]; return <div ref={ref} role={variant === "danger" ? "alert" : "status"} className={cn("flex gap-3 rounded-md border bg-surface p-4", variant === "info" && "border-info/35", variant === "success" && "border-success/35", variant === "warning" && "border-warning/50", variant === "danger" && "border-danger/35", className)} {...props}><span className={cn("mt-0.5", variant === "info" && "text-info", variant === "success" && "text-success", variant === "warning" && "text-warning", variant === "danger" && "text-danger")}>{icon ?? <Icon className="size-5" aria-hidden="true" />}</span><div><p className="text-sm font-semibold text-foreground">{title}</p>{children && <div className="mt-1 text-sm text-muted-foreground">{children}</div>}</div></div>; }); Alert.displayName = "Alert";
