import { forwardRef } from "react";
import type { HTMLAttributes, ImgHTMLAttributes } from "react";
import { cn } from "../lib/utils";
export interface AvatarProps extends HTMLAttributes<HTMLSpanElement> { size?: "sm" | "md" | "lg"; }
export const Avatar = forwardRef<HTMLSpanElement, AvatarProps>(({ size = "md", className, ...props }, ref) => <span ref={ref} className={cn("relative inline-flex shrink-0 overflow-hidden rounded-full bg-muted", size === "sm" && "size-8", size === "md" && "size-10", size === "lg" && "size-12", className)} {...props} />); Avatar.displayName = "Avatar";
export const AvatarImage = forwardRef<HTMLImageElement, ImgHTMLAttributes<HTMLImageElement>>(({ className, alt, ...props }, ref) => <img ref={ref} alt={alt} className={cn("size-full object-cover", className)} {...props} />); AvatarImage.displayName = "AvatarImage";
export interface AvatarFallbackProps extends HTMLAttributes<HTMLSpanElement> { initials: string; }
export const AvatarFallback = forwardRef<HTMLSpanElement, AvatarFallbackProps>(({ initials, className, ...props }, ref) => <span ref={ref} className={cn("flex size-full items-center justify-center bg-primary/10 text-xs font-bold text-primary", className)} {...props}>{initials}</span>); AvatarFallback.displayName = "AvatarFallback";
