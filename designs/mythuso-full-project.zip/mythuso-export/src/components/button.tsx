import { forwardRef } from "react";
import type { ButtonHTMLAttributes, ReactNode } from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { LoaderCircle } from "lucide-react";
import { cn } from "../lib/utils";

export const buttonVariants = cva("inline-flex min-w-0 items-center justify-center gap-2 whitespace-nowrap font-semibold transition-colors focus-visible:outline-none disabled:pointer-events-none disabled:opacity-45", { variants: { variant: { primary: "bg-primary text-primary-foreground hover:bg-primary/90 active:bg-primary/80", accent: "bg-accent text-accent-foreground hover:bg-accent/85 active:bg-accent/75", secondary: "border border-border bg-surface text-foreground hover:bg-muted", ghost: "text-foreground hover:bg-muted", destructive: "bg-danger text-white hover:bg-danger/90" }, size: { sm: "h-8 rounded-sm px-3 text-xs", md: "h-10 rounded-md px-4 text-sm", lg: "h-12 rounded-md px-5 text-base", icon: "size-10 rounded-md p-0" } }, defaultVariants: { variant: "primary", size: "md" } });

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement>, VariantProps<typeof buttonVariants> { loading?: boolean; leadingIcon?: ReactNode; trailingIcon?: ReactNode; }
export const Button = forwardRef<HTMLButtonElement, ButtonProps>(({ className, variant, size, loading = false, leadingIcon, trailingIcon, children, disabled, ...props }, ref) => <button ref={ref} className={cn(buttonVariants({ variant, size }), className)} disabled={disabled || loading} aria-busy={loading || undefined} {...props}>{loading ? <LoaderCircle aria-hidden="true" className="size-4 animate-spin" /> : leadingIcon}{children}{!loading && trailingIcon}</button>);
Button.displayName = "Button";

export interface IconButtonProps extends Omit<ButtonProps, "children" | "size"> { label: string; children: ReactNode; size?: "sm" | "md" | "lg"; }
export const IconButton = forwardRef<HTMLButtonElement, IconButtonProps>(({ label, size = "md", children, className, ...props }, ref) => <Button ref={ref} aria-label={label} title={label} size="icon" className={cn(size === "sm" && "size-8", size === "lg" && "size-12", className)} {...props}>{children}</Button>);
IconButton.displayName = "IconButton";
