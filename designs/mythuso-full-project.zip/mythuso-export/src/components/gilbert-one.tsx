import { forwardRef, type HTMLAttributes } from "react";
import gilbertOneImage from "../assets/illustrations/gilbert-one.png";
import { cn } from "../lib/utils";

export interface GilbertOneProps extends HTMLAttributes<HTMLDivElement> {
  /** Accessible label for informative uses. Pass an empty string when decorative. */
  label?: string;
  /** Controls whether GilbertOne gently turns and blinks. */
  animated?: boolean;
}

export const GilbertOne = forwardRef<HTMLDivElement, GilbertOneProps>(
  ({ className, label = "GilbertOne healthcare assistant", animated = true, ...props }, ref) => (
    <div
      ref={ref}
      className={cn("gilbert-one relative inline-block aspect-[604/764]", animated && "gilbert-one--animated", className)}
      role={label ? "img" : undefined}
      aria-label={label || undefined}
      aria-hidden={label ? undefined : true}
      {...props}
    >
      <img src={gilbertOneImage} alt="" width={604} height={764} className="h-full w-full object-contain" />
      <span className="gilbert-one__face" aria-hidden="true">
        <svg className="gilbert-one__gaze" viewBox="0 0 96 48" focusable="false">
          <g className="gilbert-one__eyes">
            <ellipse cx="28" cy="24" rx="12" ry="8" />
            <ellipse cx="68" cy="24" rx="12" ry="8" />
          </g>
        </svg>
      </span>
    </div>
  ),
);

GilbertOne.displayName = "GilbertOne";