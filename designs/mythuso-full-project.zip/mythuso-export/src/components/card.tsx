import { forwardRef } from "react";
import type { HTMLAttributes, ReactNode } from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../lib/utils";
const cardVariants = cva("border border-border bg-surface", { variants: { variant: { default: "shadow-sm", elevated: "shadow-md", interactive: "shadow-sm transition-colors hover:border-accent" }, padding: { none: "", sm: "p-4", md: "p-5", lg: "p-6" } }, defaultVariants: { variant: "default", padding: "none" } });
export interface CardProps extends HTMLAttributes<HTMLDivElement>, VariantProps<typeof cardVariants> {}
export const Card = forwardRef<HTMLDivElement, CardProps>(({ className, variant, padding, ...props }, ref) => <div ref={ref} className={cn("rounded-lg", cardVariants({ variant, padding }), className)} {...props} />); Card.displayName = "Card";
export const CardHeader = forwardRef<HTMLDivElement, HTMLAttributes<HTMLDivElement>>(({ className, ...props }, ref) => <div ref={ref} className={cn("flex flex-col gap-1 border-b border-border px-5 py-4", className)} {...props} />); CardHeader.displayName = "CardHeader";
export const CardTitle = forwardRef<HTMLHeadingElement, HTMLAttributes<HTMLHeadingElement>>(({ className, ...props }, ref) => <h3 ref={ref} className={cn("font-display text-lg font-semibold text-foreground", className)} {...props} />); CardTitle.displayName = "CardTitle";
export const CardDescription = forwardRef<HTMLParagraphElement, HTMLAttributes<HTMLParagraphElement>>(({ className, ...props }, ref) => <p ref={ref} className={cn("text-sm text-muted-foreground", className)} {...props} />); CardDescription.displayName = "CardDescription";
export const CardContent = forwardRef<HTMLDivElement, HTMLAttributes<HTMLDivElement>>(({ className, ...props }, ref) => <div ref={ref} className={cn("p-5", className)} {...props} />); CardContent.displayName = "CardContent";
export interface MetricCardProps extends Omit<CardProps, "title"> { label: string; value: string; trend?: string; icon?: ReactNode; }
export const MetricCard = forwardRef<HTMLDivElement, MetricCardProps>(({ label, value, trend, icon, className, ...props }, ref) => <Card ref={ref} padding="md" className={cn("min-w-0", className)} {...props}><div className="mb-4 flex items-center justify-between text-muted-foreground"><span className="text-xs font-semibold uppercase">{label}</span>{icon}</div><p className="font-display text-3xl font-semibold text-foreground">{value}</p>{trend && <p className="mt-1 text-xs font-medium text-success">{trend}</p>}</Card>); MetricCard.displayName = "MetricCard";
