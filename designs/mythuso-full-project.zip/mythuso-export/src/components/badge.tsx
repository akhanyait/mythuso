import { forwardRef } from "react";
import type { HTMLAttributes } from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../lib/utils";
const badgeVariants = cva("inline-flex items-center gap-1.5 rounded-full font-semibold", { variants: { variant: { neutral: "bg-muted text-muted-foreground", primary: "bg-primary/10 text-primary", accent: "bg-accent/15 text-foreground", success: "bg-success/15 text-foreground", warning: "bg-warning/20 text-foreground", danger: "bg-danger/12 text-danger" }, size: { sm: "px-2 py-0.5 text-[0.6875rem]", md: "px-2.5 py-1 text-xs" } }, defaultVariants: { variant: "neutral", size: "md" } });
export interface BadgeProps extends HTMLAttributes<HTMLSpanElement>, VariantProps<typeof badgeVariants> { dot?: boolean; }
export const Badge = forwardRef<HTMLSpanElement, BadgeProps>(({ className, variant, size, dot, children, ...props }, ref) => <span ref={ref} className={cn(badgeVariants({ variant, size }), className)} {...props}>{dot && <span aria-hidden="true" className="size-1.5 rounded-full bg-current" />}{children}</span>);
Badge.displayName = "Badge";
export interface StatusIndicatorProps extends HTMLAttributes<HTMLSpanElement> { status?: "online" | "busy" | "offline"; label: string; }
export const StatusIndicator = forwardRef<HTMLSpanElement, StatusIndicatorProps>(({ status = "online", label, className, ...props }, ref) => <span ref={ref} className={cn("inline-flex items-center gap-2 text-sm text-foreground", className)} {...props}><span className={cn("size-2 rounded-full", status === "online" && "bg-success", status === "busy" && "bg-warning", status === "offline" && "bg-muted-foreground")} aria-hidden="true" />{label}</span>);
StatusIndicator.displayName = "StatusIndicator";
