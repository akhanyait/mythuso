import { forwardRef } from "react";
import type { ButtonHTMLAttributes, ReactNode } from "react";
import { ChevronRight } from "lucide-react";
import { cn } from "../lib/utils";
export interface NavigationItemProps extends ButtonHTMLAttributes<HTMLButtonElement> { icon?: ReactNode; active?: boolean; count?: number; }
export const NavigationItem = forwardRef<HTMLButtonElement, NavigationItemProps>(({ icon, active, count, className, children, ...props }, ref) => <button ref={ref} type="button" aria-current={active ? "page" : undefined} className={cn("flex h-10 w-full items-center gap-3 rounded-md px-3 text-left text-sm font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground", active && "bg-accent/15 text-foreground", className)} {...props}>{icon}<span className="min-w-0 flex-1 truncate">{children}</span>{typeof count === "number" ? <span className="rounded-full bg-muted px-1.5 text-xs">{count}</span> : <ChevronRight aria-hidden="true" className="size-4" />}</button>); NavigationItem.displayName = "NavigationItem";
