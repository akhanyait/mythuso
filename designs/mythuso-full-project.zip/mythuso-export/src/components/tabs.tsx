import { forwardRef } from "react";
import type { ButtonHTMLAttributes, HTMLAttributes } from "react";
import { cn } from "../lib/utils";
export const TabsList = forwardRef<HTMLDivElement, HTMLAttributes<HTMLDivElement>>(({ className, ...props }, ref) => <div ref={ref} role="tablist" className={cn("inline-flex items-center gap-1 rounded-md bg-muted p-1", className)} {...props} />); TabsList.displayName = "TabsList";
export interface TabProps extends ButtonHTMLAttributes<HTMLButtonElement> { active?: boolean; }
export const Tab = forwardRef<HTMLButtonElement, TabProps>(({ active, className, children, ...props }, ref) => <button ref={ref} type="button" role="tab" aria-selected={active} className={cn("h-8 rounded-sm px-3 text-sm font-semibold text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none", active && "bg-surface text-foreground shadow-sm", className)} {...props}>{children}</button>); Tab.displayName = "Tab";
