import { Link } from "@tanstack/react-router";
import {
  AlertTriangle, ArrowRight, Bell, BookOpen, Calendar, CalendarDays, ChevronDown, ClipboardList,
  FileText, FlaskConical, HeartPulse, Home, MessageCircle, Pill, Quote, Search, Send, Settings,
  Share2, Stethoscope, Syringe, TestTube2, UserPlus, Users, Activity, NotebookPen,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import nurseImage from "../assets/photography/careline-doctor.jpg";
import mythusoWordmark from "../assets/logos/mythuso-logo.png";
import { Badge, Button, GilbertOne } from "../index";
import { cn } from "../lib/utils";
import { Donut } from "./charts";

type Role = "nurse" | "doctor";
type Nav = { icon: LucideIcon; label: string; count?: number };
type Visit = { time: string; name: string; note: string; room: string; status: "Checked in" | "In room" | "Waiting" | "Scheduled" };

const nav: Record<Role, Nav[]> = {
  nurse: [{ icon: Home, label: "Dashboard" }, { icon: Users, label: "My Patients" }, { icon: CalendarDays, label: "Appointments" }, { icon: ClipboardList, label: "Clinical Tasks", count: 4 }, { icon: Pill, label: "Medications" }, { icon: TestTube2, label: "Test Results" }, { icon: HeartPulse, label: "Care Plans" }, { icon: MessageCircle, label: "Messages", count: 2 }, { icon: Users, label: "Team" }, { icon: BookOpen, label: "Resources" }, { icon: Settings, label: "Settings" }],
  doctor: [{ icon: Home, label: "Dashboard" }, { icon: Calendar, label: "My Schedule" }, { icon: Users, label: "My Patients" }, { icon: Stethoscope, label: "Consultations" }, { icon: Pill, label: "Prescriptions" }, { icon: TestTube2, label: "Test Results" }, { icon: NotebookPen, label: "Clinical Notes" }, { icon: Share2, label: "Referrals" }, { icon: FileText, label: "Reports" }, { icon: MessageCircle, label: "Messages", count: 3 }, { icon: BookOpen, label: "Resources" }, { icon: Settings, label: "Settings" }],
};

const nurseSchedule: Visit[] = [
  { time: "09:00", name: "Thandi M. Molekoa", note: "General consultation", room: "Room 2", status: "Checked in" },
  { time: "09:30", name: "Sipho N. Dlamini", note: "Diabetes follow-up", room: "Room 3", status: "Waiting" },
  { time: "10:00", name: "Lerato K. Maseko", note: "Child vaccination", room: "Room 1", status: "Scheduled" },
  { time: "10:30", name: "Nomvula R. Khumalo", note: "Antenatal visit", room: "Room 4", status: "Scheduled" },
];
const doctorSchedule: Visit[] = [
  { time: "09:00", name: "Thandi M. Molekoa", note: "Follow-up – Hypertension", room: "Room 1", status: "In room" },
  { time: "09:30", name: "Sipho N. Dlamini", note: "Diabetes review", room: "Room 2", status: "Waiting" },
  { time: "10:00", name: "Nomvula R. Khumalo", note: "Antenatal care", room: "Room 3", status: "Scheduled" },
  { time: "10:30", name: "Jacob T. Nkosi", note: "Chest symptoms", room: "Room 1", status: "Scheduled" },
  { time: "11:00", name: "Lerato K. Maseko", note: "Child wellness", room: "Room 4", status: "Scheduled" },
];

const statusTone: Record<Visit["status"], string> = { "Checked in": "bg-success/15 text-success", "In room": "bg-success/15 text-success", Waiting: "bg-warning/30 text-foreground", Scheduled: "bg-primary/10 text-primary" };

function Panel({ title, action = "View all", children, className }: { title: string; action?: string; children: React.ReactNode; className?: string }) {
  return <section className={cn("patient-panel rounded-xl border border-border bg-surface/90 p-5 shadow-sm", className)}><div className="flex items-center justify-between gap-3"><h2 className="font-display text-base font-semibold">{title}</h2>{action && <Button variant="ghost" size="sm" className="px-2 text-primary" trailingIcon={<ArrowRight className="size-3" />}>{action}</Button>}</div>{children}</section>;
}

function Schedule({ visits }: { visits: Visit[] }) {
  return <div className="mt-3 divide-y divide-border">{visits.map((v) => <div key={v.time} className="flex items-center gap-3 py-3"><span className="w-11 text-xs font-bold">{v.time}</span><span className="flex size-8 items-center justify-center rounded-md bg-accent/10 text-accent"><Stethoscope className="size-4" /></span><div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold">{v.name}</p><p className="truncate text-[0.6875rem] text-muted-foreground">{v.note}</p></div><span className="hidden text-xs text-muted-foreground sm:block">{v.room}</span><span className={cn("rounded-full px-2.5 py-1 text-[0.6875rem] font-semibold", statusTone[v.status])}>{v.status}</span></div>)}</div>;
}

function Actions({ items }: { items: [LucideIcon, string][] }) {
  return <div className="mt-3 grid grid-cols-4 gap-2">{items.map(([Icon, label]) => <button key={label} type="button" className="patient-action flex flex-col items-center gap-2 rounded-lg border border-border p-3 text-center text-[0.6875rem] font-semibold"><span className="patient-icon-tile flex size-9 items-center justify-center rounded-md bg-accent/10 text-accent"><Icon className="size-4" /></span><span className="text-[0.6875rem] leading-tight">{label}</span></button>)}</div>;
}

function Legend({ rows }: { rows: [string, string, string][] }) {
  return <ul className="flex-1 space-y-2.5 text-xs">{rows.map(([dot, label, value]) => <li key={label} className="flex items-center gap-2"><span className={cn("size-2.5 rounded-full", dot)} /><span className="flex-1 text-muted-foreground">{label}</span><span className="font-bold">{value}</span></li>)}</ul>;
}

function NurseDashboard() {
  return <div className="space-y-5">
    <section className="patient-panel relative overflow-hidden rounded-xl border border-border bg-surface p-5 sm:p-6"><img src={nurseImage} alt="" className="absolute inset-y-0 right-0 hidden w-1/3 object-cover object-top md:block" /><div className="relative md:max-w-[62%]"><p className="text-sm text-muted-foreground">Good day,</p><h1 className="font-display text-3xl font-semibold sm:text-4xl">Sister Naledi</h1><p className="text-sm text-muted-foreground">Compassion. Care. Community.</p><p className="mt-4 flex gap-2 rounded-lg bg-accent/10 p-3 font-display text-sm italic text-primary"><Quote className="size-4 shrink-0 text-accent" />Every patient interaction is an opportunity to make a difference.</p><h2 className="mt-5 text-sm font-bold">Today's overview</h2><div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-4">{([["24", "Patients today", "bg-accent/10 text-accent"], ["5", "Follow-ups", "bg-primary/10 text-primary"], ["3", "Vaccinations", "bg-highlight/25 text-primary"], ["2", "Alerts", "bg-coral/10 text-coral"]] as const).map(([n, l, t]) => <div key={l} className={cn("rounded-lg p-3", t)}><p className="font-display text-2xl font-semibold">{n}</p><p className="text-[0.6875rem] font-semibold text-foreground">{l}</p></div>)}</div></div></section>
    <div className="grid gap-5 xl:grid-cols-[1.2fr_0.8fr]">
      <Panel title="Today's schedule"><Schedule visits={nurseSchedule} /></Panel>
      <Panel title="Patient flow" action=""><div className="mt-2 flex justify-end"><Badge variant="success"><span className="status-pulse mr-1 inline-block size-1.5 rounded-full bg-success" />Live</Badge></div><div className="mt-2 flex flex-col items-center gap-5 sm:flex-row"><Donut segments={[{ value: 13, tone: "text-accent" }, { value: 20, tone: "text-primary" }, { value: 10, tone: "text-highlight" }, { value: 37, tone: "text-success" }]} center="24 / 30" note="Patients seen" /><Legend rows={[["bg-accent", "Checked in", "4"], ["bg-primary", "In consultation", "6"], ["bg-highlight", "Waiting", "3"], ["bg-success", "Completed", "24"]]} /></div></Panel>
    </div>
    <div className="grid gap-5 xl:grid-cols-[1.2fr_0.8fr]">
      <Panel title="Recent alerts"><div className="mt-3 divide-y divide-border">{([[AlertTriangle, "High BP reading", "Sipho N. Dlamini", "10:15", "bg-coral/10 text-coral"], [CalendarDays, "Missed appointment", "Lerato P. Maseko", "09:40", "bg-warning/30 text-primary"], [ClipboardList, "Follow-up required", "Jacob T. Nkosi", "08:20", "bg-primary/10 text-primary"]] as const).map(([Icon, t, p, time, tone]) => <div key={t} className="flex items-center gap-3 py-3"><span className={cn("flex size-8 items-center justify-center rounded-md", tone)}><Icon className="size-4" /></span><div className="flex-1"><p className="text-sm font-semibold">{t}</p><p className="text-[0.6875rem] text-muted-foreground">{p}</p></div><span className="text-xs text-muted-foreground">{time}</span></div>)}</div></Panel>
      <div className="space-y-5">
        <Panel title="Common actions" action=""><Actions items={[[HeartPulse, "Record vitals"], [Syringe, "Administer vaccine"], [FileText, "Update records"], [Send, "Send message"]]} /></Panel>
        <Panel title="Care quality" action="This week"><div className="mt-3 grid grid-cols-3 gap-2 text-center">{([["98%", 98, "Vitals recorded"], ["95%", 95, "Patient satisfaction"], ["100%", 100, "Immunisations logged"]] as const).map(([l, v, n]) => <div key={n} className="flex flex-col items-center"><Donut size="size-20" segments={[{ value: v, tone: "text-success" }]} center={l} note="" /><p className="mt-1 text-[0.6875rem] text-muted-foreground">{n}</p></div>)}</div></Panel>
      </div>
    </div>
  </div>;
}

function DoctorDashboard() {
  const insights = [["124", "Total consultations", "+12%", "text-success"], ["78%", "Follow-up adherence", "+5%", "text-success"], ["16", "New patients", "+8%", "text-success"], ["4", "Referrals made", "−20%", "text-coral"]] as const;
  return <div className="space-y-5">
    <section className="patient-panel grid gap-4 rounded-xl border border-border bg-surface p-5 sm:p-6 lg:grid-cols-[1fr_auto_1fr] lg:items-center"><div><p className="text-sm text-muted-foreground">Good morning,</p><h1 className="font-display text-3xl font-semibold sm:text-4xl">Dr. Dlamini</h1><p className="text-sm text-muted-foreground">Quality care changes lives.</p></div><div className="rounded-lg border border-border p-4"><p className="text-xs font-semibold">Today · Tue, 24 Jun 2025</p><div className="mt-2 grid grid-cols-4 gap-4 text-center">{[["8", "Consultations"], ["2", "Follow-ups"], ["1", "Procedure"], ["0", "Urgent"]].map(([n, l]) => <div key={l}><p className="font-display text-2xl font-semibold">{n}</p><p className="text-[0.625rem] text-muted-foreground">{l}</p></div>)}</div></div><p className="flex gap-2 rounded-lg bg-accent/10 p-4 font-display text-sm italic text-primary"><Quote className="size-4 shrink-0 text-accent" />Medicine is not just a profession, it's a commitment to people.</p></section>
    <div className="grid gap-5 xl:grid-cols-[1.2fr_0.8fr]">
      <Panel title="Today's consultations"><Schedule visits={doctorSchedule} /></Panel>
      <Panel title="Clinical insights" action="Last 30 days"><div className="mt-3 grid grid-cols-2 gap-3">{insights.map(([n, l, c, t]) => <div key={l} className="health-chart-card rounded-lg border border-border p-3"><div className="flex items-baseline justify-between"><p className="font-display text-2xl font-semibold">{n}</p><span className={cn("text-xs font-bold", t)}>{c}</span></div><p className="text-[0.6875rem] text-muted-foreground">{l}</p></div>)}</div><h3 className="mt-5 text-sm font-bold">Patient demographics</h3><div className="mt-3 flex flex-col items-center gap-5 sm:flex-row"><Donut segments={[{ value: 28, tone: "text-accent" }, { value: 62, tone: "text-primary" }, { value: 10, tone: "text-highlight" }]} center="124" note="Patients" /><Legend rows={[["bg-accent", "Children (0–17)", "28%"], ["bg-primary", "Adults (18–64)", "62%"], ["bg-highlight", "Seniors (65+)", "10%"]]} /></div></Panel>
    </div>
    <div className="grid gap-5 xl:grid-cols-[1.2fr_0.8fr]">
      <Panel title="Recent test results (requiring review)"><div className="mt-3 divide-y divide-border">{([["Abnormal", "Lerato P. Mokoena – HbA1c (8.2%)", "Today", "bg-coral/10 text-coral"], ["Abnormal", "Jacob T. Nkosi – Cholesterol (6.1 mmol/L)", "Yesterday", "bg-coral/10 text-coral"], ["Follow up", "Thandi M. Molekoa – Creatinine (slightly high)", "2 days ago", "bg-primary/10 text-primary"]] as const).map(([s, t, d, tone]) => <div key={t} className="flex items-center gap-3 py-3"><span className={cn("flex items-center gap-1 rounded-full px-2.5 py-1 text-[0.6875rem] font-semibold", tone)}><FlaskConical className="size-3" />{s}</span><p className="flex-1 text-sm">{t}</p><span className="text-xs text-muted-foreground">{d}</span></div>)}</div></Panel>
      <Panel title="Quick actions" action=""><Actions items={[[Pill, "New prescription"], [TestTube2, "Request test"], [UserPlus, "Refer patient"], [Activity, "Clinical note"]]} /></Panel>
    </div>
  </div>;
}

export function ClinicianSpace({ role }: { role: Role }) {
  const profile = role === "nurse" ? { name: "Sister Naledi M.", title: "Registered Nurse", tag: "Caring today. Stronger communities tomorrow." } : { name: "Dr. Ayanda Dlamini", title: "General Practitioner", tag: "Better care. Healthier lives." };
  return <div className="patient-dashboard min-h-screen bg-background"><div className="flex">
    <aside className="sticky top-0 hidden h-screen w-60 shrink-0 flex-col border-r border-border bg-surface lg:flex"><div className="border-b border-border p-5"><Link to="/"><img src={mythusoWordmark} alt="MyThuso — Help. Health. Home." width={1657} height={598} className="h-8 w-auto object-contain" /></Link><p className="mt-1 text-[0.625rem] text-muted-foreground">For a healthier tomorrow.</p></div><nav className="flex-1 space-y-1 overflow-y-auto p-3" aria-label={`${profile.title} navigation`}>{nav[role].map(({ icon: Icon, label, count }, i) => <button key={label} type="button" aria-current={i === 0 ? "page" : undefined} className={cn("patient-nav-item flex h-10 w-full items-center gap-3 rounded-md px-3 text-sm font-medium text-muted-foreground hover:bg-muted hover:text-foreground", i === 0 && "bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground")}><Icon className="size-4" /><span className="flex-1 text-left">{label}</span>{count && <span className="flex size-5 items-center justify-center rounded-full bg-coral text-[0.625rem] font-bold text-primary-foreground">{count}</span>}</button>)}</nav><div className="m-3 rounded-lg bg-accent/10 p-4"><Stethoscope className="size-6 text-accent" /><p className="mt-2 font-display text-sm font-semibold">{profile.tag}</p></div></aside>
    <div className="min-w-0 flex-1"><header className="sticky top-0 z-40 flex items-center gap-3 border-b border-border bg-surface/95 px-4 py-3 backdrop-blur sm:px-6"><Link to="/" className="lg:hidden"><img src={mythusoWordmark} alt="MyThuso — Help. Health. Home." width={1657} height={598} className="h-7 w-auto object-contain" /></Link><div className="relative hidden flex-1 sm:block"><Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" /><input type="search" placeholder="Search for patients, records or health topics..." className="h-10 w-full max-w-xl rounded-md border border-input bg-muted/50 pl-10 pr-4 text-sm" /></div><div className="ml-auto flex items-center gap-3"><Button variant="secondary" size="icon" aria-label="Notifications" className="relative rounded-full"><Bell className="size-4" /><span className="notification-dot absolute right-2 top-2 size-2 rounded-full bg-coral" /></Button><Button variant="secondary" className="h-10 rounded-full py-1 pl-1 pr-3"><img src={nurseImage} alt="" className="size-8 rounded-full object-cover object-top" /><span className="hidden text-left sm:block"><span className="block text-xs font-bold">{profile.name}</span><span className="block text-[0.625rem] text-muted-foreground">{profile.title}</span></span><ChevronDown className="size-3.5 text-muted-foreground" /></Button></div></header>
      <main className="p-4 sm:p-6">{role === "nurse" ? <NurseDashboard /> : <DoctorDashboard />}</main></div>
  </div><div className="fixed bottom-5 right-5 z-50 flex items-end gap-2"><Button className="rounded-full shadow-md" size="sm" leadingIcon={<MessageCircle className="size-4" />}>How can I help you today?</Button><GilbertOne className="h-16 w-12 drop-shadow-lg" label="Chat with GilbertOne" /></div></div>;
}
