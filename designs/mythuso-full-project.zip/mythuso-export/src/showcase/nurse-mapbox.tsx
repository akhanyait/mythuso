import { useEffect, useRef, useState } from "react";
import type { ReactNode } from "react";

export type MapboxPin = { id: string; label: string; name: string; lng: number; lat: number; urgent?: boolean; home?: boolean };

export const mapboxToken: string | undefined =
  import.meta.env.VITE_LOVABLE_CONNECTOR_MAPBOX_PUBLIC_TOKEN || import.meta.env.VITE_MAPBOX_TOKEN;
const TOKEN = mapboxToken;

export const clinicLocation = { lng: 28.0412, lat: -26.1458 };
export const nurseLocation = { lng: 28.0468, lat: -26.1486 };

/**
 * Mapbox GL map for nurse allocations. When a public Mapbox token is present it renders
 * live streets with patient markers; otherwise it shows the supplied schematic fallback.
 */
export function MapboxAllocationMap({ pins, selectedId, onSelect, showRoute, zoomSignal, fallback }: {
  pins: MapboxPin[];
  selectedId: string;
  onSelect: (id: string) => void;
  showRoute: boolean;
  zoomSignal: number;
  fallback: ReactNode;
}) {
  const container = useRef<HTMLDivElement>(null);
  const mapRef = useRef<any>(null);
  const markers = useRef<Record<string, HTMLElement>>({});
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (!TOKEN || !container.current) return;
    let cancelled = false;
    void Promise.all([import("mapbox-gl"), import("mapbox-gl/dist/mapbox-gl.css")]).then(([mod]) => {
      if (cancelled || !container.current) return;
      const mapboxgl = mod.default;
      mapboxgl.accessToken = TOKEN;
      const map = new mapboxgl.Map({ container: container.current, style: "mapbox://styles/mapbox/light-v11", center: [28.046, -26.151], zoom: 13.2, attributionControl: false });
      mapRef.current = map;
      const add = (el: HTMLElement, lng: number, lat: number) => new mapboxgl.Marker({ element: el }).setLngLat([lng, lat]).addTo(map);
      const clinic = document.createElement("div"); clinic.className = "nurse-mapbox-clinic"; clinic.textContent = "+"; add(clinic, clinicLocation.lng, clinicLocation.lat);
      const nurse = document.createElement("div"); nurse.className = "nurse-mapbox-nurse nurse-map-location"; add(nurse, nurseLocation.lng, nurseLocation.lat);
      pins.forEach((pin) => {
        const el = document.createElement("button");
        el.type = "button"; el.textContent = pin.label; el.setAttribute("aria-label", `Show ${pin.name} allocation`);
        el.className = `nurse-mapbox-pin${pin.urgent ? " nurse-mapbox-pin--urgent" : ""}`;
        el.addEventListener("click", () => onSelect(pin.id));
        markers.current[pin.id] = el; add(el, pin.lng, pin.lat);
      });
      map.on("load", () => {
        map.addSource("route", { type: "geojson", data: { type: "Feature", properties: {}, geometry: { type: "LineString", coordinates: [[clinicLocation.lng, clinicLocation.lat], [nurseLocation.lng, nurseLocation.lat], ...pins.map((p) => [p.lng, p.lat])] } } });
        const accent = getComputedStyle(document.documentElement).getPropertyValue("--accent").trim();
        map.addLayer({ id: "route", type: "line", source: "route", paint: { "line-color": accent, "line-width": 4, "line-opacity": 0.85 }, layout: { "line-cap": "round", "line-join": "round" } });
        setReady(true);
      });
    });
    return () => { cancelled = true; mapRef.current?.remove(); mapRef.current = null; markers.current = {}; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    Object.entries(markers.current).forEach(([id, el]) => el.classList.toggle("nurse-mapbox-pin--selected", id === selectedId));
    const pin = pins.find((p) => p.id === selectedId);
    if (pin && mapRef.current) mapRef.current.easeTo({ center: [pin.lng, pin.lat], duration: 700 });
  }, [selectedId, pins]);

  useEffect(() => {
    if (ready && mapRef.current?.getLayer("route")) mapRef.current.setLayoutProperty("route", "visibility", showRoute ? "visible" : "none");
  }, [showRoute, ready]);

  useEffect(() => {
    if (!mapRef.current || zoomSignal === 0) return;
    mapRef.current.zoomTo(mapRef.current.getZoom() + (zoomSignal > 0 ? 1 : -1), { duration: 300 });
  }, [zoomSignal]);

  if (!TOKEN) return <>{fallback}</>;
  return <div ref={container} className="absolute inset-0" aria-label="Allocation map" />;
}

export const hasMapboxToken = Boolean(TOKEN);
