import { cn } from "../lib/utils";

export type Series = { label: string; values: number[]; tone: string; dot: string };

/** Smooth-enough polyline path for a series scaled into a box. */
function toPath(values: number[], min: number, max: number, w: number, h: number, pad = 24) {
  const step = (w - pad * 2) / Math.max(values.length - 1, 1);
  return values.map((v, i) => `${i ? "L" : "M"}${(pad + i * step).toFixed(1)} ${(h - 20 - ((v - min) / (max - min)) * (h - 36)).toFixed(1)}`).join(" ");
}

export function MultiTrendChart({ series, labels, min = 0, max = 200, className }: { series: Series[]; labels: string[]; min?: number; max?: number; className?: string }) {
  const w = 600, h = 200, pad = 24;
  const step = (w - pad * 2) / (labels.length - 1);
  return <div className={className}>
    <div className="mb-2 flex flex-wrap gap-4 text-xs text-muted-foreground">{series.map((s) => <span key={s.label} className="flex items-center gap-1.5"><span className={cn("size-2 rounded-full", s.dot)} />{s.label}</span>)}</div>
    <svg viewBox={`0 0 ${w} ${h}`} className="health-chart h-52 w-full" role="img" aria-label={`Trends for ${series.map((s) => s.label).join(", ")}`}>
      {[0, 0.25, 0.5, 0.75, 1].map((f) => { const y = h - 20 - f * (h - 36); return <g key={f} className="health-chart__labels"><path className="health-chart__grid" d={`M${pad} ${y} H${w - pad}`} /><text x="0" y={y + 2}>{Math.round(min + f * (max - min))}</text></g>; })}
      {series.map((s) => { const d = toPath(s.values, min, max, w, h, pad); return <g key={s.label} className={s.tone}><path className="health-chart__line" d={d} pathLength="1" />{s.values.map((v, i) => <circle key={i} className="health-chart__point" cx={pad + i * step} cy={h - 20 - ((v - min) / (max - min)) * (h - 36)} r="3" />)}</g>; })}
      <g className="health-chart__labels">{labels.map((l, i) => <text key={l} x={pad + i * step - 8} y={h - 4}>{l}</text>)}</g>
    </svg>
  </div>;
}

export function Sparkline({ values, tone }: { values: number[]; tone: string }) {
  const min = Math.min(...values) - 2, max = Math.max(...values) + 2;
  const d = toPath(values, min, max, 120, 56, 4);
  return <svg viewBox="0 0 120 56" className={cn("health-chart h-12 w-24", tone)} aria-hidden="true"><path className="health-chart__area" d={`${d} L116 36 L4 36 Z`} /><path className="health-chart__line" d={d} pathLength="1" /></svg>;
}

export type Segment = { value: number; tone: string };

/** Donut chart; segment values are percentages summing to at most 100. */
export function Donut({ segments, center, note, size = "size-36" }: { segments: Segment[]; center: string; note: string; size?: string }) {
  let offset = 0;
  return <div className={cn("relative shrink-0", size)}>
    <svg viewBox="0 0 42 42" className="h-full w-full" aria-hidden="true">
      <circle className="chart-ring-track" cx="21" cy="21" r="15.9155" strokeWidth="5" />
      {segments.map((s, i) => { const el = <circle key={i} className={cn("chart-ring", s.tone)} cx="21" cy="21" r="15.9155" strokeWidth="5" stroke="currentColor" strokeDasharray={`${Math.max(s.value - 1, 0)} ${101 - s.value}`} strokeDashoffset={-offset} />; offset += s.value; return el; })}
    </svg>
    <div className="absolute inset-0 flex flex-col items-center justify-center text-center"><span className="font-display text-2xl font-semibold leading-none">{center}</span><span className="mt-1 text-[0.625rem] text-muted-foreground">{note}</span></div>
  </div>;
}
