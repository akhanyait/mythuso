import { useState } from "react";
import {
  Activity, AlertTriangle, Building2, Crosshair, List, Map as MapIcon, Minus, Plus, LayoutGrid, Check, Clock, Home, MapPin, Navigation, Route, Stethoscope, Syringe, UserRound,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { Button } from "../index";
import { MapboxAllocationMap, hasMapboxToken } from "./nurse-mapbox";
import { cn } from "../lib/utils";

type PlanRange = "Day" | "Week" | "Month";
type QueueStatus = "Checked in" | "Waiting" | "In care" | "Next" | "Home visit";

type Allocation = {
  id: string;
  lng: number;
  lat: number;
  initials: string;
  name: string;
  time: string;
  wait: string;
  care: string;
  place: string;
  area: string;
  travel: string;
  status: QueueStatus;
  pinClass: string;
  urgent?: boolean;
};

const allocations: Allocation[] = [
  { id: "MT-10234", lng: 28.0418, lat: -26.1452, initials: "TM", name: "Thandi M. Molekoa", time: "09:00", wait: "Checked in 6m ago", care: "Hypertension review", place: "Room 1", area: "Rosebank Clinic", travel: "At clinic", status: "Checked in", pinClass: "nurse-map-pin--one" },
  { id: "MT-10251", lng: 28.0335, lat: -26.1536, initials: "SN", name: "Sipho N. Dlamini", time: "09:30", wait: "Waiting 8m", care: "Diabetes · high BP", place: "Room 2", area: "Parkwood", travel: "7 min", status: "Waiting", pinClass: "nurse-map-pin--two", urgent: true },
  { id: "MT-10288", lng: 28.0445, lat: -26.1628, initials: "LK", name: "Lerato K. Maseko", time: "10:00", wait: "Arriving soon", care: "Child immunisation", place: "Home visit", area: "Saxonwold", travel: "12 min", status: "Home visit", pinClass: "nurse-map-pin--three" },
  { id: "MT-10302", lng: 28.0408, lat: -26.1466, initials: "NK", name: "Nomvula R. Khumalo", time: "10:30", wait: "Scheduled", care: "Antenatal · 28 weeks", place: "Room 4", area: "Rosebank Clinic", travel: "At clinic", status: "Next", pinClass: "nurse-map-pin--four" },
  { id: "MT-10317", lng: 28.0628, lat: -26.1398, initials: "JN", name: "Jacob T. Nkosi", time: "11:15", wait: "Allocated", care: "Asthma follow-up", place: "Home visit", area: "Melrose", travel: "9 min", status: "Home visit", pinClass: "nurse-map-pin--five" },
];

const statusTone: Record<QueueStatus, string> = {
  "Checked in": "bg-success/15 text-success",
  Waiting: "bg-warning/30 text-foreground",
  "In care": "bg-accent/15 text-accent",
  Next: "bg-primary/10 text-primary",
  "Home visit": "bg-coral/10 text-coral",
};

function MapPinButton({ allocation, selected, onSelect }: { allocation: Allocation; selected: boolean; onSelect: () => void }) {
  return <Button
    variant="secondary"
    size="icon"
    aria-label={`Show ${allocation.name} allocation`}
    aria-pressed={selected}
    onClick={onSelect}
    className={cn("nurse-map-pin absolute z-20 size-9 rounded-full border-2 border-surface shadow-md", allocation.pinClass, allocation.urgent ? "bg-coral text-primary-foreground" : "bg-primary text-primary-foreground", selected && "nurse-map-pin--selected")}
  ><span className="text-[0.625rem] font-bold">{allocation.initials}</span></Button>;
}

function SchematicMap({ selected, onSelect, visible, showRoute }: { selected: Allocation; onSelect: (allocation: Allocation) => void; visible: Allocation[]; showRoute: boolean }) {
  return <div className="nurse-map absolute inset-0">
    <div className="nurse-map-road nurse-map-road--one" /><div className="nurse-map-road nurse-map-road--two" /><div className="nurse-map-road nurse-map-road--three" />
    <div className="nurse-map-block nurse-map-block--one" /><div className="nurse-map-block nurse-map-block--two" /><div className="nurse-map-block nurse-map-block--three" /><div className="nurse-map-block nurse-map-block--four" />
    {showRoute && <svg viewBox="0 0 640 400" className="absolute inset-0 size-full" aria-hidden="true"><path d="M112 310 C188 278 190 218 270 225 S372 152 430 188 S514 132 559 84" pathLength="1" className="nurse-map-route" /></svg>}
    <span className="absolute left-[8%] top-[12%] text-[0.625rem] font-semibold text-muted-foreground">Parktown North</span><span className="absolute right-[8%] top-[15%] text-[0.625rem] font-semibold text-muted-foreground">Melrose</span><span className="absolute bottom-[11%] left-[39%] text-[0.625rem] font-semibold text-muted-foreground">Rosebank</span><span className="absolute right-[13%] top-[52%] text-[0.625rem] font-semibold text-muted-foreground">Saxonwold</span>
    <div className="absolute bottom-[18%] left-[14%] z-10 flex size-11 items-center justify-center rounded-lg border-2 border-surface bg-accent text-accent-foreground shadow-md" aria-label="Rosebank Clinic"><Building2 className="size-5" /></div>
    <div className="nurse-map-location absolute bottom-[31%] left-[42%] z-30 flex size-10 items-center justify-center rounded-full border-4 border-surface bg-highlight text-primary shadow-md" aria-label="Nurse S. current position"><Navigation className="size-4" /></div>
    {visible.map((allocation) => <MapPinButton key={allocation.id} allocation={allocation} selected={allocation.id === selected.id} onSelect={() => onSelect(allocation)} />)}
  </div>;
}

type MapMode = "Map" | "List" | "By area";

function AllocationMap({ selected, onSelect, tall }: { selected: Allocation; onSelect: (allocation: Allocation) => void; tall?: boolean }) {
  const [mode, setMode] = useState<MapMode>("Map");
  const [layers, setLayers] = useState({ clinic: true, home: true, urgent: true, route: true });
  const [zoom, setZoom] = useState(0);
  const visible = allocations.filter((a) => (a.urgent ? layers.urgent : a.place === "Home visit" ? layers.home : layers.clinic));
  const areas = [...new Set(allocations.map((a) => a.area))];
  const layerItems = [["clinic", "Clinic patients"], ["home", "Home visits"], ["urgent", "High priority"], ["route", "Show route"]] as const;
  return <div>
    <div className="mb-3 flex flex-wrap items-center gap-2"><div className="flex rounded-lg bg-muted p-1">{([["Map", MapIcon], ["List", List], ["By area", LayoutGrid]] as const).map(([m, I]) => <Button key={m} size="sm" variant={mode === m ? "primary" : "ghost"} aria-pressed={mode === m} onClick={() => setMode(m)}><I className="size-3.5" />{m}</Button>)}</div><span className="ml-auto flex items-center gap-1.5 text-[0.625rem] font-semibold text-muted-foreground"><span className={cn("size-1.5 rounded-full", hasMapboxToken ? "bg-success" : "bg-warning")} />{hasMapboxToken ? "Mapbox live" : "Mapbox ready · preview map"}</span></div>
    {mode === "Map" && <div className={cn("nurse-map-frame relative overflow-hidden rounded-lg border border-border bg-surface-raised", tall ? "min-h-[36rem]" : "min-h-[25rem]")}>
      <MapboxAllocationMap pins={visible.map((a) => ({ id: a.id, label: a.initials, name: a.name, lng: a.lng, lat: a.lat, urgent: a.urgent, home: a.place === "Home visit" }))} selectedId={selected.id} onSelect={(id) => { const a = allocations.find((x) => x.id === id); if (a) onSelect(a); }} showRoute={layers.route} zoomSignal={zoom} fallback={<SchematicMap selected={selected} onSelect={onSelect} visible={visible} showRoute={layers.route} />} />
      <fieldset className="absolute right-3 top-3 z-40 space-y-1.5 rounded-lg border border-border bg-surface/95 p-3 shadow-md backdrop-blur"><legend className="sr-only">Map layers</legend>{layerItems.map(([key, label]) => <label key={key} className="flex cursor-pointer items-center gap-2 text-[0.6875rem] font-semibold"><input type="checkbox" checked={layers[key]} onChange={() => setLayers((l) => ({ ...l, [key]: !l[key] }))} className="size-3.5 accent-[var(--primary)]" />{label}</label>)}</fieldset>
      <div className="absolute bottom-28 right-3 z-40 flex flex-col overflow-hidden rounded-lg border border-border bg-surface shadow-md"><Button size="icon" variant="ghost" aria-label="Centre on my location" onClick={() => onSelect(allocations[0])}><Crosshair className="size-4" /></Button><Button size="icon" variant="ghost" aria-label="Zoom in" onClick={() => setZoom((z) => Math.abs(z) + 1)}><Plus className="size-4" /></Button><Button size="icon" variant="ghost" aria-label="Zoom out" onClick={() => setZoom((z) => -(Math.abs(z) + 1))}><Minus className="size-4" /></Button></div>
      <div key={selected.id} className="nurse-map-card absolute inset-x-3 bottom-3 z-40 rounded-lg border border-border bg-surface/95 p-3 shadow-md backdrop-blur">
        <div className="flex items-start gap-3"><span className={cn("flex size-10 shrink-0 items-center justify-center rounded-full text-xs font-bold", selected.urgent ? "bg-coral/10 text-coral" : "bg-primary/10 text-primary")}>{selected.initials}</span><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><p className="text-sm font-bold">{selected.name}</p>{selected.urgent && <span className="rounded-full bg-coral/10 px-2 py-0.5 text-[0.625rem] font-bold text-coral">Urgent review</span>}</div><p className="truncate text-xs text-muted-foreground">{selected.time} · {selected.care}</p><p className="mt-1 flex flex-wrap gap-x-3 text-[0.6875rem] font-semibold"><span className="flex items-center gap-1"><MapPin className="size-3 text-accent" />{selected.area}</span><span className="flex items-center gap-1"><Route className="size-3 text-accent" />{selected.travel}</span><span>{selected.place}</span></p></div><Button size="sm" variant="secondary">Directions</Button></div>
      </div>
    </div>}
    {mode === "List" && <div className="health-tab-enter space-y-2">{allocations.map((a) => <Button key={a.id} variant="ghost" onClick={() => onSelect(a)} className={cn("nurse-queue-row h-auto w-full justify-start gap-3 rounded-lg border border-border p-3 text-left", selected.id === a.id && "border-accent/40 bg-accent/5")}><span className={cn("flex size-9 shrink-0 items-center justify-center rounded-full text-[0.625rem] font-bold", a.urgent ? "bg-coral text-primary-foreground" : "bg-primary text-primary-foreground")}>{a.initials}</span><span className="min-w-0 flex-1"><span className="block truncate text-xs font-bold">{a.name}</span><span className="block truncate text-[0.6875rem] font-normal text-muted-foreground">{a.time} · {a.care}</span></span><span className="text-[0.6875rem] font-semibold">{a.area} · {a.travel}</span></Button>)}</div>}
    {mode === "By area" && <div className="health-tab-enter grid gap-3 sm:grid-cols-2">{areas.map((area) => { const list = allocations.filter((a) => a.area === area); return <div key={area} className="rounded-lg border border-border p-3"><div className="mb-2 flex items-center justify-between"><p className="flex items-center gap-1.5 text-sm font-bold"><MapPin className="size-3.5 text-accent" />{area}</p><span className="rounded-full bg-muted px-2 py-0.5 text-[0.625rem] font-bold">{list.length}</span></div>{list.map((a) => <button key={a.id} type="button" onClick={() => onSelect(a)} className="flex w-full items-center justify-between rounded-md px-2 py-1.5 text-left text-xs hover:bg-muted"><span className="font-semibold">{a.name}</span><span className="text-muted-foreground">{a.time}</span></button>)}</div>; })}</div>}
  </div>;
}

export function NurseMapView() {
  const [selected, setSelected] = useState(allocations[1]);
  return <section className="nurse-command space-y-5"><div><p className="text-xs font-bold uppercase text-accent">Map view</p><h1 className="font-display text-3xl font-semibold">Patient allocations map</h1><p className="text-sm text-muted-foreground">Clinic base, home visits, your route and every allocated patient.</p></div><div className="grid gap-5 xl:grid-cols-[1fr_20rem]"><div className="nurse-map-panel rounded-xl border border-border bg-surface p-5 shadow-sm"><AllocationMap selected={selected} onSelect={setSelected} tall /></div><div className="rounded-xl border border-border bg-surface p-5 shadow-sm"><h2 className="font-display text-lg font-semibold">Today’s route</h2><p className="mb-3 text-xs text-muted-foreground">5 stops · 28 min travel</p><QueueBoard selected={selected} onSelect={setSelected} /></div></div></section>;
}

function QueueBoard({ selected, onSelect }: { selected: Allocation; onSelect: (allocation: Allocation) => void }) {
  const stages = [["Checked in", 2, "bg-success"], ["Waiting", 3, "bg-warning"], ["In care", 1, "bg-accent"], ["Completed", 7, "bg-primary"]] as const;
  return <div>
    <div className="grid grid-cols-4 gap-2">{stages.map(([label, count, tone]) => <div key={label} className="rounded-lg bg-muted/60 p-2.5 text-center"><span className={cn("mx-auto mb-2 block h-1.5 w-8 rounded-full", tone)} /><p className="font-display text-xl font-semibold">{count}</p><p className="text-[0.625rem] text-muted-foreground">{label}</p></div>)}</div>
    <div className="relative mt-4 space-y-2 before:absolute before:bottom-5 before:left-[1.125rem] before:top-5 before:w-px before:bg-border">{allocations.slice(0, 4).map((allocation, index) => <Button key={allocation.id} variant="ghost" onClick={() => onSelect(allocation)} className={cn("nurse-queue-row relative z-10 h-auto w-full justify-start gap-3 rounded-lg border border-transparent p-2.5 text-left", selected.id === allocation.id && "border-accent/40 bg-accent/5")}><span className={cn("flex size-9 shrink-0 items-center justify-center rounded-full border-2 border-surface text-[0.625rem] font-bold", allocation.urgent ? "bg-coral text-primary-foreground" : "bg-muted text-primary")}>{index + 1}</span><span className="min-w-0 flex-1"><span className="flex items-center justify-between gap-2"><span className="truncate text-xs font-bold">{allocation.time} · {allocation.name}</span><span className={cn("shrink-0 rounded-full px-2 py-0.5 text-[0.5625rem] font-bold", statusTone[allocation.status])}>{allocation.status}</span></span><span className="mt-0.5 block truncate text-[0.6875rem] font-normal text-muted-foreground">{allocation.care} · {allocation.wait}</span></span></Button>)}</div>
    <div className="mt-4"><div className="mb-1.5 flex items-center justify-between text-[0.6875rem]"><span className="text-muted-foreground">Shift queue progress</span><span className="font-bold">7 of 13 completed</span></div><div className="h-2 overflow-hidden rounded-full bg-muted"><div className="nurse-queue-progress h-full rounded-full bg-accent" /></div></div>
  </div>;
}

const dayPlan: [string, string, string, LucideIcon][] = [
  ["08:00", "Shift handover", "Night notes reviewed · Rosebank Clinic", Check],
  ["09:00", "Clinic consultations", "Thandi, Sipho and Nomvula · Rooms 1–4", Stethoscope],
  ["10:45", "Travel to Saxonwold", "12 minutes · route optimised", Navigation],
  ["11:00", "Child immunisation", "Lerato K. Maseko · home visit", Syringe],
  ["12:15", "Break and documentation", "30 minutes · 2 notes outstanding", Clock],
  ["13:00", "Community care round", "2 home visits · Melrose", Home],
];

function PlanTimeline({ range, selected }: { range: PlanRange; selected: Allocation }) {
  if (range === "Day") return <div className="relative space-y-1 before:absolute before:bottom-5 before:left-[1.125rem] before:top-5 before:w-px before:bg-border">{dayPlan.map(([time, title, note, Icon]) => { const active = title.includes(selected.name.split(" ")[0]) || (selected.place === "Home visit" && title.includes("home")); return <div key={`${time}-${title}`} className={cn("nurse-plan-row relative grid grid-cols-[2.25rem_minmax(0,1fr)] gap-3 rounded-lg p-2", active && "bg-accent/10")}><span className={cn("z-10 flex size-9 items-center justify-center rounded-full border border-border bg-surface", active ? "text-accent" : "text-muted-foreground")}><Icon className="size-4" /></span><div><p className="text-[0.625rem] font-bold text-primary">{time}</p><p className="text-xs font-bold">{title}</p><p className="text-[0.6875rem] text-muted-foreground">{note}</p></div></div>; })}</div>;
  if (range === "Week") return <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">{[["Mon", "8 visits", "3 home"], ["Tue", "11 visits", "Clinic"], ["Wed", "6 visits", "2 follow-ups"], ["Thu", "12 visits", "High load"], ["Fri", "7 visits", "4 home"]].map(([day, count, note], index) => <div key={day} className={cn("rounded-lg border border-border p-3", index === 0 && "border-accent/40 bg-accent/5")}><p className="text-[0.625rem] font-bold text-muted-foreground">{day}</p><p className="mt-2 text-sm font-bold">{count}</p><p className="text-[0.625rem] text-muted-foreground">{note}</p><div className="mt-3 h-16 overflow-hidden rounded bg-muted"><div className={cn("nurse-workload-bar mt-auto w-full bg-primary", ["h-3/5", "h-4/5", "h-1/2", "h-full", "h-2/3"][index])} /></div></div>)}</div>;
  return <div className="grid grid-cols-7 gap-1">{Array.from({ length: 30 }, (_, index) => { const day = index + 1; const campaign = [4, 11, 18, 25].includes(day); const homeRound = [2, 9, 16, 23, 30].includes(day); return <div key={day} className={cn("min-h-14 rounded-md border border-border p-1.5", day === 28 && "border-accent bg-accent/10")}><p className="text-[0.625rem] font-bold">{day}</p>{campaign && <span className="mt-1 block h-1.5 rounded-full bg-primary" />}{homeRound && <span className="mt-1 block h-1.5 rounded-full bg-coral" />}</div>; })}<div className="col-span-7 mt-2 flex flex-wrap gap-3 text-[0.625rem] text-muted-foreground"><span className="flex items-center gap-1"><span className="size-2 rounded-full bg-primary" />Vaccination drive</span><span className="flex items-center gap-1"><span className="size-2 rounded-full bg-coral" />Community round</span></div></div>;
}

export function NurseOperationsBoard() {
  const [selected, setSelected] = useState(allocations[1]);
  const [range, setRange] = useState<PlanRange>("Day");
  return <section className="space-y-5" aria-label="Nurse allocation and planning">
    <div className="flex flex-wrap items-end justify-between gap-3"><div><p className="text-xs font-bold uppercase text-accent">Today’s operations</p><h2 className="font-display text-2xl font-semibold">Patient schedule & allocations</h2><p className="text-xs text-muted-foreground">Select any patient to link their queue position, care plan and location.</p></div><div className="grid grid-cols-4 gap-2 rounded-lg border border-border bg-surface p-2 text-center shadow-sm"><div><p className="font-display text-lg font-semibold">13</p><p className="text-[0.5625rem] text-muted-foreground">Assigned</p></div><div><p className="font-display text-lg font-semibold">7</p><p className="text-[0.5625rem] text-muted-foreground">Complete</p></div><div><p className="font-display text-lg font-semibold">5</p><p className="text-[0.5625rem] text-muted-foreground">Remaining</p></div><div><p className="font-display text-lg font-semibold">28m</p><p className="text-[0.5625rem] text-muted-foreground">Travel</p></div></div></div>
    <div className="grid gap-5 xl:grid-cols-[0.78fr_1.22fr]"><div className="rounded-xl border border-border bg-surface p-5 shadow-sm"><div className="mb-4 flex items-center justify-between"><div><h3 className="font-display text-lg font-semibold">Today’s schedule</h3><p className="text-xs text-muted-foreground">Live patient queue and care status.</p></div><span className="flex items-center gap-1.5 rounded-full bg-success/10 px-2.5 py-1 text-[0.625rem] font-bold text-success"><span className="status-pulse size-1.5 rounded-full bg-success" />Live</span></div><QueueBoard selected={selected} onSelect={setSelected} /></div><div className="nurse-map-panel rounded-xl border border-border bg-surface p-5 shadow-sm"><div className="mb-4 flex flex-wrap items-center justify-between gap-3"><div><h3 className="font-display text-lg font-semibold">Patient allocations</h3><p className="text-xs text-muted-foreground">Clinic base, home visits, route and patient locations.</p></div><div className="flex flex-wrap gap-3 text-[0.625rem] font-semibold text-muted-foreground"><span className="flex items-center gap-1"><MapPin className="size-3 text-primary" />Clinic patient</span><span className="flex items-center gap-1"><Home className="size-3 text-coral" />Home visit</span><span className="flex items-center gap-1"><Navigation className="size-3 text-accent" />Nurse</span></div></div><AllocationMap selected={selected} onSelect={setSelected} /></div></div>
    <div className="grid gap-5 xl:grid-cols-[1.35fr_0.65fr]"><div className="rounded-xl border border-border bg-surface p-5 shadow-sm"><div className="mb-5 flex flex-wrap items-center justify-between gap-3"><div><h3 className="font-display text-lg font-semibold">Care plan</h3><p className="text-xs text-muted-foreground">Travel, visits, follow-ups and community rounds.</p></div><div className="flex rounded-lg bg-muted p-1">{(["Day", "Week", "Month"] as PlanRange[]).map((item) => <Button key={item} size="sm" variant={range === item ? "primary" : "ghost"} onClick={() => setRange(item)} aria-pressed={range === item}>{item}</Button>)}</div></div><PlanTimeline range={range} selected={selected} /></div><div className="rounded-xl border border-border bg-surface p-5 shadow-sm"><div className="flex items-center justify-between"><div><h3 className="font-display text-lg font-semibold">Allocation health</h3><p className="text-xs text-muted-foreground">Capacity and changes today.</p></div><Activity className="size-5 text-accent" /></div><div className="mt-5 space-y-3">{[["Route coverage", "82%", "w-[82%]", "bg-accent"], ["Visit capacity", "68%", "w-[68%]", "bg-primary"], ["Notes complete", "54%", "w-[54%]", "bg-coral"]].map(([label, value, width, tone]) => <div key={label}><div className="mb-1 flex justify-between text-xs"><span className="text-muted-foreground">{label}</span><span className="font-bold">{value}</span></div><div className="h-2 overflow-hidden rounded-full bg-muted"><div className={cn("nurse-allocation-progress h-full rounded-full", width, tone)} /></div></div>)}</div><div className="mt-5 rounded-lg bg-warning/20 p-3"><div className="flex gap-2"><AlertTriangle className="mt-0.5 size-4 shrink-0 text-primary" /><div><p className="text-xs font-bold">1 allocation needs review</p><p className="text-[0.6875rem] text-muted-foreground">Sipho’s elevated reading may change the 10:45 departure.</p></div></div><Button size="sm" variant="secondary" className="mt-3 w-full">Reassign visit</Button></div><div className="mt-4 flex items-center gap-3 rounded-lg border border-border p-3"><span className="flex size-9 items-center justify-center rounded-full bg-accent/10 text-accent"><UserRound className="size-4" /></span><div><p className="text-xs font-bold">Nurse S. Sithole</p><p className="text-[0.625rem] text-muted-foreground">5 remaining · 2 home visits</p></div></div></div></div>
  </section>;
}