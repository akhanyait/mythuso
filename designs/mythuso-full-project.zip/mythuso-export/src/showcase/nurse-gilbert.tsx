import { useEffect, useRef, useState } from "react";
import { AlertTriangle, BookOpen, ClipboardList, Copy, FileText, HeartHandshake, LockKeyhole, Minus, Paperclip, Pill, Send, ShieldCheck, Sparkles, ThumbsDown, ThumbsUp, X } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { Button, GilbertOne } from "@/index";
import { cn } from "@/lib/utils";

type Msg = { id: number; from: "nurse" | "gilbert"; text: string; source?: string; followUps?: string[]; note?: boolean };

const topics: [LucideIcon, string, string, string][] = [
  [ClipboardList, "Clinical Guidelines", "Latest protocols", "Find a clinical guideline for hypertension"],
  [Pill, "Medication Info", "Doses, interactions", "What is the adult dose for amlodipine?"],
  [HeartHandshake, "Patient Care", "Assessments, education", "How do I prepare a patient for a blood test?"],
  [FileText, "Documentation", "Help with notes", "Help me write a note for a follow-up visit for a diabetic patient."],
  [ShieldCheck, "Infection Control", "Best practices", "Summarise hand hygiene moments"],
  [BookOpen, "Professional Support", "Policies, procedures", "Find a training resource on CPD"],
];

function reply(q: string): Omit<Msg, "id" | "from"> {
  const t = q.toLowerCase();
  if (t.includes("amlodipine")) return { text: "For adults, the usual starting dose of amlodipine is 5 mg once daily.\n\nThe dose may be increased to 10 mg once daily depending on the patient's response and blood pressure control.\n\nAlways follow your facility's protocol and consult a prescriber if unsure.", source: "South African STG, 2023", followUps: ["Show contraindications", "Common side effects", "Patient education notes"] };
  if (t.includes("blood test")) return { text: "Key steps to prepare a patient for a blood test:\n\n1. Confirm the test and any fasting requirements.\n2. Explain the procedure to the patient.\n3. Ensure correct patient identification.\n4. Use appropriate equipment and follow infection control procedures.\n5. Label samples correctly and send to the laboratory.\n6. Advise the patient when and how they will receive results.\n\nWould you like a patient information leaflet to share?", followUps: ["Yes, show leaflet", "More preparation tips", "Related guidelines"] };
  if (t.includes("note") || t.includes("document")) return { note: true, text: "Follow-up Visit Note\nDate: 12 March 2025\nPatient: [Name / ID]\nReason for Visit: Diabetes follow-up\nSubjective: Patient reports better glucose control. No new symptoms.\nObjective: BP 128/78 mmHg, HbA1c 7.2% (previously 7.8%).\nPlan: Continue current medication. Reinforce diet and exercise. Next review in 3 months.\n\nPlease review and edit as needed.", followUps: ["Copy note", "Add to EMR (if available)", "Make changes"] };
  if (t.includes("contraindication")) return { text: "Amlodipine should be avoided in cardiogenic shock, severe aortic stenosis and unstable angina. Use caution in hepatic impairment. Confirm with the prescriber before administering.", source: "South African STG, 2023" };
  if (t.includes("side effect")) return { text: "Common side effects include ankle swelling, flushing, headache, dizziness and fatigue. Advise patients to report persistent swelling or palpitations." };
  return { text: "Here's what I found in trusted guidance. I've summarised the key points — please verify against your facility's protocol before acting.", source: "National Clinical Guidelines", followUps: ["Summarise this guideline", "Check a medication", "Help with a patient note"] };
}

export function NurseGilbert() {
  const [open, setOpen] = useState(false);
  const [minimized, setMinimized] = useState(false);
  const [accepted, setAccepted] = useState(false);
  const [checks, setChecks] = useState([false, false]);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [draft, setDraft] = useState("");
  const [thinking, setThinking] = useState(false);
  const end = useRef<HTMLDivElement>(null);
  useEffect(() => { end.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, thinking]);

  const ask = (text: string) => {
    const q = text.trim(); if (!q || thinking) return;
    setMessages((m) => [...m, { id: Date.now(), from: "nurse", text: q }]); setDraft(""); setThinking(true);
    window.setTimeout(() => { setMessages((m) => [...m, { id: Date.now() + 1, from: "gilbert", ...reply(q) }]); setThinking(false); }, 700);
  };

  if (!open || minimized) return <div className="fixed bottom-5 right-5 z-50 flex items-end gap-2"><Button className="rounded-full shadow-md" size="sm" onClick={() => { setOpen(true); setMinimized(false); }}>{minimized ? "Still have questions?" : "Chat with GilbertOne"}</Button><button type="button" onClick={() => { setOpen(true); setMinimized(false); }} aria-label="Open GilbertOne"><GilbertOne className="h-16 w-12 drop-shadow-lg" label="" /></button></div>;

  return <aside role="dialog" aria-label="GilbertOne for nurses" className="fixed inset-x-3 bottom-3 top-16 z-50 flex flex-col overflow-hidden rounded-xl border border-border bg-surface shadow-lg sm:inset-x-auto sm:right-5 sm:w-[25rem]">
    <header className="flex items-center gap-3 border-b border-border px-4 py-3"><GilbertOne className="h-10 w-8" label="" /><div className="flex-1"><p className="font-display text-sm font-semibold">GilbertOne</p><p className="flex items-center gap-1 text-[0.6875rem] text-success"><span className="size-1.5 rounded-full bg-success" />Online · Nurse mode</p></div><Button variant="ghost" size="icon" aria-label="Minimise" onClick={() => setMinimized(true)}><Minus className="size-4" /></Button><Button variant="ghost" size="icon" aria-label="Close" onClick={() => setOpen(false)}><X className="size-4" /></Button></header>
    {!accepted ? <div className="flex-1 space-y-4 overflow-y-auto p-5 text-sm">
      <h2 className="font-display text-lg font-semibold">Before you continue</h2><p className="text-xs text-muted-foreground">Please read and acknowledge this information before starting your chat with GilbertOne.</p>
      <div className="rounded-lg border border-danger/30 bg-danger/10 p-3 text-xs text-danger"><p className="flex items-center gap-2 font-bold"><AlertTriangle className="size-4" />If it might be an emergency</p><p className="mt-1">Call 10177, 112 or go to your nearest hospital.</p></div>
      <div className="text-xs text-muted-foreground"><p className="flex items-center gap-2 font-bold text-foreground"><LockKeyhole className="size-4" />Privacy and professional use</p><p className="mt-1">GilbertOne supports nurses with trusted information. Always verify and follow your facility's protocols. Do not enter identifiable patient information unless permitted.</p></div>
      <div className="text-xs"><p className="flex items-center gap-2 font-bold"><ShieldCheck className="size-4" />What GilbertOne will not do</p><ul className="mt-1 list-disc space-y-1 pl-9 text-muted-foreground"><li>Never replaces clinical judgement.</li><li>Never gives a diagnosis.</li><li>Never prescribes or changes medication.</li><li>Never provides patient-specific treatment plans.</li><li>Never handles emergencies.</li></ul></div>
      {["I understand GilbertOne is not a doctor.", "I will always follow my facility's protocols."].map((l, i) => <label key={l} className="flex items-center gap-2 text-xs"><input type="checkbox" checked={checks[i]} onChange={(e) => setChecks((c) => c.map((v, j) => (j === i ? e.target.checked : v)))} className="size-4 accent-primary" />{l}</label>)}
      <div className="flex gap-2"><Button variant="secondary" onClick={() => setOpen(false)}>Cancel</Button><Button className="flex-1" disabled={!checks.every(Boolean)} onClick={() => setAccepted(true)}>I Accept and Continue</Button></div>
    </div> : <>
      <div className="flex-1 space-y-4 overflow-y-auto bg-background/50 p-4">
        {messages.length === 0 && <div className="text-center"><GilbertOne className="mx-auto h-24 w-20" label="" /><p className="mt-2 font-display text-xl font-semibold text-primary">Hello, Nurse S.</p><p className="text-sm">How can I help you today?</p><p className="text-xs text-muted-foreground">Choose a common topic or type your question.</p><div className="mt-4 grid grid-cols-2 gap-2 text-left">{topics.map(([Icon, t, n, q]) => <button key={t} type="button" onClick={() => ask(q)} className="patient-action rounded-lg border border-border bg-surface p-3"><Icon className="size-5 text-accent" /><p className="mt-1 text-xs font-bold text-primary">{t}</p><p className="text-[0.625rem] text-muted-foreground">{n}</p></button>)}</div></div>}
        {messages.map((m) => m.from === "nurse" ? <p key={m.id} className="ml-auto max-w-[85%] rounded-lg bg-primary/10 p-3 text-xs text-primary">{m.text}</p> : <div key={m.id} className="flex gap-2"><GilbertOne className="h-9 w-7 shrink-0" label="" /><div className="min-w-0 flex-1 space-y-2"><div className={cn("whitespace-pre-line rounded-lg border border-border bg-surface p-3 text-xs leading-relaxed", m.note && "font-mono text-[0.6875rem]")}>{m.text}{m.source && <p className="mt-2 flex w-fit items-center gap-1 rounded bg-muted px-2 py-1 text-[0.625rem] text-muted-foreground"><Sparkles className="size-3" />Source: {m.source}</p>}</div><div className="flex gap-1"><Button variant="ghost" size="icon" className="size-7" aria-label="Helpful"><ThumbsUp className="size-3.5" /></Button><Button variant="ghost" size="icon" className="size-7" aria-label="Not helpful"><ThumbsDown className="size-3.5" /></Button>{m.note && <Button variant="ghost" size="sm" leadingIcon={<Copy className="size-3" />} onClick={() => void navigator.clipboard?.writeText(m.text)}>Copy</Button>}</div>{m.followUps && <div className="flex flex-wrap gap-1.5">{m.followUps.map((f) => <Button key={f} variant="secondary" size="sm" onClick={() => ask(f)}>{f}</Button>)}</div>}</div></div>)}
        {thinking && <p className="text-xs text-muted-foreground">GilbertOne is thinking…</p>}
        <div ref={end} />
      </div>
      <form className="flex items-center gap-2 border-t border-border p-3" onSubmit={(e) => { e.preventDefault(); ask(draft); }}><Paperclip className="size-4 text-muted-foreground" /><input value={draft} onChange={(e) => setDraft(e.target.value)} placeholder="Type your message…" aria-label="Message GilbertOne" className="h-10 flex-1 rounded-md border border-input bg-background px-3 text-sm" /><Button type="submit" size="icon" className="rounded-full" aria-label="Send" disabled={!draft.trim()}><Send className="size-4" /></Button></form>
    </>}
  </aside>;
}
