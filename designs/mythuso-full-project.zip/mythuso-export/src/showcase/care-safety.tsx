import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { QRCodeSVG } from "qrcode.react";
import { CartesianGrid, Line, LineChart, ReferenceArea, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import {
  Activity, AlertTriangle, BellRing, Car, Check, CheckCircle2, Clock3, Fingerprint, Flag, HeartPulse, KeyRound,
  MapPin, Navigation, Phone, QrCode, ScanFace, ShieldAlert, ShieldCheck, Siren, Smartphone, Stethoscope, Thermometer,
  UserRound, Users, Video, X, Droplet, Wind,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { Badge, Button, Input, Select, Textarea } from "../index";
import { cn } from "../lib/utils";
import {
  PROXIMITY_KM, allocationFor, checkIn, deviceTriage, dispatchClinician, distanceKm, flagArea, historyFor, livePatients, news2,
  patientById, project, sendPanic, setPanicStatus, setVirtual, severityOf, updateAlarm, useLive, visitRule, vitalMeta, zoneById, zones,
} from "./care-live";
import type { Alarm, Severity, VitalKey, ZoneRisk } from "./care-live";
import { mapboxToken } from "./nurse-mapbox";

const vitalIcons: Record<VitalKey, LucideIcon> = { hr: HeartPulse, sys: Activity, spo2: Wind, glucose: Droplet, temp: Thermometer };
const vitalColor: Record<VitalKey, string> = { hr: "var(--coral)", sys: "var(--primary)", spo2: "var(--info)", glucose: "var(--accent)", temp: "var(--warning)" };
const sevTone: Record<Severity, "warning" | "danger"> = { watch: "warning", urgent: "danger", critical: "danger" };
const riskTone: Record<ZoneRisk, "success" | "warning" | "danger"> = { safe: "success", caution: "warning", high: "danger" };
const riskLabel: Record<ZoneRisk, string> = { safe: "Safe", caution: "Caution", high: "High risk" };
const fmtTime = (t: number) => new Date(t).toLocaleTimeString("en-ZA", { hour: "2-digit", minute: "2-digit" });

function Card({ title, note, action, children, className }: { title?: string; note?: string; action?: React.ReactNode; children: React.ReactNode; className?: string }) {
  return <section className={cn("doctor-panel rounded-xl border border-border bg-surface p-5 shadow-sm", className)}>{(title || action) && <div className="mb-4 flex flex-wrap items-start justify-between gap-3"><div>{title && <h2 className="font-display text-lg font-semibold">{title}</h2>}{note && <p className="mt-0.5 text-xs text-muted-foreground">{note}</p>}</div>{action}</div>}{children}</section>;
}
function Heading({ icon: Icon, eyebrow, title, note, action }: { icon: LucideIcon; eyebrow: string; title: string; note: string; action?: React.ReactNode }) {
  return <div className="flex flex-wrap items-end justify-between gap-4"><div className="flex items-start gap-3"><span className="flex size-10 items-center justify-center rounded-lg bg-accent/10 text-accent"><Icon className="size-5" /></span><div><p className="text-[0.625rem] font-bold uppercase text-accent">{eyebrow}</p><h1 className="font-display text-3xl font-semibold">{title}</h1><p className="mt-1 text-sm text-muted-foreground">{note}</p></div></div>{action}</div>;
}
export function PreviewNote({ children }: { children: React.ReactNode }) {
  return <p className="flex items-start gap-2 rounded-lg border border-info/30 bg-info/10 p-3 text-xs"><ShieldCheck className="mt-0.5 size-4 shrink-0 text-info" />{children}</p>;
}
function LiveDot() { return <span className="relative flex size-2"><span className="notification-dot absolute inline-flex size-full rounded-full bg-success" /><span className="relative inline-flex size-2 rounded-full bg-success" /></span>; }

/* ---------------- Live vitals ---------------- */
export function LiveVitalTiles({ patientId }: { patientId: string }) {
  const { live } = useLive();
  const p = patientById(patientId);
  const series = live[patientId]; const r = series[series.length - 1]; const prev = series[series.length - 2] ?? r;
  const device = p.battery < 15 ? { label: "Battery critical — reconnect device", tone: "danger" as const } : p.battery < 30 ? { label: "Low battery", tone: "warning" as const } : { label: "Connected & syncing", tone: "success" as const };
  return <div>
    <div className="mb-3 flex flex-wrap items-center gap-x-4 gap-y-1.5 rounded-lg border border-border bg-muted/30 px-3 py-2 text-xs">
      <span className="flex items-center gap-1.5 font-bold"><Smartphone className="size-3.5 text-accent" />{p.device}</span>
      <Badge size="sm" variant={device.tone}><LiveDot /> {device.label}</Badge>
      <span className="text-muted-foreground">Battery {p.battery}%</span>
      <span className="text-muted-foreground">Last reading just now · live feed</span>
    </div>
    <div className="grid grid-cols-2 gap-3 md:grid-cols-5">{(Object.keys(vitalMeta) as VitalKey[]).map((k) => {
    const Icon = vitalIcons[k]; const sev = severityOf(k, r[k]); const delta = +(r[k] - prev[k]).toFixed(1);
    return <div key={k} className={cn("doctor-metric rounded-lg border p-3 transition-colors", sev === "critical" || sev === "urgent" ? "border-danger/50 bg-danger/10" : sev === "watch" ? "border-warning/50 bg-warning/10" : "border-border bg-muted/30")}>
      <div className="flex items-center justify-between"><Icon className="size-4" style={{ color: vitalColor[k] }} />{sev ? <Badge size="sm" variant={sevTone[sev]}>{sev}</Badge> : <LiveDot />}</div>
      <p className="mt-2 font-display text-2xl font-semibold tabular-nums">{k === "sys" ? `${r.sys}/${r.dia}` : r[k]}<span className="ml-1 text-xs font-normal text-muted-foreground">{vitalMeta[k].unit}</span></p>
      <p className="text-[0.6875rem] text-muted-foreground">{vitalMeta[k].label} · <span className={delta > 0 ? "text-coral" : "text-success"}>{delta > 0 ? "+" : ""}{delta}</span></p>
    </div>;
  })}</div></div>;
}

export function InteractiveVitalsChart({ patientId }: { patientId: string }) {
  const { live } = useLive();
  const [range, setRange] = useState<"live" | "24h" | "7d" | "30d">("live");
  const [shown, setShown] = useState<VitalKey[]>(["sys", "hr"]);
  const [band, setBand] = useState<VitalKey>("sys");
  const p = patientById(patientId);
  const data = useMemo(() => {
    const src = range === "live" ? live[patientId] : range === "24h" ? historyFor(p, 24, 60) : range === "7d" ? historyFor(p, 28, 360) : historyFor(p, 30, 1440);
    return src.map((d) => ({ ...d, label: range === "7d" || range === "30d" ? new Date(d.t).toLocaleDateString("en-ZA", { day: "numeric", month: "short" }) : new Date(d.t).toLocaleTimeString("en-ZA", { hour: "2-digit", minute: "2-digit", second: range === "live" ? "2-digit" : undefined }) }));
  }, [range, live, patientId, p]);
  return <div>
    <div className="mb-3 flex flex-wrap items-center gap-2">
      <div className="flex rounded-lg bg-muted p-1" role="group" aria-label="Time range">{(["live", "24h", "7d", "30d"] as const).map((r) => <button key={r} type="button" onClick={() => setRange(r)} className={cn("rounded-md px-3 py-1 text-xs font-semibold", range === r ? "bg-surface shadow-sm" : "text-muted-foreground")}>{r === "live" ? "Live" : r}</button>)}</div>
      <div className="flex flex-wrap gap-1.5">{(Object.keys(vitalMeta) as VitalKey[]).map((k) => <button key={k} type="button" aria-pressed={shown.includes(k)} onClick={() => setShown((s) => (s.includes(k) ? s.filter((x) => x !== k) : [...s, k]))} className={cn("flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[0.6875rem] font-semibold", shown.includes(k) ? "border-foreground/30 bg-surface" : "border-border text-muted-foreground opacity-60")}><span className="size-2 rounded-full" style={{ background: vitalColor[k] }} />{vitalMeta[k].label}</button>)}</div>
      <label className="ml-auto flex items-center gap-2 text-[0.6875rem] text-muted-foreground">Target band<Select value={band} onChange={(e) => setBand(e.currentTarget.value as VitalKey)} className="h-8 w-36 text-xs">{(Object.keys(vitalMeta) as VitalKey[]).map((k) => <option key={k} value={k}>{vitalMeta[k].label}</option>)}</Select></label>
    </div>
    <div className="h-72"><ResponsiveContainer width="100%" height="100%"><LineChart data={data} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
      <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
      <XAxis dataKey="label" tick={{ fontSize: 10 }} minTickGap={24} />
      <YAxis tick={{ fontSize: 10 }} domain={["auto", "auto"]} />
      <ReferenceArea y1={vitalMeta[band].band[0]} y2={vitalMeta[band].band[1]} fill="var(--success)" fillOpacity={0.08} />
      <Tooltip contentStyle={{ borderRadius: 8, fontSize: 12, border: "1px solid var(--border)", background: "var(--surface)" }} />
      {shown.map((k) => <Line key={k} type="monotone" dataKey={k} name={vitalMeta[k].label} stroke={vitalColor[k]} strokeWidth={2} dot={false} isAnimationActive={range !== "live"} />)}
    </LineChart></ResponsiveContainer></div>
    <p className="mt-2 text-[0.6875rem] text-muted-foreground">Shaded band shows the target range for {vitalMeta[band].label.toLowerCase()}. Live updates every few seconds from {p.device}.</p>
  </div>;
}

/* ---------------- Alarms ---------------- */
const responses = [
  { key: "call", label: "Call patient", icon: Phone },
  { key: "virtual", label: "Start virtual consult", icon: Video },
  { key: "visit", label: "Dispatch visit", icon: Car },
  { key: "escalate", label: "Escalate to doctor", icon: Stethoscope },
  { key: "ems", label: "Call emergency services", icon: Siren },
];
export function AlarmBanner({ role }: { role: "Doctor" | "Nurse" }) {
  const { alarms } = useLive(); const open = alarms.filter((a) => a.status === "open");
  if (!open.length) return null;
  const a = open[0]; const p = patientById(a.patientId);
  return <div role="alert" className="doctor-case-panel flex flex-wrap items-center gap-3 rounded-xl border border-danger/40 bg-danger/10 p-3">
    <span className="notification-dot flex size-9 items-center justify-center rounded-full bg-danger text-primary-foreground"><BellRing className="size-4" /></span>
    <div className="min-w-0 flex-1"><p className="text-sm font-bold">{open.length} device alarm{open.length > 1 ? "s" : ""} need a response</p><p className="text-xs">{p.name}: {vitalMeta[a.vital].label} {a.value} {vitalMeta[a.vital].unit} · {a.severity}</p></div>
    <Link to={role === "Doctor" ? "/doctor/triage" : "/nurse/alarms"} className="rounded-md bg-danger px-3 py-2 text-xs font-bold text-primary-foreground">Open alarm centre</Link>
  </div>;
}

export function AlarmCentre({ role, actor }: { role: "Doctor" | "Nurse"; actor: string }) {
  const { alarms } = useLive();
  const [filter, setFilter] = useState<"active" | "resolved">("active");
  const list = alarms.filter((a) => (filter === "active" ? a.status !== "resolved" : a.status === "resolved"));
  const [selected, setSelected] = useState<string | null>(null);
  const current = alarms.find((a) => a.id === selected) ?? list[0];
  return <Card title="Alarm centre" note="Shared live between doctors and nurses" action={<div className="flex rounded-lg bg-muted p-1">{(["active", "resolved"] as const).map((f) => <button key={f} type="button" onClick={() => setFilter(f)} className={cn("rounded-md px-3 py-1 text-xs font-semibold capitalize", filter === f ? "bg-surface shadow-sm" : "text-muted-foreground")}>{f} ({alarms.filter((a) => (f === "active" ? a.status !== "resolved" : a.status === "resolved")).length})</button>)}</div>}>
    <div className="grid gap-4 lg:grid-cols-[18rem_1fr]">
      <div className="max-h-[28rem] space-y-2 overflow-y-auto pr-1">{list.length === 0 && <p className="rounded-lg bg-muted p-4 text-center text-xs text-muted-foreground">No {filter} alarms.</p>}{list.map((a) => { const p = patientById(a.patientId); return <button key={a.id} type="button" onClick={() => setSelected(a.id)} className={cn("doctor-queue-row w-full rounded-lg border p-3 text-left", current?.id === a.id ? "border-accent bg-accent/10" : "border-border")}><div className="flex items-center justify-between gap-2"><span className="text-xs font-bold">{p.name}</span><Badge size="sm" variant={sevTone[a.severity]}>{a.severity}</Badge></div><p className="mt-1 text-[0.6875rem] text-muted-foreground">{vitalMeta[a.vital].label} {a.value} {vitalMeta[a.vital].unit} · {fmtTime(a.raisedAt)}</p><p className="mt-1 text-[0.625rem] font-semibold uppercase text-muted-foreground">{a.status}{a.assignedTo ? ` · ${a.assignedTo}` : ""}</p></button>; })}</div>
      {current ? <AlarmDetail alarm={current} role={role} actor={actor} /> : <div className="rounded-lg bg-muted/40 p-6 text-sm text-muted-foreground">Select an alarm to respond.</div>}
    </div>
  </Card>;
}

function AlarmDetail({ alarm, role, actor }: { alarm: Alarm; role: "Doctor" | "Nurse"; actor: string }) {
  const p = patientById(alarm.patientId); const zone = zoneById(p.zone); const rule = visitRule(zone.risk);
  const now = Date.now();
  const act = (key: string, label: string) => {
    if (key === "visit" && !rule.canTravel) return;
    updateAlarm(alarm.id, { status: "responding", response: label, assignedTo: actor }, { at: now, who: actor, text: `${label}${key === "visit" ? ` (${rule.needs.toLowerCase()})` : ""}` });
  };
  return <div className="space-y-4">
    <div className="flex flex-wrap items-center gap-3"><div className="flex-1"><p className="text-[0.625rem] font-bold uppercase text-muted-foreground">{alarm.id} · {p.id}</p><h3 className="font-display text-xl font-semibold">{p.name}</h3><p className="text-xs text-muted-foreground">{p.condition} · {p.device} · battery {p.battery}%</p></div><Badge variant={riskTone[zone.risk]}><MapPin className="size-3" />{zone.name}: {riskLabel[zone.risk]}</Badge></div>
    <LiveVitalTiles patientId={p.id} />
    <div><p className="mb-2 text-xs font-bold">Recommended response for a {alarm.severity} {vitalMeta[alarm.vital].label.toLowerCase()} alarm</p>
      <ol className="mb-3 space-y-1 text-xs text-muted-foreground"><li>1. Confirm the reading with the patient (re-measure if possible).</li><li>2. {alarm.severity === "critical" ? "If symptomatic, call emergency services now." : "Start a virtual consult to assess symptoms."}</li><li>3. {role === "Nurse" ? "Escalate to the on-call doctor with the device trend." : "Record your triage decision and plan."}</li></ol>
      <div className="flex flex-wrap gap-2">{responses.filter((r) => !(role === "Doctor" && r.key === "escalate")).map((r) => { const blocked = r.key === "visit" && !rule.canTravel; return <Button key={r.key} size="sm" variant={r.key === "ems" ? "destructive" : "secondary"} disabled={blocked || alarm.status === "resolved"} onClick={() => act(r.key, r.label)} leadingIcon={<r.icon className="size-3.5" />} title={blocked ? rule.needs : undefined}>{r.label}</Button>; })}</div>
      {!rule.canTravel && <p className="mt-2 flex items-center gap-1.5 text-[0.6875rem] text-danger"><ShieldAlert className="size-3.5" />{zone.name} is high risk — respond virtually only.</p>}
    </div>
    <div className="flex flex-wrap gap-2 border-t border-border pt-3">
      <Button size="sm" variant="secondary" disabled={alarm.status !== "open"} onClick={() => updateAlarm(alarm.id, { status: "acknowledged", assignedTo: actor }, { at: now, who: actor, text: "Acknowledged the alarm" })} leadingIcon={<Check className="size-3.5" />}>Acknowledge</Button>
      <Button size="sm" disabled={alarm.status === "resolved"} onClick={() => updateAlarm(alarm.id, { status: "resolved" }, { at: now, who: actor, text: "Resolved — patient stable" })} leadingIcon={<CheckCircle2 className="size-3.5" />}>Resolve</Button>
    </div>
    <div><p className="mb-2 text-xs font-bold">Timeline</p><ol className="space-y-2 border-l border-border pl-4">{alarm.events.map((e, i) => <li key={i} className="relative text-xs"><span className="absolute -left-[1.3rem] top-1 size-2 rounded-full bg-accent" /><span className="font-semibold">{fmtTime(e.at)} · {e.who}</span><span className="block text-muted-foreground">{e.text}</span></li>)}</ol></div>
  </div>;
}

/* ---------------- Triage (device / nurse / doctor) ---------------- */
export function TriageLayers({ patientId, role }: { patientId: string; role: "Doctor" | "Nurse" }) {
  const { live } = useLive(); const r = live[patientId][live[patientId].length - 1]; const dev = deviceTriage(r);
  const [nurse, setNurse] = useState({ level: "Orange", notes: "Patient reports mild headache, no chest pain. Re-measured BP after 5 min rest.", by: "Sister Naledi Mokoena", at: "15:52" });
  const [doc, setDoc] = useState<{ level: string; reason: string; plan: string; signed?: string }>({ level: "", reason: "", plan: "" });
  const [nurseDraft, setNurseDraft] = useState({ level: "Orange", notes: "" });
  const [error, setError] = useState("");
  const levels = ["Red", "Orange", "Yellow", "Green"];
  const levelTone = (l: string) => (l === "Red" || l === "Orange" ? "danger" : l === "Yellow" ? "warning" : "success") as "danger" | "warning" | "success";
  return <div className="grid gap-3 lg:grid-cols-3">
    <div className="rounded-lg border border-border p-4"><p className="flex items-center gap-2 text-xs font-bold"><Smartphone className="size-4 text-accent" />1 · Device auto-triage</p><div className="mt-3 flex items-center gap-2"><Badge variant={dev.tone}>{dev.level}</Badge><span className="text-sm font-semibold">{dev.label}</span><LiveDot /></div><p className="mt-2 text-[0.6875rem] text-muted-foreground">Calculated live from the latest device reading at {fmtTime(r.t)}.</p></div>
    <div className="rounded-lg border border-border p-4"><p className="flex items-center gap-2 text-xs font-bold"><UserRound className="size-4 text-accent" />2 · Nurse triage</p><div className="mt-3 flex items-center gap-2"><Badge variant={levelTone(nurse.level)}>{nurse.level}</Badge><span className="text-xs text-muted-foreground">{nurse.by} · {nurse.at}</span></div><p className="mt-2 text-xs">{nurse.notes}</p>
      {role === "Nurse" && <form className="mt-3 space-y-2 border-t border-border pt-3" onSubmit={(e) => { e.preventDefault(); if (!nurseDraft.notes.trim()) return; setNurse({ level: nurseDraft.level, notes: nurseDraft.notes.trim().slice(0, 500), by: "You", at: fmtTime(Date.now()) }); setNurseDraft({ level: nurseDraft.level, notes: "" }); }}><Select aria-label="Nurse triage level" value={nurseDraft.level} onChange={(e) => setNurseDraft({ ...nurseDraft, level: e.currentTarget.value })}>{levels.map((l) => <option key={l}>{l}</option>)}</Select><Textarea aria-label="Nurse triage notes" maxLength={500} rows={2} placeholder="Symptoms, re-measurement, observations" value={nurseDraft.notes} onChange={(e) => setNurseDraft({ ...nurseDraft, notes: e.currentTarget.value })} /><Button size="sm" type="submit">Record nurse triage</Button></form>}
    </div>
    <div className="rounded-lg border border-accent/40 bg-accent/5 p-4"><p className="flex items-center gap-2 text-xs font-bold"><Stethoscope className="size-4 text-accent" />3 · Doctor triage</p>
      {doc.signed ? <><div className="mt-3 flex items-center gap-2"><Badge variant={levelTone(doc.level)}>{doc.level}</Badge><span className="text-xs text-muted-foreground">Signed {doc.signed}</span></div><p className="mt-2 text-xs"><b>Reason:</b> {doc.reason}</p><p className="mt-1 text-xs"><b>Plan:</b> {doc.plan}</p></>
        : role === "Doctor" ? <form className="mt-3 space-y-2" onSubmit={(e) => { e.preventDefault(); if (!doc.level || doc.reason.trim().length < 10) { setError("Choose a level and give a reason of at least 10 characters."); return; } setError(""); setDoc({ ...doc, reason: doc.reason.trim().slice(0, 500), plan: doc.plan.trim().slice(0, 500) || "Review in 24 hours", signed: `${fmtTime(Date.now())} · Dr Ayanda Dlamini` }); }}>
          <Select aria-label="Doctor triage level" value={doc.level} onChange={(e) => setDoc({ ...doc, level: e.currentTarget.value })}><option value="">Choose acuity</option>{levels.map((l) => <option key={l}>{l}</option>)}</Select>
          <Textarea aria-label="Reason" rows={2} maxLength={500} placeholder="Clinical reason (required)" value={doc.reason} onChange={(e) => setDoc({ ...doc, reason: e.currentTarget.value })} />
          <Input aria-label="Plan" maxLength={500} placeholder="Plan, e.g. adjust medication, visit, refer" value={doc.plan} onChange={(e) => setDoc({ ...doc, plan: e.currentTarget.value })} />
          {error && <p className="text-[0.6875rem] text-danger">{error}</p>}
          <Button size="sm" type="submit" leadingIcon={<Fingerprint className="size-3.5" />}>Sign doctor triage</Button></form>
        : <p className="mt-3 text-xs text-muted-foreground">Awaiting doctor review. The nurse can escalate from the alarm centre.</p>}
    </div>
  </div>;
}

export function DeviceVsNurse({ patientId }: { patientId: string }) {
  const { live } = useLive(); const r = live[patientId][live[patientId].length - 1];
  const nurse = { hr: r.hr - 3, sys: r.sys - 6, spo2: r.spo2, glucose: +(r.glucose - 0.3).toFixed(1), temp: r.temp };
  return <table className="w-full text-xs"><thead><tr className="text-left text-[0.625rem] uppercase text-muted-foreground"><th className="py-2">Vital</th><th>Device (live)</th><th>Nurse (15:52)</th><th>Difference</th></tr></thead><tbody>{(Object.keys(vitalMeta) as VitalKey[]).map((k) => { const d = +(r[k] - nurse[k]).toFixed(1); return <tr key={k} className="border-t border-border"><td className="py-2 font-semibold">{vitalMeta[k].label}</td><td className="tabular-nums">{r[k]} {vitalMeta[k].unit}</td><td className="tabular-nums">{nurse[k]} {vitalMeta[k].unit}</td><td><Badge size="sm" variant={Math.abs(d) > 5 ? "warning" : "success"}>{d > 0 ? "+" : ""}{d}</Badge></td></tr>; })}</tbody></table>;
}

function News2Calculator({ patientId }: { patientId: string }) {
  const { live } = useLive(); const r = live[patientId][live[patientId].length - 1];
  const [rr, setRr] = useState(18); const [alert, setAlert] = useState(true); const [o2, setO2] = useState(false);
  const score = news2({ rr, spo2: r.spo2, sys: r.sys, hr: r.hr, temp: r.temp, alert, o2 });
  const band = score >= 7 ? ["High", "danger", "Emergency response"] : score >= 5 ? ["Medium", "warning", "Urgent clinical review"] : ["Low", "success", "Continue routine monitoring"];
  return <div className="space-y-3"><div className="flex items-center gap-4"><div className="flex size-20 items-center justify-center rounded-full border-4 font-display text-3xl font-bold" style={{ borderColor: `var(--${band[1]})` }}>{score}</div><div><Badge variant={band[1] as "danger"}>{band[0]} risk</Badge><p className="mt-1 text-xs">{band[2]}</p><p className="text-[0.625rem] text-muted-foreground">Uses live SpO2, BP, HR and temperature.</p></div></div>
    <label className="block text-xs font-semibold">Respiratory rate: {rr}/min<input type="range" min={6} max={32} value={rr} onChange={(e) => setRr(+e.currentTarget.value)} className="mt-1 w-full accent-[var(--accent)]" /></label>
    <div className="flex gap-4 text-xs"><label className="flex items-center gap-2"><input type="checkbox" checked={alert} onChange={(e) => setAlert(e.currentTarget.checked)} />Alert (ACVPU)</label><label className="flex items-center gap-2"><input type="checkbox" checked={o2} onChange={(e) => setO2(e.currentTarget.checked)} />On oxygen</label></div>
    <p className="text-[0.625rem] text-muted-foreground">Decision support only — the doctor makes the clinical decision.</p></div>;
}

function RiskHeatmap({ onPick }: { onPick: (id: string) => void }) {
  const { live } = useLive();
  return <div className="overflow-x-auto"><table className="w-full text-xs"><thead><tr className="text-[0.625rem] uppercase text-muted-foreground"><th className="py-1 text-left">Patient</th>{(Object.keys(vitalMeta) as VitalKey[]).map((k) => <th key={k}>{vitalMeta[k].label}</th>)}</tr></thead><tbody>{livePatients.map((p) => { const r = live[p.id][live[p.id].length - 1]; return <tr key={p.id} className="cursor-pointer hover:bg-muted/40" onClick={() => onPick(p.id)}><td className="py-1.5 pr-2 font-semibold">{p.name.split(" ")[0]}</td>{(Object.keys(vitalMeta) as VitalKey[]).map((k) => { const s = severityOf(k, r[k]); return <td key={k} className="p-0.5"><div className={cn("rounded px-1.5 py-1 text-center tabular-nums transition-colors", s === "critical" ? "bg-danger text-primary-foreground" : s === "urgent" ? "bg-danger/40" : s === "watch" ? "bg-warning/40" : "bg-success/15")}>{r[k]}</div></td>; })}</tr>; })}</tbody></table></div>;
}

function WhatChanged({ patientId }: { patientId: string }) {
  const { live } = useLive(); const s = live[patientId]; const first = s[0]; const last = s[s.length - 1];
  return <ul className="space-y-2">{(Object.keys(vitalMeta) as VitalKey[]).map((k) => { const d = +(last[k] - first[k]).toFixed(1); const pct = first[k] ? Math.round((d / first[k]) * 100) : 0; return <li key={k} className="flex items-center justify-between text-xs"><span>{vitalMeta[k].label}</span><span className={cn("font-semibold tabular-nums", Math.abs(pct) >= 8 ? "text-coral" : "text-muted-foreground")}>{d > 0 ? "▲" : d < 0 ? "▼" : "•"} {Math.abs(d)} {vitalMeta[k].unit} ({pct}%)</span></li>; })}</ul>;
}

function MedicationOverlay() {
  const doses = [["07:00", "Amlodipine 5 mg", true], ["13:00", "Metformin 500 mg", true], ["19:00", "Amlodipine 5 mg", false]] as const;
  return <ul className="space-y-2">{doses.map(([t, m, taken]) => <li key={t + m} className="flex items-center gap-2 text-xs"><span className="w-12 font-semibold tabular-nums">{t}</span><span className="flex-1">{m}</span><Badge size="sm" variant={taken ? "success" : "warning"}>{taken ? "Taken (smart box)" : "Due"}</Badge></li>)}<li className="text-[0.625rem] text-muted-foreground">BP rose 40 min after a missed dose on 26 Sep.</li></ul>;
}

export function DoctorTriagePage() {
  const [patientId, setPatientId] = useState("MT-10234");
  const p = patientById(patientId); const zone = zoneById(p.zone);
  return <div className="doctor-page space-y-5">
    <Heading icon={HeartPulse} eyebrow="Doctor workspace" title="Live triage & monitoring" note="Real-time device readings, three-layer triage and alarms across your patients." action={<Badge variant="success"><LiveDot /> Live feed</Badge>} />
    <PreviewNote>Preview: readings are simulated every few seconds. Real device feeds connect later through the code engine.</PreviewNote>
    <div className="flex gap-2 overflow-x-auto pb-1">{livePatients.map((x) => <button key={x.id} type="button" onClick={() => setPatientId(x.id)} className={cn("shrink-0 rounded-full border px-3 py-1.5 text-xs font-semibold", x.id === patientId ? "border-primary bg-primary text-primary-foreground" : "border-border bg-surface")}>{x.name}</button>)}</div>
    <Card title={p.name} note={`${p.condition} · ${p.age} yrs · ${p.device}`} action={<Badge variant={riskTone[zone.risk]}><MapPin className="size-3" />{zone.name}: {riskLabel[zone.risk]} · {visitRule(zone.risk).mode}</Badge>}><LiveVitalTiles patientId={patientId} /></Card>
    <Card title="Interactive vitals trend" note="Toggle vitals, change range, hover for exact values"><InteractiveVitalsChart patientId={patientId} /></Card>
    <Card title="Triage" note="Device, nurse and doctor assessments side by side"><TriageLayers patientId={patientId} role="Doctor" /></Card>
    <div className="grid gap-5 xl:grid-cols-3">
      <Card title="Early warning score" note="NEWS2-style calculator"><News2Calculator patientId={patientId} /></Card>
      <Card title="What changed" note="Since the start of this session"><WhatChanged patientId={patientId} /></Card>
      <Card title="Medication vs readings" note="Smart pill box adherence"><MedicationOverlay /></Card>
    </div>
    <div className="grid gap-5 xl:grid-cols-2">
      <Card title="Device vs nurse readings" note="Spot measurement drift"><DeviceVsNurse patientId={patientId} /></Card>
      <Card title="Patient risk heatmap" note="Tap a row to open that patient"><RiskHeatmap onPick={setPatientId} /></Card>
    </div>
    <AlarmCentre role="Doctor" actor="Dr Ayanda Dlamini" />
    <FieldAllocation patientId={patientId} actorRole="Doctor" />
  </div>;
}

export function NurseAlarmsPage() {
  const [patientId, setPatientId] = useState("MT-10251");
  const p = patientById(patientId);
  return <div className="space-y-5">
    <Heading icon={BellRing} eyebrow="Nurse workspace" title="Alarms & live readings" note="Device alarms, triage results and how to respond — shared with the doctor in real time." action={<Badge variant="success"><LiveDot /> Live feed</Badge>} />
    <PreviewNote>Preview: readings, alarms and area risk are simulated. Police risk data and live GPS connect later through the code engine.</PreviewNote>
    <AlarmCentre role="Nurse" actor="Sister Naledi Mokoena" />
    <div className="flex gap-2 overflow-x-auto pb-1">{livePatients.map((x) => <button key={x.id} type="button" onClick={() => setPatientId(x.id)} className={cn("shrink-0 rounded-full border px-3 py-1.5 text-xs font-semibold", x.id === patientId ? "border-primary bg-primary text-primary-foreground" : "border-border bg-surface")}>{x.name}</button>)}</div>
    <Card title={`${p.name} — device readings`} note={`${p.device} · battery ${p.battery}%`}><LiveVitalTiles patientId={patientId} /><div className="mt-4"><InteractiveVitalsChart patientId={patientId} /></div></Card>
    <Card title="Triage results" note="Device result, your triage and the doctor's decision"><TriageLayers patientId={patientId} role="Nurse" /></Card>
    <FieldAllocation patientId={patientId} actorRole="Nurse" />
    <div className="grid gap-5 xl:grid-cols-2"><FieldSafety clinicianId="N-01" /><FlagRiskArea by="Sister Naledi Mokoena" /></div>
  </div>;
}

/* ---------------- Safety map: real Mapbox streets with schematic fallback ---------------- */
export function SafetyMap({ highlight, height = "h-80" }: { highlight?: string; height?: string }) {
  return <div className={cn("relative overflow-hidden rounded-lg border border-border bg-muted/30", height)}>
    {mapboxToken ? <MapboxSafetyMap highlight={highlight} /> : <SchematicSafetyMap highlight={highlight} />}
    <div className="pointer-events-none absolute bottom-2 left-2 z-10 flex flex-wrap gap-2 rounded-md bg-surface/90 p-2 text-[0.5625rem] font-semibold">{(["safe", "caution", "high"] as ZoneRisk[]).map((r) => <span key={r} className="flex items-center gap-1"><span className={cn("size-2 rounded-full", r === "safe" ? "bg-success" : r === "caution" ? "bg-warning" : "bg-danger")} />{riskLabel[r]}</span>)}<span className="text-muted-foreground">{mapboxToken ? "Live Mapbox map · demo safety data" : "Source: police reports (integration pending)"}</span></div>
  </div>;
}

function MapboxSafetyMap({ highlight }: { highlight?: string }) {
  const { clinicians, panics } = useLive();
  const container = useRef<HTMLDivElement>(null);
  const mapRef = useRef<any>(null);
  const glRef = useRef<any>(null);
  const patientEls = useRef<Record<string, HTMLElement>>({});
  const clinicianMarkers = useRef<Record<string, any>>({});
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancelled = false;
    let ro: ResizeObserver | undefined;
    void Promise.all([import("mapbox-gl"), import("mapbox-gl/dist/mapbox-gl.css")]).then(([mod]) => {
      if (cancelled || !container.current) return;
      const mapboxgl = mod.default;
      glRef.current = mapboxgl;
      mapboxgl.accessToken = mapboxToken;
      const css = (name: string) => getComputedStyle(document.documentElement).getPropertyValue(name).trim() || "#334155";
      const colors: Record<ZoneRisk, string> = { safe: css("--success"), caution: css("--warning"), high: css("--danger") };
      const matchRisk = ["match", ["get", "risk"], "safe", colors.safe, "caution", colors.caution, colors.high];
      const map = new mapboxgl.Map({ container: container.current, style: "mapbox://styles/mapbox/light-v11", center: [28.052, -26.135], zoom: 12.1, attributionControl: false });
      mapRef.current = map;
      // The container settles after mount; keep the map's cached size in sync.
      ro = new ResizeObserver(() => map.resize());
      ro.observe(container.current);
      livePatients.forEach((p) => {
        const el = document.createElement("span");
        el.title = p.name; el.textContent = p.name[0];
        el.className = `flex size-5 items-center justify-center rounded-full border-2 border-surface bg-coral text-[0.5rem] font-bold text-primary-foreground shadow${highlight === p.id ? " ring-4 ring-coral/30" : ""}`;
        patientEls.current[p.id] = el;
        new mapboxgl.Marker({ element: el }).setLngLat([p.lng, p.lat]).addTo(map);
      });
      zones.forEach((z) => {
        const el = document.createElement("span");
        el.textContent = z.name;
        el.className = "pointer-events-none whitespace-nowrap rounded bg-surface/85 px-1.5 py-0.5 text-[0.5625rem] font-bold uppercase tracking-wide text-muted-foreground shadow-sm";
        new mapboxgl.Marker({ element: el, offset: [0, 8] }).setLngLat([z.lng, z.lat]).addTo(map);
      });
      map.on("load", () => {
        map.addSource("safety-zones", { type: "geojson", data: { type: "FeatureCollection", features: zones.map((z) => ({ type: "Feature", properties: { risk: z.risk, radiusKm: z.radiusKm }, geometry: { type: "Point", coordinates: [z.lng, z.lat] } })) } as any });
        map.addLayer({ id: "safety-zones", type: "circle", source: "safety-zones", paint: {
          "circle-radius": ["*", ["get", "radiusKm"], 60],
          "circle-color": matchRisk, "circle-opacity": 0.16,
          "circle-stroke-color": matchRisk, "circle-stroke-opacity": 0.55, "circle-stroke-width": 1.5,
        } as any });
        map.addSource("dispatch", { type: "geojson", data: { type: "FeatureCollection", features: [] } });
        map.addLayer({ id: "dispatch", type: "line", source: "dispatch", paint: { "line-color": css("--primary"), "line-width": 2.5, "line-opacity": 0.85, "line-dasharray": [2, 1.5] } as any });
        setReady(true);
        const pts = [...livePatients.map((x) => [x.lng, x.lat]), ...zones.map((x) => [x.lng, x.lat])] as [number, number][];
        const bounds = pts.reduce((b, p) => b.extend(p), new mapboxgl.LngLatBounds(pts[0], pts[0]));
        map.fitBounds(bounds, { padding: { top: 40, bottom: 56, left: 40, right: 40 }, maxZoom: 12.6, duration: 0 });
      });
    });
    return () => { cancelled = true; ro?.disconnect(); mapRef.current?.remove(); mapRef.current = null; glRef.current = null; clinicianMarkers.current = {}; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    Object.entries(patientEls.current).forEach(([id, el]) => { el.classList.toggle("ring-4", highlight === id); el.classList.toggle("ring-coral/30", highlight === id); });
  }, [highlight]);

  useEffect(() => {
    const map = mapRef.current; const gl = glRef.current;
    if (!map || !gl) return;
    clinicians.forEach((c) => {
      const sos = c.panic || panics.some((x) => x.status === "active" && x.name === c.name);
      let marker = clinicianMarkers.current[c.id];
      if (!marker) {
        const el = document.createElement("span");
        el.className = `flex items-center rounded-full px-1.5 py-0.5 text-[0.5625rem] font-bold shadow transition-colors ${c.role === "Doctor" ? "bg-accent text-accent-foreground" : "bg-primary text-primary-foreground"}`;
        marker = new gl.Marker({ element: el }).setLngLat([c.lng, c.lat]).addTo(map);
        clinicianMarkers.current[c.id] = marker;
      }
      const el = marker.getElement();
      el.title = `${c.name} · ${c.status}`;
      el.classList.toggle("bg-danger", sos);
      el.classList.toggle("notification-dot", sos);
      el.textContent = c.name.split(" ").slice(-1)[0];
      marker.setLngLat([c.lng, c.lat]);
    });
  }, [clinicians, panics]);

  useEffect(() => {
    const map = mapRef.current;
    if (!ready || !map?.getSource("dispatch")) return;
    map.getSource("dispatch").setData({ type: "FeatureCollection", features: clinicians.filter((c) => c.status === "En route" && c.target).map((c) => { const t = patientById(c.target!); return { type: "Feature", properties: {}, geometry: { type: "LineString", coordinates: [[c.lng, c.lat], [t.lng, t.lat]] } }; }) } as any);
  }, [clinicians, ready]);

  return <div ref={container} className="absolute inset-0" style={{ position: "absolute", top: 0, right: 0, bottom: 0, left: 0 }} aria-label="Live safety map" />;
}

function SchematicSafetyMap({ highlight }: { highlight?: string }) {
  const { clinicians, panics } = useLive();
  return <>
    <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="absolute inset-0 size-full" aria-hidden="true">
      {[20, 40, 60, 80].map((v) => <g key={v}><line x1={v} y1={0} x2={v} y2={100} stroke="var(--border)" strokeWidth={0.2} /><line x1={0} y1={v} x2={100} y2={v} stroke="var(--border)" strokeWidth={0.2} /></g>)}
      {zones.map((z) => { const c = project(z.lat, z.lng); const r = z.radiusKm * 3.6; return <ellipse key={z.id} cx={c.x} cy={c.y} rx={r} ry={r * 1.4} fill={`var(--${z.risk === "safe" ? "success" : z.risk === "caution" ? "warning" : "danger"})`} fillOpacity={0.18} stroke={`var(--${z.risk === "safe" ? "success" : z.risk === "caution" ? "warning" : "danger"})`} strokeWidth={0.3} strokeDasharray="1 0.6" />; })}
      {clinicians.filter((c) => c.status === "En route" && c.target).map((c) => { const a = project(c.lat, c.lng); const t = patientById(c.target!); const b = project(t.lat, t.lng); return <line key={c.id} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke="var(--primary)" strokeWidth={0.4} strokeDasharray="1 1" />; })}
    </svg>
    {zones.map((z) => { const c = project(z.lat, z.lng); return <span key={z.id} className="absolute -translate-x-1/2 translate-y-5 whitespace-nowrap text-[0.5625rem] font-bold uppercase text-muted-foreground" style={{ left: `${c.x}%`, top: `${c.y}%` }}>{z.name}</span>; })}
    {livePatients.map((p) => { const c = project(p.lat, p.lng); return <span key={p.id} title={p.name} className={cn("absolute flex size-5 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border-2 border-surface bg-coral text-[0.5rem] font-bold text-primary-foreground shadow", highlight === p.id && "ring-4 ring-coral/30")} style={{ left: `${c.x}%`, top: `${c.y}%` }}>{p.name[0]}</span>; })}
    {clinicians.map((c) => { const pt = project(c.lat, c.lng); const sos = c.panic || panics.some((x) => x.status === "active" && x.name === c.name); return <span key={c.id} title={`${c.name} · ${c.status}`} className={cn("absolute flex -translate-x-1/2 -translate-y-1/2 items-center gap-1 rounded-full px-1.5 py-0.5 text-[0.5625rem] font-bold shadow transition-all duration-[2400ms] ease-linear", sos ? "notification-dot bg-danger text-primary-foreground" : c.role === "Doctor" ? "bg-accent text-accent-foreground" : "bg-primary text-primary-foreground")} style={{ left: `${pt.x}%`, top: `${pt.y}%` }}>{c.role === "Doctor" ? <Stethoscope className="size-2.5" /> : <UserRound className="size-2.5" />}{c.name.split(" ").slice(-1)[0]}</span>; })}
  </>;
}

export function FieldAllocation({ patientId, actorRole }: { patientId: string; actorRole: "Doctor" | "Nurse" | "Admin" }) {
  const { clinicians } = useLive(); const p = patientById(patientId); const zone = zoneById(p.zone); const rule = visitRule(zone.risk);
  const rows = allocationFor(patientId, clinicians);
  const [done, setDone] = useState("");
  return <Card title="Visit allocation & area safety" note={`Only clinicians within ${PROXIMITY_KM} km of ${p.name.split(" ")[0]} can be allocated`}>
    <div className="grid gap-4 lg:grid-cols-[1fr_22rem]">
      <SafetyMap highlight={patientId} />
      <div className="space-y-3">
        <div className={cn("rounded-lg border p-3", zone.risk === "high" ? "border-danger/40 bg-danger/10" : zone.risk === "caution" ? "border-warning/40 bg-warning/10" : "border-success/40 bg-success/10")}><p className="flex items-center gap-2 text-xs font-bold"><ShieldAlert className="size-4" />{zone.name}: {riskLabel[zone.risk]} — {rule.mode}</p><p className="mt-1 text-[0.6875rem]">{zone.note}. {rule.needs}.</p></div>
        <ul className="space-y-2">{rows.map((r) => <li key={r.clinician.id} className={cn("rounded-lg border border-border p-3 text-xs", !r.inRange && "opacity-50")}>
          <div className="flex items-center justify-between gap-2"><span className="font-bold">{r.clinician.name}</span><Badge size="sm" variant={r.clinician.role === "Doctor" ? "accent" : "primary"}>{r.clinician.role}</Badge></div>
          <p className="mt-1 text-muted-foreground">{r.km.toFixed(1)} km · ETA {r.etaMin} min · {r.clinician.status}</p>
          <p className="mt-1 flex flex-wrap gap-x-3 text-[0.6875rem]"><span className="flex items-center gap-1"><Car className="size-3" />{r.clinician.driver ?? "No driver"}</span><span className="flex items-center gap-1"><Users className="size-3" />{r.clinician.companion ?? "No companion"}</span></p>
          {!r.inRange ? <p className="mt-2 text-[0.6875rem] text-muted-foreground">Outside the {PROXIMITY_KM} km area</p> : <div className="mt-2 flex flex-wrap gap-2">
            <Button size="sm" disabled={!r.physical} onClick={() => { dispatchClinician(r.clinician.id, patientId); setDone(`${r.clinician.name} dispatched with ${r.clinician.driver}${r.clinician.companion ? ` and ${r.clinician.companion}` : ""}.`); }} leadingIcon={<Car className="size-3.5" />}>Physical visit</Button>
            <Button size="sm" variant="secondary" onClick={() => { setVirtual(r.clinician.id); setDone(`${r.clinician.name} assigned a virtual consultation.`); }} leadingIcon={<Video className="size-3.5" />}>Virtual</Button>
          </div>}
          {r.inRange && !r.physical && rule.canTravel && !r.escortOk && <p className="mt-1 text-[0.6875rem] text-danger">Needs a companion before travelling here</p>}
        </li>)}</ul>
        {done && <p role="status" className="rounded-lg bg-success/15 p-2 text-xs font-semibold">{done}</p>}
        <p className="text-[0.625rem] text-muted-foreground">Allocated by {actorRole.toLowerCase()} · preview only.</p>
      </div>
    </div>
  </Card>;
}

export function FlagRiskArea({ by }: { by: string }) {
  const { flaggedAreas } = useLive(); const [name, setName] = useState(""); const [note, setNote] = useState("");
  return <Card title="Flag a risk area" note="Visible to admin and every clinician allocated nearby">
    <form className="space-y-2" onSubmit={(e) => { e.preventDefault(); if (!name.trim() || !note.trim()) return; flagArea({ name: name.trim().slice(0, 80), note: note.trim().slice(0, 300), by }); setName(""); setNote(""); }}>
      <Input aria-label="Area or street" maxLength={80} placeholder="Area or street, e.g. 7th Ave, Alexandra" value={name} onChange={(e) => setName(e.currentTarget.value)} />
      <Textarea aria-label="What did you see" maxLength={300} rows={2} placeholder="What did you see?" value={note} onChange={(e) => setNote(e.currentTarget.value)} />
      <Button size="sm" type="submit" leadingIcon={<Flag className="size-3.5" />}>Flag area</Button>
    </form>
    {flaggedAreas.length > 0 && <ul className="mt-3 space-y-2">{flaggedAreas.map((f, i) => <li key={i} className="rounded-lg bg-warning/15 p-2 text-xs"><b>{f.name}</b> — {f.note}<span className="block text-[0.625rem] text-muted-foreground">Flagged by {f.by}</span></li>)}</ul>}
  </Card>;
}

export function FieldSafety({ clinicianId }: { clinicianId: string }) {
  const { clinicians, tick } = useLive(); const c = clinicians.find((x) => x.id === clinicianId)!;
  const remaining = Math.max(0, 360 - (tick - c.lastCheckIn) * 2.5);
  const [pin, setPin] = useState(""); const [duress, setDuress] = useState(false);
  return <Card title="Field safety" note={`${c.name} · ${c.vehicle ?? "No vehicle"}`}>
    <div className="flex items-center gap-4"><div className={cn("flex size-16 items-center justify-center rounded-full border-4 font-display text-lg font-bold tabular-nums", remaining < 60 ? "border-danger text-danger" : "border-success")}>{Math.floor(remaining / 60)}:{String(Math.floor(remaining % 60)).padStart(2, "0")}</div><div className="flex-1"><p className="text-xs font-bold">Next safety check-in</p><p className="text-[0.6875rem] text-muted-foreground">Control room is alerted if the timer runs out.</p><Button size="sm" className="mt-2" onClick={() => checkIn(clinicianId)} leadingIcon={<Check className="size-3.5" />}>I'm safe</Button></div></div>
    <div className="mt-4 grid gap-2 text-xs sm:grid-cols-2"><p className="flex items-center gap-2 rounded-lg bg-muted p-2"><Car className="size-4" />Driver: {c.driver ?? "—"}</p><p className="flex items-center gap-2 rounded-lg bg-muted p-2"><Users className="size-4" />Companion: {c.companion ?? "—"}</p></div>
    <form className="mt-4 flex gap-2" onSubmit={(e) => { e.preventDefault(); setDuress(pin === "9999"); setPin(""); }}><Input aria-label="Safety PIN" type="password" inputMode="numeric" maxLength={4} placeholder="Safety PIN (duress PIN sends silent alert)" value={pin} onChange={(e) => setPin(e.currentTarget.value.replace(/\D/g, ""))} /><Button size="sm" variant="secondary" type="submit">Confirm</Button></form>
    <p className="mt-1 text-[0.625rem] text-muted-foreground">{duress ? "PIN accepted." : "Demo: 1234 is normal, 9999 is duress."}</p>
  </Card>;
}

/* ---------------- Panic button (every role) ---------------- */
const emergencyKinds = [
  { key: "Medical emergency", icon: HeartPulse },
  { key: "Personal safety threat", icon: ShieldAlert },
  { key: "Vehicle accident", icon: Car },
  { key: "Fire or hazard", icon: AlertTriangle },
  { key: "Other emergency", icon: Siren },
];
export function PanicButton({ role, name, className }: { role: "Patient" | "Nurse" | "Doctor" | "Admin" | "Partner"; name: string; className?: string }) {
  const [open, setOpen] = useState(false); const [kind, setKind] = useState(""); const [count, setCount] = useState<number | null>(null); const [sent, setSent] = useState<string | null>(null);
  useEffect(() => {
    if (count === null) return;
    if (count === 0) { setSent(sendPanic({ role, name, kind })); setCount(null); return; }
    const t = setTimeout(() => setCount(count - 1), 1000); return () => clearTimeout(t);
  }, [count, role, name, kind]);
  const close = () => { setOpen(false); setKind(""); setCount(null); };
  return <>
    <button type="button" onClick={() => setOpen(true)} aria-label="Panic button — emergency alert" className={cn("flex items-center gap-2 rounded-full bg-danger px-4 py-2.5 text-sm font-bold text-primary-foreground shadow-lg ring-4 ring-danger/20 hover:ring-danger/40 focus-visible:outline-none focus-visible:ring-danger/60", className)}><Siren className="size-4" />SOS</button>
    {open && <div className="fixed inset-0 z-[70] flex items-end justify-center bg-foreground/40 p-4 sm:items-center" role="dialog" aria-modal="true" aria-labelledby="sos-title">
      <div className="w-full max-w-md rounded-2xl bg-surface p-5 shadow-xl">
        <div className="flex items-start justify-between"><div><p className="text-[0.625rem] font-bold uppercase text-danger">Emergency</p><h2 id="sos-title" className="font-display text-xl font-semibold">{sent ? "Help is on the way" : "What is happening?"}</h2></div><button type="button" onClick={close} aria-label="Close" className="rounded-md p-1 hover:bg-muted"><X className="size-4" /></button></div>
        {sent ? <div className="mt-4 space-y-3 text-sm"><p className="flex items-center gap-2 rounded-lg bg-danger/10 p-3"><Siren className="size-4 text-danger" />Alert {sent} sent to the control room with your live location.</p><ul className="space-y-1 text-xs text-muted-foreground"><li>• Emergency contacts notified by SMS</li><li>• {role === "Patient" ? "Nearest clinician and ambulance service alerted" : "Security response and your driver/companion alerted"}</li><li>• Stay on the line: control room will call you</li></ul><a href="tel:10177" className="flex items-center justify-center gap-2 rounded-lg bg-danger py-2.5 text-sm font-bold text-primary-foreground"><Phone className="size-4" />Call 10177 now</a><div className="flex gap-2"><Button variant="secondary" className="flex-1" onClick={() => { setPanicStatus(sent, "cancelled"); setSent(null); close(); }}>I'm safe — cancel</Button><Button variant="ghost" className="flex-1" onClick={close}>Keep active</Button></div><p className="text-[0.625rem] text-muted-foreground">Preview: no real alert is sent.</p></div>
          : count !== null ? <div className="mt-6 flex flex-col items-center gap-3"><div className="notification-dot flex size-24 items-center justify-center rounded-full bg-danger font-display text-4xl font-bold text-primary-foreground">{count}</div><p className="text-sm">Sending "{kind}" alert…</p><Button variant="secondary" onClick={() => setCount(null)}>Cancel</Button></div>
          : <div className="mt-4 grid gap-2">{emergencyKinds.map((k) => <button key={k.key} type="button" onClick={() => { setKind(k.key); setCount(3); }} className="flex items-center gap-3 rounded-lg border border-border p-3 text-left text-sm font-semibold hover:border-danger hover:bg-danger/5"><k.icon className="size-5 text-danger" />{k.key}</button>)}<p className="text-[0.6875rem] text-muted-foreground">Your alert sends after a 3-second countdown so you can cancel an accidental tap.</p></div>}
      </div>
    </div>}
  </>;
}

export function PanicFloating(props: { role: "Patient" | "Nurse" | "Doctor" | "Admin" | "Partner"; name: string }) {
  return <div className="fixed bottom-5 left-5 z-[60]"><PanicButton {...props} /></div>;
}

/* ---------------- Security step-up ---------------- */
export function SecurityStepUp({ role, reg }: { role: "Nurse" | "Doctor" | "Admin"; reg: string }) {
  const [otp, setOtp] = useState(""); const [otpOk, setOtpOk] = useState(false); const [face, setFace] = useState<"idle" | "scanning" | "ok">("idle");
  useEffect(() => { if (face !== "scanning") return; const t = setTimeout(() => setFace("ok"), 1600); return () => clearTimeout(t); }, [face]);
  const steps = [
    { label: "Password", ok: true, icon: KeyRound },
    { label: "Trusted device", ok: true, icon: Smartphone },
    { label: "One-time code", ok: otpOk, icon: Fingerprint },
    { label: "Face match", ok: face === "ok", icon: ScanFace },
    { label: role === "Doctor" ? "HPCSA registration" : role === "Nurse" ? "SANC registration" : "Admin role", ok: true, icon: ShieldCheck },
  ];
  const all = steps.every((s) => s.ok);
  return <Card title="Security verification" note={`${role} step-up · ${reg}`} action={<Badge variant={all ? "success" : "warning"}>{steps.filter((s) => s.ok).length}/{steps.length} verified</Badge>}>
    <ol className="grid gap-2 sm:grid-cols-5">{steps.map((s) => <li key={s.label} className={cn("flex flex-col items-center gap-1 rounded-lg border p-2 text-center text-[0.6875rem] font-semibold", s.ok ? "border-success/40 bg-success/10" : "border-border")}><s.icon className={cn("size-4", s.ok ? "text-success" : "text-muted-foreground")} />{s.label}</li>)}</ol>
    <div className="mt-4 grid gap-4 sm:grid-cols-2">
      <form onSubmit={(e) => { e.preventDefault(); setOtpOk(otp === "246810"); }} className="space-y-2"><label className="text-xs font-semibold" htmlFor={`otp-${role}`}>One-time code</label><Input id={`otp-${role}`} inputMode="numeric" maxLength={6} placeholder="6-digit code" value={otp} onChange={(e) => setOtp(e.currentTarget.value.replace(/\D/g, ""))} disabled={otpOk} /><Button size="sm" type="submit" disabled={otpOk}>{otpOk ? "Code verified" : "Verify code"}</Button><p className="text-[0.625rem] text-muted-foreground">Demo code: 246810</p></form>
      <div className="space-y-2"><p className="text-xs font-semibold">Face match</p><div className={cn("flex h-20 items-center justify-center rounded-lg border-2 border-dashed", face === "ok" ? "border-success bg-success/10" : "border-border")}><ScanFace className={cn("size-8", face === "scanning" && "notification-dot text-accent", face === "ok" && "text-success")} /></div><Button size="sm" variant="secondary" disabled={face !== "idle"} onClick={() => setFace("scanning")}>{face === "ok" ? "Face matched" : face === "scanning" ? "Scanning…" : "Start face match"}</Button></div>
    </div>
    <p className="mt-3 text-[0.625rem] text-muted-foreground">Required before signing, prescribing or starting field deployment. Preview only.</p>
  </Card>;
}

/* ---------------- Visit verification (clinician side) ---------------- */
export function ClinicianVerify() {
  const [code, setCode] = useState(""); const [state, setState] = useState<"idle" | "ok" | "bad">("idle");
  return <Card title="Arrival verification" note="Scan the patient's QR code or enter their 6-digit code">
    <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); setState(code === "482913" ? "ok" : "bad"); }}><Input aria-label="Patient visit code" inputMode="numeric" maxLength={6} placeholder="Visit code" value={code} onChange={(e) => setCode(e.currentTarget.value.replace(/\D/g, ""))} /><Button type="submit" leadingIcon={<QrCode className="size-4" />}>Verify</Button></form>
    <Button size="sm" variant="ghost" className="mt-2" onClick={() => { setCode("482913"); setState("ok"); }} leadingIcon={<ScanFace className="size-3.5" />}>Simulate QR scan</Button>
    {state === "ok" && <p role="status" className="mt-2 flex items-center gap-2 rounded-lg bg-success/15 p-2 text-xs font-semibold"><CheckCircle2 className="size-4 text-success" />Identity confirmed — Thandi Molekoa, visit VIS-2048.</p>}
    {state === "bad" && <p role="alert" className="mt-2 rounded-lg bg-danger/10 p-2 text-xs text-danger">Code does not match. Do not enter; contact the control room.</p>}
    <p className="mt-2 text-[0.625rem] text-muted-foreground">Demo code: 482913</p>
  </Card>;
}

/* ---------------- Patient visit tracker ---------------- */
export function PatientVisitTracker() {
  const { clinicians } = useLive();
  const nurse = clinicians.find((c) => c.id === "N-01")!; const me = patientById("MT-10234");
  const km = distanceKm([nurse.lat, nurse.lng], [me.lat, me.lng]); const eta = Math.max(0, Math.round((km / 32) * 60));
  const arrived = nurse.status === "On site";
  const [code] = useState("482913");
  return <div className="space-y-5">
    <div><p className="text-xs font-bold uppercase text-accent">Home visit today</p><h1 className="font-display text-3xl font-semibold">Your nurse is on the way</h1><p className="mt-1 text-sm text-muted-foreground">Track the visit live and verify your nurse at the door.</p></div>
    <PreviewNote>Preview: the nurse's location is simulated. Live GPS connects later.</PreviewNote>
    <div className="grid gap-5 lg:grid-cols-[1fr_20rem]">
      <section className="rounded-xl border border-border bg-surface p-5 shadow-sm">
        <div className="mb-4 grid grid-cols-3 gap-3 text-center"><div className="rounded-lg bg-muted/50 p-3"><p className="font-display text-2xl font-semibold tabular-nums">{arrived ? "0.0" : km.toFixed(1)}</p><p className="text-[0.6875rem] text-muted-foreground">km away</p></div><div className="rounded-lg bg-muted/50 p-3"><p className="font-display text-2xl font-semibold tabular-nums">{arrived ? "Now" : `${eta} min`}</p><p className="text-[0.6875rem] text-muted-foreground">arrival</p></div><div className="rounded-lg bg-muted/50 p-3"><p className="font-display text-lg font-semibold">{arrived ? "At your door" : "En route"}</p><p className="text-[0.6875rem] text-muted-foreground">status</p></div></div>
        <div className="mb-4 h-2 overflow-hidden rounded-full bg-muted"><div className="h-full rounded-full bg-accent transition-all duration-[2400ms]" style={{ width: `${arrived ? 100 : Math.round(nurse.progress * 100)}%` }} /></div>
        <SafetyMap highlight={me.id} height="h-72" />
      </section>
      <div className="space-y-5">
        <section className="rounded-xl border border-border bg-surface p-5 shadow-sm"><p className="text-xs font-bold">Your nurse</p><div className="mt-3 flex items-center gap-3"><span className="flex size-12 items-center justify-center rounded-full bg-primary/10 font-bold text-primary">NM</span><div><p className="text-sm font-bold">{nurse.name}</p><p className="text-[0.6875rem] text-muted-foreground">{nurse.reg} · verified</p></div></div><ul className="mt-3 space-y-1.5 text-xs"><li className="flex items-center gap-2"><Car className="size-3.5" />{nurse.vehicle}</li><li className="flex items-center gap-2"><UserRound className="size-3.5" />Driver: {nurse.driver}</li><li className="flex items-center gap-2"><Users className="size-3.5" />Companion: {nurse.companion}</li></ul></section>
        <section className="rounded-xl border border-accent/40 bg-surface p-5 text-center shadow-sm"><p className="flex items-center justify-center gap-2 text-xs font-bold"><QrCode className="size-4 text-accent" />Door verification</p><div className="mx-auto mt-3 w-fit rounded-lg bg-surface p-2 ring-1 ring-border"><QRCodeSVG value={`mythuso://verify/VIS-2048/${code}`} size={148} /></div><p className="mt-3 font-display text-2xl font-semibold tracking-[0.3em]">{code}</p><p className="mt-1 text-[0.6875rem] text-muted-foreground">Only open the door once your nurse scans this code and your screen confirms the match. Never share it by phone.</p></section>
      </div>
    </div>
  </div>;
}

/* ---------------- Admin deployment view ---------------- */
export function AdminDeployment() {
  const { clinicians, alarms, panics, flaggedAreas, tick } = useLive();
  const [patientId, setPatientId] = useState("MT-10251");
  const active = panics.filter((p) => p.status === "active");
  const counts = { enroute: clinicians.filter((c) => c.status === "En route").length, onsite: clinicians.filter((c) => c.status === "On site").length, virtual: clinicians.filter((c) => c.status === "Virtual").length, alarms: alarms.filter((a) => a.status !== "resolved").length };
  return <div className="min-h-screen bg-background">
    <header className="sticky top-0 z-40 flex items-center gap-3 border-b border-border bg-surface/95 px-4 py-3 backdrop-blur sm:px-6"><Link to="/" className="font-display text-lg font-semibold">MyThuso <span className="text-accent">Control room</span></Link><Badge variant="success" className="ml-2"><LiveDot /> Live</Badge><div className="ml-auto flex items-center gap-2"><Link to="/nurse" className="text-xs font-semibold text-muted-foreground hover:text-foreground">Nurse</Link><Link to="/doctor" className="text-xs font-semibold text-muted-foreground hover:text-foreground">Doctor</Link><Link to="/patient" className="text-xs font-semibold text-muted-foreground hover:text-foreground">Patient</Link></div></header>
    <main className="space-y-5 p-4 sm:p-6">
      <Heading icon={Navigation} eyebrow="Admin" title="Live deployment" note="Where every nurse and doctor is, who is with them, and which areas are safe." />
      <PreviewNote>Preview: positions, area risk and alerts are simulated. Live GPS and police reports connect later through the code engine.</PreviewNote>
      {active.length > 0 && <div role="alert" className="notification-dot rounded-xl border border-danger bg-danger p-4 text-primary-foreground">{active.map((p) => <div key={p.id} className="flex flex-wrap items-center gap-3"><Siren className="size-5" /><p className="flex-1 text-sm font-bold">{p.id}: {p.kind} — {p.name} ({p.role}) at {fmtTime(p.at)}</p><Button size="sm" variant="secondary" onClick={() => setPanicStatus(p.id, "resolved")}>Mark handled</Button></div>)}</div>}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">{[["En route", counts.enroute, Car], ["On site", counts.onsite, MapPin], ["Virtual", counts.virtual, Video], ["Open alarms", counts.alarms, BellRing]].map(([l, v, I]) => { const Icon = I as LucideIcon; return <div key={l as string} className="doctor-metric rounded-xl border border-border bg-surface p-4"><Icon className="size-4 text-accent" /><p className="mt-2 font-display text-3xl font-semibold">{v as number}</p><p className="text-xs text-muted-foreground">{l as string}</p></div>; })}</div>
      <div className="grid gap-5 xl:grid-cols-[1fr_24rem]">
        <Card title="Live map" note={`Updated ${tick} times this session`}><SafetyMap height="h-[28rem]" /></Card>
        <Card title="Deployed team" note="Status, escort and check-ins"><ul className="space-y-2">{clinicians.map((c) => { const overdue = tick - c.lastCheckIn > 144; return <li key={c.id} className={cn("rounded-lg border p-3 text-xs", c.panic ? "border-danger bg-danger/10" : "border-border")}><div className="flex items-center justify-between"><span className="font-bold">{c.name}</span><Badge size="sm" variant={c.status === "En route" ? "primary" : c.status === "On site" ? "success" : "neutral"}>{c.status}</Badge></div><p className="mt-1 text-muted-foreground">{c.role} · {c.reg}{c.target ? ` · to ${patientById(c.target).name.split(" ")[0]}` : ""}</p><p className="mt-1 flex flex-wrap gap-x-3"><span className="flex items-center gap-1"><Car className="size-3" />{c.driver ?? "—"}</span><span className="flex items-center gap-1"><Users className="size-3" />{c.companion ?? "No companion"}</span></p><p className={cn("mt-1 flex items-center gap-1", overdue ? "text-danger" : "text-success")}><Clock3 className="size-3" />{overdue ? "Check-in overdue" : "Checked in"}</p></li>; })}</ul></Card>
      </div>
      <div className="flex gap-2 overflow-x-auto pb-1">{livePatients.map((x) => <button key={x.id} type="button" onClick={() => setPatientId(x.id)} className={cn("shrink-0 rounded-full border px-3 py-1.5 text-xs font-semibold", x.id === patientId ? "border-primary bg-primary text-primary-foreground" : "border-border bg-surface")}>{x.name} · {zoneById(x.zone).name}</button>)}</div>
      <FieldAllocation patientId={patientId} actorRole="Admin" />
      <div className="grid gap-5 xl:grid-cols-2">
        <Card title="Area risk register" note="Police reports + staff flags"><ul className="space-y-2">{zones.map((z) => <li key={z.id} className="flex items-start justify-between gap-2 rounded-lg border border-border p-3 text-xs"><div><p className="font-bold">{z.name}</p><p className="text-muted-foreground">{z.note}</p></div><Badge size="sm" variant={riskTone[z.risk]}>{riskLabel[z.risk]}</Badge></li>)}{flaggedAreas.map((f, i) => <li key={i} className="rounded-lg bg-warning/15 p-3 text-xs"><b>{f.name}</b> — {f.note} <span className="text-muted-foreground">({f.by})</span></li>)}</ul></Card>
        <SecurityStepUp role="Admin" reg="Control room supervisor" />
      </div>
      <AlarmCentre role="Doctor" actor="Control room" />
    </main>
    <PanicFloating role="Admin" name="Control room supervisor" />
  </div>;
}
