import { Activity, Bell, Building2, CalendarDays, CheckCircle2, ClipboardList, FileText, HeartPulse, Home, MessageSquareText, Search, Settings, ShieldCheck, Stethoscope, Users } from "lucide-react";
export const showcaseIcons = { Activity, Bell, Building2, CalendarDays, CheckCircle2, ClipboardList, FileText, HeartPulse, Home, MessageSquareText, Search, Settings, ShieldCheck, Stethoscope, Users };
