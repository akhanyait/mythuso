import { useState } from "react";
import { Link, useRouter } from "@tanstack/react-router";
import type { LucideIcon } from "lucide-react";
import { Check, ClipboardCheck, FlaskConical, LogOut, PackageCheck, Pill, Repeat, Search, ShieldCheck, Truck, X } from "lucide-react";
import mythusoWordmark from "../assets/logos/mythuso-logo.png";
import patientLerato from "../assets/photography/patient-lerato.jpg";
import patientSipho from "../assets/photography/patient-sipho.jpg";
import patientThandi from "../assets/photography/patient-thandi.jpg";
import { Button, Input, Textarea } from "../index";
import { cn } from "../lib/utils";
import { PanicFloating } from "./care-safety";

export type PartnerPage = "orders" | "repeats" | "collections" | "results";
const paths: Record<PartnerPage, string> = { orders: "/partner", repeats: "/partner/repeats", collections: "/partner/collections", results: "/partner/results" };
const nav: { page: PartnerPage; label: string; icon: LucideIcon }[] = [
  { page: "orders", label: "Orders", icon: ClipboardCheck },
  { page: "repeats", label: "Substitution & repeats", icon: Repeat },
  { page: "collections", label: "Collections", icon: Truck },
  { page: "results", label: "Results", icon: FlaskConical },
];

type Stage = 0 | 1 | 2; // requested, verified, handed over
type Rx = { id: string; items: string[]; patient: string; image: string; doctor: string; stage: Stage; held?: string; batch?: string; mine: boolean };
const seedRx: Rx[] = [
  { id: "RX-0081", items: ["Amlodipine 5 mg · 30 tabs", "Hydrochlorothiazide 12.5 mg · 30 tabs"], patient: "Lerato Molefe", image: patientLerato, doctor: "Dr Ayanda Dlamini", stage: 0, mine: true },
  { id: "RX-0079", items: ["Metformin 500 mg · 60 tabs"], patient: "Thabo Molefe", image: patientSipho, doctor: "Dr Ayanda Dlamini", stage: 2, batch: "MF-24-118", mine: false },
];
const labs = [
  { id: "LAB-0023", test: "Fasting panel", status: "At the laboratory", note: "Results verified", patient: "Lerato Molefe" },
  { id: "LAB-0019", test: "HbA1c", status: "With the courier", note: "Sample in transit · seal intact", patient: "Thabo Molefe" },
];
const stageLabel = ["Awaiting pharmacist", "Verified · ready for release", "Handed over"];

function Panel({ title, note, children, className }: { title?: string; note?: string; children: React.ReactNode; className?: string }) {
  return <section className={cn("doctor-panel rounded-xl border border-border bg-surface p-5 shadow-sm", className)}>{title && <div className="mb-4"><h2 className="font-display text-lg font-semibold">{title}</h2>{note && <p className="mt-0.5 text-xs text-muted-foreground">{note}</p>}</div>}{children}</section>;
}
function Chip({ tone, children }: { tone: "yours" | "else" | "ok" | "warn"; children: React.ReactNode }) {
  const t = { yours: "bg-primary text-primary-foreground", else: "bg-muted text-muted-foreground", ok: "bg-success/15 text-success", warn: "bg-warning/15 text-warning" }[tone];
  return <span className={cn("rounded-full px-2 py-0.5 text-[0.625rem] font-bold uppercase", t)}>{children}</span>;
}

function Workflow({ rx, onChange }: { rx: Rx; onChange: (r: Rx) => void }) {
  const [original, setOriginal] = useState(false);
  const [allergy, setAllergy] = useState(false);
  const [recipient, setRecipient] = useState(false);
  const [batch, setBatch] = useState("");
  const [reason, setReason] = useState("");
  const steps = [["Requested", "A doctor, against a signed consultation."], ["Verified", "Original prescription checked and allergy record reconciled."], ["Handed over", "Prescription and recipient verified before release."]];
  return <Panel title={`Prescription to handover · ${rx.id}`} note="Three acts by two registered people — nobody may perform two of them. Nothing here is dispensed.">
    <ol className="grid gap-3 sm:grid-cols-3">{steps.map(([t, d], i) => <li key={t} className={cn("rounded-lg border p-3 transition-colors", rx.stage >= i ? "border-success/40 bg-success/5" : "border-border")}><span className={cn("mb-2 flex size-6 items-center justify-center rounded-full text-xs font-bold", rx.stage >= i ? "bg-success text-primary-foreground" : "bg-muted")}>{rx.stage >= i ? <Check className="size-3.5" /> : i + 1}</span><p className="text-sm font-bold">{t}</p><p className="text-xs text-muted-foreground">{d}</p></li>)}</ol>
    {rx.held && <p className="mt-4 rounded-lg bg-warning/10 p-3 text-xs text-warning">On hold: {rx.held} <button className="ml-2 underline" onClick={() => onChange({ ...rx, held: undefined })}>Lift hold</button></p>}
    {!rx.held && rx.stage === 0 && <div className="mt-4 space-y-2 text-sm">
      <label className="flex items-center gap-2"><input type="checkbox" checked={original} onChange={(e) => setOriginal(e.target.checked)} />Original prescription matches the request</label>
      <label className="flex items-center gap-2"><input type="checkbox" checked={allergy} onChange={(e) => setAllergy(e.target.checked)} />Allergy record reconciled (no known allergies)</label>
      <div className="flex flex-wrap gap-2 pt-2"><Button disabled={!original || !allergy} onClick={() => onChange({ ...rx, stage: 1 })}>Verify request</Button></div>
      <Textarea placeholder="Written reason to hold this request" value={reason} onChange={(e) => setReason(e.target.value)} aria-label="Hold reason" />
      <Button variant="secondary" disabled={reason.trim().length < 5} onClick={() => { onChange({ ...rx, held: reason.trim() }); setReason(""); }}>Hold with reason</Button>
    </div>}
    {!rx.held && rx.stage === 1 && <div className="mt-4 space-y-2 text-sm">
      <Input placeholder="Named batch number, e.g. AM-24-331" value={batch} onChange={(e) => setBatch(e.target.value)} aria-label="Batch number" />
      <label className="flex items-center gap-2"><input type="checkbox" checked={recipient} onChange={(e) => setRecipient(e.target.checked)} />Recipient identity checked against the prescription</label>
      <Button disabled={batch.trim().length < 4 || !recipient} onClick={() => onChange({ ...rx, stage: 2, batch: batch.trim(), mine: false })} leadingIcon={<PackageCheck className="size-4" />}>Release against batch</Button>
    </div>}
    {rx.stage === 2 && <p className="mt-4 rounded-lg bg-success/10 p-3 text-xs text-success">Released against batch {rx.batch}. Awaiting courier.</p>}
  </Panel>;
}

export function PartnerSpace({ page = "orders" }: { page?: PartnerPage }) {
  const router = useRouter();
  const [rxs, setRxs] = useState(seedRx);
  const [sel, setSel] = useState("RX-0081");
  const [collected, setCollected] = useState<string[]>([]);
  const [subs, setSubs] = useState<Record<string, "approved" | "declined">>({});
  const current = rxs.find((r) => r.id === sel)!;
  const update = (r: Rx) => setRxs((all) => all.map((x) => (x.id === r.id ? r : x)));
  const yours = rxs.filter((r) => r.mine && r.stage < 2).length;

  const stats = [["Open orders", rxs.filter((r) => r.stage < 2).length + labs.length, "1 past its window"], ["Collections", 3 - collected.length, "Next 07:00"], ["Ready for release", rxs.filter((r) => r.stage === 1).length, "Awaiting a clinician"], ["Yours to act on", yours, "Pharmacist queue"]] as const;

  const content = {
    orders: <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_minmax(0,1.3fr)]">
      <Panel title={`Prescriptions · ${rxs.length}`} note="Every row says whether the next move is yours or somebody else's.">
        <ul className="space-y-2">{rxs.map((r) => <li key={r.id}><button onClick={() => setSel(r.id)} className={cn("flex w-full items-center gap-3 rounded-lg border p-3 text-left transition-colors hover:bg-muted/50", sel === r.id ? "border-primary" : "border-border")}><img src={r.image} alt="" className="size-10 rounded-full object-cover" /><span className="min-w-0 flex-1"><span className="block text-sm font-bold">{r.id} · {r.patient}</span><span className="block text-xs text-muted-foreground">{r.items.length} item{r.items.length > 1 ? "s" : ""} · {r.held ? "On hold" : stageLabel[r.stage]}</span></span><Chip tone={r.mine && r.stage < 2 ? "yours" : "else"}>{r.mine && r.stage < 2 ? "Yours" : "Elsewhere"}</Chip></button></li>)}</ul>
        <h3 className="mb-2 mt-5 text-sm font-bold">Laboratory · {labs.length}</h3>
        <ul className="space-y-2">{labs.map((l) => <li key={l.id} className="flex items-center gap-3 rounded-lg border border-border p-3"><FlaskConical className="size-5 text-accent" /><span className="flex-1"><span className="block text-sm font-bold">{l.id} · {l.test}</span><span className="block text-xs text-muted-foreground">{l.status} · {l.note}</span></span><Chip tone="else">Elsewhere</Chip></li>)}</ul>
      </Panel>
      <div className="space-y-4">
        <Panel title={current.patient} note={`Prescribed by ${current.doctor} · Care consent recorded`}><ul className="space-y-1 text-sm">{current.items.map((i) => <li key={i} className="flex items-center gap-2"><Pill className="size-4 text-primary" />{i}</li>)}</ul><p className="mt-3 text-xs text-muted-foreground">Allergy record: no known allergies reported · Reconciled</p></Panel>
        <Workflow key={current.id} rx={current} onChange={update} />
      </div>
    </div>,
    repeats: <Panel title="Substitution & repeats" note="Generic substitutions need the patient's agreement and cannot change strength or form.">
      <ul className="space-y-3">{[["SUB-12", "Amlodipine 5 mg (Norvasc) → generic amlodipine 5 mg", "Lerato Molefe"], ["REP-07", "Metformin 500 mg · repeat 2 of 5", "Thabo Molefe"], ["REP-09", "Salbutamol inhaler · repeat 1 of 3", "Nomsa Molefe"]].map(([id, d, p]) => <li key={id} className="flex flex-wrap items-center gap-3 rounded-lg border border-border p-3"><Repeat className="size-5 text-accent" /><span className="min-w-0 flex-1"><span className="block text-sm font-bold">{id} · {p}</span><span className="block text-xs text-muted-foreground">{d}</span></span>{subs[id] ? <Chip tone={subs[id] === "approved" ? "ok" : "warn"}>{subs[id]}</Chip> : <span className="flex gap-2"><Button size="sm" onClick={() => setSubs({ ...subs, [id]: "approved" })}>Approve</Button><Button size="sm" variant="secondary" onClick={() => setSubs({ ...subs, [id]: "declined" })}>Decline</Button></span>}</li>)}</ul>
    </Panel>,
    collections: <Panel title="Collections" note="Courier and patient collections. Verify the recipient before any handover.">
      <ul className="space-y-3">{[["07:00", "Courier · Rosebank route", "RX-0079 · sealed bag 4412", patientSipho], ["09:30", "Patient collection", "Lerato Molefe · RX-0081", patientLerato], ["12:00", "Nurse pickup · Sister Naledi", "Home visit kit for Nomsa Molefe", patientThandi]].map(([t, w, d, img]) => <li key={t} className="flex flex-wrap items-center gap-3 rounded-lg border border-border p-3"><span className="w-14 font-display text-lg font-semibold text-primary">{t}</span><img src={img} alt="" className="size-10 rounded-full object-cover" /><span className="min-w-0 flex-1"><span className="block text-sm font-bold">{w}</span><span className="block text-xs text-muted-foreground">{d}</span></span>{collected.includes(t) ? <Chip tone="ok">Collected</Chip> : <Button size="sm" onClick={() => setCollected([...collected, t])} leadingIcon={<ShieldCheck className="size-4" />}>Verify & hand over</Button>}</li>)}</ul>
    </Panel>,
    results: <Panel title="Laboratory results" note="Results are verified by the laboratory and released to the requesting doctor, not interpreted here.">
      <div className="grid gap-3 md:grid-cols-2">{labs.map((l) => <div key={l.id} className="rounded-lg border border-border p-4"><div className="flex items-center justify-between"><p className="font-bold">{l.id}</p><Chip tone={l.status === "At the laboratory" ? "ok" : "warn"}>{l.note.split(" · ")[0]}</Chip></div><p className="mt-1 text-sm">{l.test} · {l.patient}</p><ol className="mt-3 flex gap-1">{["Collected", "In transit", "At lab", "Verified"].map((s, i) => <li key={s} className="flex-1"><span className={cn("block h-1.5 rounded-full", i <= (l.status === "At the laboratory" ? 3 : 1) ? "bg-primary" : "bg-muted")} /><span className="mt-1 block text-[0.625rem] text-muted-foreground">{s}</span></li>)}</ol></div>)}</div>
    </Panel>,
  }[page];

  return <div className="patient-dashboard min-h-screen overflow-x-hidden bg-background"><div className="flex">
    <aside className="sticky top-0 hidden h-screen w-60 shrink-0 flex-col border-r border-border bg-surface lg:flex"><div className="border-b border-border p-5"><Link to="/"><img src={mythusoWordmark} alt="MyThuso — Help. Health. Home." width={1657} height={598} className="h-8 w-auto object-contain" /></Link><div className="mt-4 flex items-center gap-3 rounded-lg bg-muted/50 p-3"><span className="flex size-9 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">RP</span><div><p className="text-xs font-bold">Rosebank Community Pharmacy</p><p className="text-[0.625rem] text-muted-foreground">SAPC Y041882</p></div></div><p className="mt-3 flex items-center gap-2 text-[0.6875rem] text-success"><ShieldCheck className="size-3.5" />7 of 7 checks passing</p></div>
      <nav className="flex-1 p-3" aria-label="Partner navigation"><p className="mb-1 px-3 text-[0.5625rem] font-bold uppercase text-muted-foreground">Workspace</p>{nav.map(({ page: p, label, icon: Icon }) => <Link key={p} to={paths[p]} className={cn("patient-nav-item mb-1 flex h-9 items-center gap-3 rounded-md px-3 text-xs font-semibold text-muted-foreground hover:bg-muted hover:text-foreground", page === p && "bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground")}><Icon className="size-4" />{label}</Link>)}</nav>
      <Button variant="ghost" onClick={() => router.navigate({ to: "/" })} className="m-3 mb-20 justify-start" leadingIcon={<LogOut className="size-4" />}>Leave this workspace</Button></aside>
    <div className="min-w-0 flex-1">
      <header className="sticky top-0 z-40 flex items-center gap-3 border-b border-border bg-surface/95 px-4 py-3 backdrop-blur sm:px-6"><Link to="/" className="lg:hidden"><img src={mythusoWordmark} alt="MyThuso — Help. Health. Home." width={1657} height={598} className="h-7 w-auto object-contain" /></Link><div className="relative hidden flex-1 sm:block"><Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" /><Input type="search" placeholder="Search orders, patients or batches..." className="max-w-xl bg-muted/50 pl-10" /></div><span className="ml-auto rounded-full bg-accent/15 px-3 py-1 text-[0.625rem] font-bold uppercase">Design preview · Fictional data</span></header>
      <nav className="flex gap-2 overflow-x-auto border-b border-border bg-surface p-3 lg:hidden" aria-label="Mobile partner navigation">{nav.map(({ page: p, label }) => <Link key={p} to={paths[p]} className={cn("shrink-0 rounded-full px-3 py-1.5 text-xs font-semibold", page === p ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground")}>{label}</Link>)}</nav>
      <main className="space-y-4 p-4 sm:p-6">
        <div><p className="text-[0.625rem] font-bold uppercase text-accent">Pharmacy partner</p><h1 className="font-display text-3xl font-semibold">{nav.find((n) => n.page === page)!.label}</h1><p className="mt-1 text-sm text-muted-foreground">The pharmacy is simulated. No prescription is sent and no pharmacist has seen it.</p></div>
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">{stats.map(([l, v, n]) => <div key={l} className="doctor-panel rounded-xl border border-border bg-surface p-4"><p className="text-xs text-muted-foreground">{l}</p><p className="font-display text-3xl font-semibold text-primary">{v}</p><p className="text-[0.6875rem] text-muted-foreground">{n}</p></div>)}</div>
        {content}
        <p className="flex items-center gap-2 text-xs text-muted-foreground"><X className="size-3" />ThusoIQ connection: sandbox adapter</p>
      </main>
    </div>
  </div><PanicFloating role="Partner" name="Rosebank Community Pharmacy" /></div>;
}
