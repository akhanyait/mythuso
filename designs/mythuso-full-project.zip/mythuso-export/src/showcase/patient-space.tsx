import { Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import {
  Activity, ArrowRight, Award, Bell, BookOpen, BrainCircuit, Building2, Calendar, CalendarDays, CalendarPlus, ChevronDown,
  BarChart3, Captions, Check, ClipboardList, Clock, Download, Droplets, FilePlus2, FileText, Heart, HeartPulse, Home, Leaf, MapPin,
  Maximize2, Menu, MessageCircle, Mic, MicOff, MonitorUp, Paperclip, Phone, PhoneOff, Pill, Plus, Search, Send, Settings, ShieldCheck, Smile,
  Stethoscope, Sun, Syringe, Target, TestTube2, TrendingDown, TrendingUp, Upload, UserRound, Users, Video, VideoOff, Volume2, Wifi, X, Zap,
  AlertTriangle, Apple, Bluetooth, LogOut, RefreshCw, Scale, Smartphone, Watch,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import type { ComponentType } from "react";
import doctorImage from "../assets/photography/careline-doctor.jpg";
import capeTownImage from "../assets/photography/cape-town-care.jpg";
import mythusoWordmark from "../assets/logos/mythuso-logo.png";
import deviceBpImage from "../assets/photography/device-bp-monitor.jpg";
import deviceGlucoseImage from "../assets/photography/device-glucose-meter.jpg";
import deviceWatchImage from "../assets/photography/device-smartwatch.jpg";
import deviceScaleImage from "../assets/photography/device-smart-scale.jpg";
import deviceOxiImage from "../assets/photography/device-pulse-oximeter.jpg";
import { Badge, Button, GilbertOne, IconButton } from "../index";
import { buttonVariants } from "../components/button";
import {
  MyThusoDashboardIcon, MyThusoFamilyIcon, MyThusoHealthIcon, MyThusoMedicationIcon,
  MyThusoMessagesIcon, MyThusoMindIcon, MyThusoQuickIcon, MyThusoResultsIcon,
  MyThusoSettingsIcon, MyThusoVisitIcon,
} from "../components/mythuso-icons";
import { cn } from "../lib/utils";
import { useEffect, useState } from "react";
import { GilbertChatLauncher } from "./gilbert-chat";
import { PanicFloating, PatientVisitTracker } from "./care-safety";
import { MoreDestination, type MorePage } from "./more-pages";
import { supabase } from "../integrations/supabase/client";

type PatientPage = "dashboard" | "health" | "resources" | "book" | "quick-booking" | "mental-health" | "test-results" | "prescriptions" | "records" | "family" | "messages" | "settings" | "consultation" | "appointments" | "wellness" | "health-tips" | "devices" | "visit-tracker" | MorePage;

type PatientPath = "/patient" | "/patient/health" | "/patient/book-appointment" | "/patient/quick-booking" | "/patient/mental-health" | "/patient/test-results" | "/patient/prescriptions" | "/patient/records" | "/patient/family" | "/patient/messages" | "/patient/settings" | "/patient/consultation" | "/patient/appointments" | "/patient/wellness" | "/patient/health-tips" | "/patient/devices" | "/patient/visit-tracker" | `/patient/${MorePage}`;
type IconGraphic = ComponentType<{ className?: string; strokeWidth?: number }>;
type NavItem = { icon: IconGraphic; label: string; to: PatientPath; page: PatientPage; badge?: string; count?: number };
type NavGroup = { label: string; icon: IconGraphic; items: NavItem[] };
const navGroups: NavGroup[] = [
  { label: "Overview", icon: Home, items: [
    { icon: MyThusoDashboardIcon, label: "Dashboard", to: "/patient", page: "dashboard" },
  ] },
  { label: "Care", icon: MyThusoVisitIcon, items: [
    { icon: MyThusoVisitIcon, label: "Book a Visit", to: "/patient/book-appointment", page: "book" },
    { icon: CalendarDays, label: "Appointments", to: "/patient/appointments", page: "appointments" },
    { icon: MyThusoQuickIcon, label: "Quick Booking", to: "/patient/quick-booking", page: "quick-booking", badge: "New" },
    { icon: Bell, label: "Reminders", to: "/patient/reminders", page: "reminders" },
    { icon: MyThusoMessagesIcon, label: "Messages", to: "/patient/messages", page: "messages", count: 2 },
  ] },
  { label: "My Health", icon: MyThusoHealthIcon, items: [
    { icon: MyThusoHealthIcon, label: "Health Overview", to: "/patient/health", page: "health" },
    { icon: Stethoscope, label: "Symptom Checker", to: "/patient/symptom-checker", page: "symptom-checker" },
    { icon: HeartPulse, label: "Risk Assessment", to: "/patient/risk-assessment", page: "risk-assessment" },
    { icon: Syringe, label: "Vaccinations", to: "/patient/vaccinations", page: "vaccinations" },
    { icon: MyThusoResultsIcon, label: "Test Results", to: "/patient/test-results", page: "test-results" },
    { icon: MyThusoMedicationIcon, label: "Prescriptions", to: "/patient/prescriptions", page: "prescriptions" },
    { icon: ClipboardList, label: "Health Timeline", to: "/patient/health-timeline", page: "health-timeline" },
    { icon: FileText, label: "Medical Records", to: "/patient/records", page: "records" },
    { icon: Download, label: "Download & Share", to: "/patient/share-records", page: "share-records" },
  ] },
  { label: "Wellness", icon: Leaf, items: [
    { icon: Leaf, label: "Wellness Overview", to: "/patient/wellness", page: "wellness" },
    { icon: MyThusoMindIcon, label: "Mental Health", to: "/patient/mental-health", page: "mental-health" },
    { icon: Apple, label: "Nutrition & Diet", to: "/patient/nutrition", page: "nutrition" },
    { icon: Activity, label: "Activity Tracking", to: "/patient/activity", page: "activity" },
    { icon: BookOpen, label: "Health Library", to: "/patient/health-library", page: "health-library" },
    { icon: Users, label: "Community Support", to: "/patient/community", page: "community" },
    { icon: BookOpen, label: "Health Tips", to: "/patient/health-tips", page: "health-tips" },
  ] },
  { label: "Devices", icon: Wifi, items: [
    { icon: Wifi, label: "Connected Devices", to: "/patient/devices", page: "devices", count: 1 },
    { icon: Watch, label: "Wearable Sync", to: "/patient/wearables", page: "wearables" },
    { icon: MapPin, label: "Nurse Visit Tracker", to: "/patient/visit-tracker", page: "visit-tracker" },
  ] },
  { label: "Family & Safety", icon: MyThusoFamilyIcon, items: [
    { icon: MyThusoFamilyIcon, label: "Family Care", to: "/patient/family", page: "family" },
    { icon: ShieldCheck, label: "Emergency Information", to: "/patient/emergency-info", page: "emergency-info" },
  ] },
  { label: "Account", icon: MyThusoSettingsIcon, items: [
    { icon: MyThusoSettingsIcon, label: "Settings", to: "/patient/settings", page: "settings" },
  ] },
];

type QuickAction = { icon: IconGraphic; title: string; note: string; to: PatientPath; iconTone: string };
const quickActions: QuickAction[] = [
  { icon: MyThusoVisitIcon, title: "Book a Visit", note: "Find a doctor or clinic", to: "/patient/book-appointment", iconTone: "bg-accent text-accent-foreground" },
  { icon: MyThusoQuickIcon, title: "Quick Booking", note: "Common services", to: "/patient/quick-booking", iconTone: "bg-primary text-primary-foreground" },
  { icon: MyThusoResultsIcon, title: "View Results", note: "Your latest tests", to: "/patient/test-results", iconTone: "bg-highlight/40 text-primary" },
  { icon: MyThusoMedicationIcon, title: "Order Repeat Prescription", note: "Quick and easy", to: "/patient/prescriptions", iconTone: "bg-accent/15 text-accent" },
  { icon: MyThusoMindIcon, title: "Mental Health Support", note: "Talk to someone", to: "/patient/mental-health", iconTone: "bg-coral/15 text-coral" },
];

const overview = [
  { icon: HeartPulse, label: "Blood Pressure", value: "120/80", unit: "mmHg", status: "Normal", values: [118, 122, 116, 121, 119, 125], tone: "text-accent", iconTone: "bg-coral/10 text-coral" },
  { icon: Droplets, label: "Blood Sugar", value: "5.6", unit: "mmol/L", status: "Normal", values: [5.9, 5.4, 5.8, 5.3, 5.5, 5.6], tone: "text-primary", iconTone: "bg-primary/10 text-primary" },
  { icon: UserRound, label: "Weight", value: "68", unit: "kg", status: "Stable", values: [70, 69.5, 70, 69, 68.4, 68], tone: "text-coral", iconTone: "bg-highlight/25 text-primary" },
  { icon: Heart, label: "BMI", value: "24.1", unit: "", status: "Healthy", values: [24.8, 24.6, 24.7, 24.3, 24.2, 24.1], tone: "text-accent", iconTone: "bg-accent/10 text-accent" },
];

const careTeam = [
  { name: "Dr. Ayanda Dlamini", role: "General Practitioner", org: "Rosebank Clinic", action: "Message", image: doctorImage },
  { name: "Sister Naledi Mokoena", role: "Practice Nurse", org: "Rosebank Clinic", action: "Message", initials: "NM" },
  { name: "Rosebank Community Clinic", role: "Primary Care Facility", org: "", action: "Call", initials: "RC" },
] as const;

const quickServices = [
  { icon: HeartPulse, title: "Blood Pressure Check", tone: "bg-coral/10 text-coral" },
  { icon: Droplets, title: "Diabetes Review", tone: "bg-primary/10 text-primary" },
  { icon: Syringe, title: "Vaccination", tone: "bg-accent/10 text-accent" },
  { icon: BrainCircuit, title: "Mental Health Check-in", tone: "bg-primary/10 text-primary" },
  { icon: Heart, title: "Women's Health", tone: "bg-coral/10 text-coral" },
  { icon: Users, title: "Child Health", tone: "bg-accent/10 text-accent" },
  { icon: HeartPulse, title: "Chronic Care Follow-up", tone: "bg-highlight/25 text-primary" },
  { icon: TestTube2, title: "Pathology Test", tone: "bg-primary/10 text-primary" },
] as const;

const recentResults = [
  { icon: FileText, name: "Full Blood Count", date: "12 Mar 2025", tone: "bg-primary/10 text-primary" },
  { icon: Droplets, name: "Cholesterol", date: "12 Mar 2025", tone: "bg-accent/10 text-accent" },
  { icon: TestTube2, name: "HbA1c", date: "12 Mar 2025", tone: "bg-coral/10 text-coral" },
  { icon: ClipboardList, name: "Urinalysis", date: "12 Mar 2025", tone: "bg-highlight/25 text-primary" },
] as const;

const messagePreviews = [
  { name: "Dr. Ayanda Dlamini", note: "Your test results are now available.", time: "10:32", unread: true, image: doctorImage },
  { name: "Rosebank Clinic", note: "Appointment reminder for 26 Jun.", time: "Yesterday", initials: "RC" },
  { name: "Pharmacy", note: "Your prescription is ready.", time: "Wed", initials: "NP" },
  { name: "MyThuso", note: "Tips for managing high blood pressure.", time: "3 Jun", initials: "MT" },
  { name: "Sister Naledi Mokoena", note: "Your weekly check-in is due.", time: "2 Jun", initials: "NM" },
  { name: "Lab Results", note: "HbA1c report is ready to view.", time: "1 Jun", initials: "LR" },
] as const;

const healthTips = [
  { tag: "WELLNESS", title: "5 simple habits for a healthier you", read: "5 min read", image: doctorImage, tone: "bg-accent/10 text-accent" },
  { tag: "NUTRITION", title: "Healthy eating on a budget", read: "4 min read", image: capeTownImage, tone: "bg-coral/10 text-coral" },
  { tag: "FAMILY HEALTH", title: "Keeping your family healthy", read: "6 min read", image: doctorImage, tone: "bg-primary/10 text-primary" },
  { tag: "COMMUNITY", title: "A healthier South Africa", read: "4 min read", image: capeTownImage, tone: "bg-highlight/25 text-primary" },
] as const;

const services = [
  { icon: Pill, title: "Repeat Prescription", note: "Medication", tone: "bg-accent/10 text-accent" },
  { icon: HeartPulse, title: "Blood Pressure Check", note: "Hypertension", tone: "bg-accent/10 text-accent" },
  { icon: TestTube2, title: "Diabetes Review", note: "Glucose & HbA1c", tone: "bg-primary/10 text-primary" },
  { icon: Syringe, title: "Vaccination", note: "Flu, COVID-19, routine", tone: "bg-primary/10 text-primary" },
  { icon: BrainCircuit, title: "Mental Health Check-in", note: "Virtual or in-person", tone: "bg-coral/10 text-coral" },
  { icon: Users, title: "Child Wellness Visit", note: "Growth & development", tone: "bg-highlight/25 text-primary" },
  { icon: Heart, title: "Chronic Care Follow-up", note: "Hypertension, diabetes", tone: "bg-coral/10 text-coral" },
  { icon: ClipboardList, title: "Pathology Test", note: "Blood, urine, etc.", tone: "bg-primary/10 text-primary" },
] as const;

const results = [
  ["Full Blood Count", "17 Mar 2025", "Normal"], ["Cholesterol", "12 Mar 2025", "Normal"],
  ["HbA1c", "10 Mar 2025", "Normal"], ["Urinalysis", "12 Mar 2025", "Normal"],
  ["Liver Function", "03 Mar 2025", "Normal"],
] as const;

const prescriptions = [
  { name: "Amlodipine 5mg", note: "1 tablet daily", doctor: "Dr. Ayanda · 02 Mar 2025", status: "Active" },
  { name: "Metformin 500mg", note: "1 tablet twice daily", doctor: "Dr. Ayanda · 02 Mar 2025", status: "Refill" },
  { name: "Vitamin D3 1000IU", note: "1 tablet daily", doctor: "Prescribed · 26 Feb 2025", status: "Active" },
] as const;

const records = [
  [FileText, "Clinical Summary", "12 Mar 2025"], [TestTube2, "Lab Results", "17 Mar 2025"],
  [ClipboardList, "Radiology Report", "26 Jan 2025"], [Pill, "Prescription History", "2024–2025"],
  [ShieldCheck, "Immunisation Record", "2003–2025"],
] as const;

const family = [
  { initials: "LM", name: "Lerato M.", relation: "Daughter · 12 years" },
  { initials: "SM", name: "Sipho M.", relation: "Child · age 7" },
  { initials: "NM", name: "Nomvula M.", relation: "Mother · 66 years" },
] as const;

const wellbeing = [
  { icon: MessageCircle, title: "Speak to a professional", note: "Book a session", tone: "bg-accent/10 text-accent" },
  { icon: BookOpen, title: "Self-help resources", note: "Articles and tools", tone: "bg-primary/10 text-primary" },
  { icon: Smile, title: "Mood check-in", note: "Track how you're feeling", tone: "bg-highlight/25 text-primary" },
  { icon: Phone, title: "Crisis support", note: "Get help now", tone: "bg-coral/10 text-coral" },
];

type Conversation = { initials: string; name: string; note: string; time: string; unread?: boolean };
const conversations: Conversation[] = [
  { initials: "AD", name: "Dr. Ayanda Dlamini", note: "Your test results look good.", time: "10:52", unread: true },
  { initials: "RC", name: "Rosebank Clinic", note: "Appointment reminder for 26 Jun.", time: "Yesterday" },
  { initials: "NP", name: "Pharmacy", note: "Your prescription is ready.", time: "Wed" },
  { initials: "SM", name: "S. Mokoena", note: "Follow-up on your blood pressure.", time: "10 Jun" },
  { initials: "MT", name: "MyThuso", note: "Welcome to your new patient portal.", time: "1 Jun" },
];

function IconTile({ icon: Icon, tone = "bg-accent/10 text-accent", size = "md" }: { icon: IconGraphic; tone?: string; size?: "sm" | "md" | "lg" }) {
  return <span className={cn("patient-icon-tile flex shrink-0 items-center justify-center rounded-md", size === "sm" ? "size-8" : size === "lg" ? "size-11" : "size-9", tone)}><Icon className={size === "lg" ? "size-5" : "size-4"} /></span>;
}

function SectionHeader({ icon, title, note, action = "View all", tone }: { icon: IconGraphic; title: string; note?: string; action?: string; tone?: string }) {
  return <div className="flex items-start justify-between gap-3"><div className="flex items-center gap-2"><IconTile icon={icon} tone={tone} /><div><h2 className="font-display text-base font-semibold">{title}</h2>{note && <p className="text-xs text-muted-foreground">{note}</p>}</div></div><Button variant="ghost" size="sm" className="px-2 text-primary" trailingIcon={<ArrowRight className="size-3" />}>{action}</Button></div>;
}

function PageTitle({ icon, title, note }: { icon: IconGraphic; title: string; note: string }) {
  return <div className="flex items-start gap-3"><IconTile icon={icon} size="lg" /><div><h1 className="font-display text-2xl font-semibold sm:text-3xl">{title}</h1><p className="mt-1 text-sm text-muted-foreground">{note}</p></div></div>;
}

function HealthCommandChart({ range }: { range: "7D" | "30D" | "6M" }) {
  const sets = {
    "7D": { labels: ["18 Jun", "19 Jun", "20 Jun", "21 Jun", "22 Jun", "23 Jun", "Today"], systolic: [124, 121, 126, 119, 122, 118, 120], diastolic: [82, 80, 84, 78, 81, 79, 80] },
    "30D": { labels: ["26 May", "31 May", "5 Jun", "10 Jun", "15 Jun", "20 Jun", "Today"], systolic: [129, 126, 124, 127, 122, 121, 120], diastolic: [86, 83, 82, 84, 81, 79, 80] },
    "6M": { labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Today"], systolic: [134, 132, 130, 126, 124, 122, 120], diastolic: [89, 88, 86, 84, 83, 81, 80] },
  }[range];
  const w = 720, h = 250, left = 44, right = 690, top = 22, bottom = 210;
  const x = (index: number) => left + (index * (right - left)) / (sets.labels.length - 1);
  const y = (value: number) => bottom - ((value - 60) / 90) * (bottom - top);
  const path = (values: number[]) => values.map((value, index) => `${index ? "L" : "M"}${x(index).toFixed(1)} ${y(value).toFixed(1)}`).join(" ");
  return <div className="health-command-chart mt-5">
    <div className="mb-3 flex flex-wrap items-center gap-4 text-xs font-medium text-muted-foreground"><span className="flex items-center gap-2"><span className="size-2 rounded-full bg-accent" />Systolic</span><span className="flex items-center gap-2"><span className="size-2 rounded-full bg-coral" />Diastolic</span><span className="ml-auto flex items-center gap-2"><span className="h-2 w-5 rounded-sm bg-highlight/30" />Healthy range</span></div>
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full overflow-visible" role="img" aria-label={`Blood pressure trend for the last ${range.toLowerCase()}`}>
      <rect className="health-command-chart__range" x={left} y={y(125)} width={right - left} height={y(75) - y(125)} rx="6" />
      {[60, 80, 100, 120, 140].map((value) => <g key={value}><path className="health-chart__grid" d={`M${left} ${y(value)} H${right}`} /><text className="health-command-chart__label" x="2" y={y(value) + 4}>{value}</text></g>)}
      <path className="health-command-chart__area text-accent" d={`${path(sets.systolic)} L${right} ${bottom} L${left} ${bottom} Z`} />
      <path className="health-chart__line text-accent" pathLength="1" d={path(sets.systolic)} />
      <path className="health-chart__line health-command-chart__line-secondary text-coral" pathLength="1" d={path(sets.diastolic)} />
      {sets.systolic.map((value, index) => <circle key={`s-${sets.labels[index]}`} className="health-chart__point text-accent" cx={x(index)} cy={y(value)} r="4" />)}
      {sets.diastolic.map((value, index) => <circle key={`d-${sets.labels[index]}`} className="health-chart__point text-coral" cx={x(index)} cy={y(value)} r="4" />)}
      <circle className="health-chart__halo text-accent" cx={x(sets.labels.length - 1)} cy={y(120)} r="10" />
      {sets.labels.map((label, index) => <text key={label} className="health-command-chart__label" x={x(index)} y="240" textAnchor="middle">{label}</text>)}
    </svg>
  </div>;
}

function Dashboard() {
  const [range, setRange] = useState<"7D" | "30D" | "6M">("30D");
  return <div className="space-y-5">
    <section className="overflow-hidden rounded-xl border border-accent/10 bg-accent/5 shadow-sm">
      <div className="patient-welcome relative min-h-28 overflow-hidden px-5 py-5 sm:px-6">
        <span className="patient-welcome__mountain patient-welcome__mountain--one" aria-hidden="true" />
        <span className="patient-welcome__mountain patient-welcome__mountain--two" aria-hidden="true" />
        <div className="relative z-10 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div><h1 className="font-display text-3xl font-semibold sm:text-4xl">Good morning, Thandi</h1><p className="mt-1 text-sm text-muted-foreground sm:text-base">Your vitals are stable today. Here is your latest health picture.</p></div>
          <div className="flex items-center gap-5 self-start sm:self-center"><div className="flex items-center gap-2 rounded-full border border-accent/20 bg-surface/80 px-4 py-2.5 text-xs font-semibold text-accent shadow-sm"><span className="status-pulse size-2 rounded-full bg-accent" />Health data up to date</div><p className="hidden max-w-44 rotate-[-3deg] font-display text-xl font-semibold italic leading-tight text-primary xl:block">“A healthier you.<br />Brighter tomorrows.”</p></div>
        </div>
        <Leaf className="absolute -bottom-7 right-8 size-32 rotate-12 text-accent/20" /><Leaf className="absolute -bottom-5 right-44 hidden size-20 -rotate-12 text-highlight/25 xl:block" />
      </div>
      <div className="relative z-10 grid grid-cols-2 gap-4 px-3 pb-3 lg:grid-cols-4" aria-label="Current health readings">{overview.map(({ icon, label, value, unit, status, iconTone }, index) => { const trend = index < 2 ? "Within your range" : index === 2 ? "Down 1.2 kg" : "Healthy range"; const TrendIcon = index === 2 ? TrendingDown : TrendingUp; return <article key={label} className={cn("health-metric min-w-0 rounded-lg border border-border bg-surface p-4 shadow-sm sm:p-5", `health-chart-card--${index + 1}`)}><div className="flex items-start justify-between gap-2"><IconTile icon={icon} tone={iconTone} size="lg" /><Badge variant={index === 0 ? "success" : "neutral"} className="max-sm:px-1.5">{status}</Badge></div><p className="mt-5 font-display text-2xl font-semibold leading-none sm:text-3xl">{value} <span className="text-[0.625rem] font-medium text-muted-foreground sm:text-xs">{unit}</span></p><p className="mt-2 text-xs text-muted-foreground">{label}</p><div className="mt-4 h-1.5 overflow-hidden rounded-full bg-muted"><span className={cn("health-metric__progress block h-full rounded-full", `health-metric__progress--${index + 1}`)} /></div><p className="mt-3 flex items-center gap-1 text-[0.625rem] font-semibold text-success sm:text-[0.6875rem]"><TrendIcon className="size-3 shrink-0" /><span className="truncate">{trend}</span></p></article>; })}</div>
    </section>

    <div className="grid items-stretch gap-4 lg:grid-cols-[minmax(0,3fr)_minmax(0,1fr)]">
      <section aria-label="Next appointment" className="grid min-h-[20rem] overflow-hidden rounded-xl bg-primary text-primary-foreground shadow-sm md:grid-cols-[14rem_minmax(0,1fr)_14rem]">
        <div className="m-4 mb-0 flex min-h-60 items-end justify-center overflow-hidden rounded-lg bg-primary-foreground/10 md:mb-4 md:mr-0 md:min-h-0">
          <img src={doctorImage} alt="Dr. Ayanda Dlamini" className="h-full w-full object-cover object-top" />
        </div>
        <div className="flex min-w-0 flex-col gap-4 p-5 md:px-5 md:py-6">
          <div><span className="inline-flex items-center rounded-full border border-primary-foreground/20 bg-primary-foreground/10 px-3 py-1.5 text-xs font-semibold">Your upcoming appointment</span><h2 className="mt-4 font-display text-2xl font-semibold">Dr. Ayanda Dlamini</h2><p className="mt-1 text-sm text-primary-foreground/70">General Practitioner</p></div>
          <ul className="space-y-3 text-sm"><li className="flex items-center gap-2.5"><Building2 className="size-4 shrink-0 text-highlight" /><span className="min-w-0 truncate">Rosebank Community Clinic</span></li><li className="flex items-center gap-2.5"><MapPin className="size-4 shrink-0 text-highlight" />Consultation Room 2</li><li className="flex items-start gap-2.5"><Stethoscope className="mt-0.5 size-4 shrink-0 text-highlight" /><span>General Consultation<span className="mt-0.5 block text-xs text-primary-foreground/70">Routine check-up and follow-up</span></span></li></ul>
          <Button type="button" variant="ghost" className="mt-auto h-auto justify-start gap-3 rounded-lg bg-primary-foreground/10 p-3 text-left text-primary-foreground hover:bg-primary-foreground/15" trailingIcon={<ArrowRight className="ml-auto size-4 shrink-0" />}><span className="flex size-10 shrink-0 items-center justify-center rounded-md bg-accent text-primary"><CalendarDays className="size-4" /></span><span className="min-w-0"><span className="block text-sm font-bold">Need to reschedule?</span><span className="block truncate text-xs font-normal text-primary-foreground/70">You can change or cancel anytime.</span></span></Button>
        </div>
        <div className="flex min-w-0 flex-col gap-3 border-t border-primary-foreground/15 p-4 md:border-l md:border-t-0 md:py-5">
          <div className="rounded-lg bg-primary-foreground/10 p-3.5"><div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-2"><div><p className="text-xs font-bold uppercase">Wed</p><p className="font-display text-4xl font-semibold leading-none">26</p><p className="mt-1.5 text-xs font-semibold uppercase">Jun 2025</p></div><span className="flex size-10 shrink-0 items-center justify-center rounded-md bg-accent text-primary"><CalendarDays className="size-5" /></span></div><div className="mt-3 border-t border-primary-foreground/15 pt-3"><p className="flex items-center gap-2 text-sm font-semibold"><Clock className="size-4 shrink-0" />10:00 – 10:30</p><p className="mt-1 pl-6 text-xs text-primary-foreground/70">30 minutes</p></div></div>
          <div className="mt-auto space-y-2.5"><Link to="/patient/consultation" className={cn(buttonVariants({ variant: "primary", size: "md" }), "w-full justify-between rounded-full bg-surface text-primary hover:bg-surface/90")}>Join online <Video className="size-4" /></Link><Button variant="ghost" className="w-full rounded-full border border-primary-foreground/30 text-primary-foreground" leadingIcon={<CalendarDays className="size-4" />}>Reschedule</Button></div>
        </div>
      </section>

      <section className="patient-panel rounded-xl border border-border bg-surface p-4 shadow-sm" aria-label="Quick actions">
        <SectionHeader icon={CalendarPlus} title="Quick actions" action="" tone="bg-accent/10 text-accent" />
        <div className="mt-3 space-y-2">{quickActions.map(({ icon, title, note, to, iconTone }) => <Link key={title} to={to} className="patient-action group flex items-center gap-3 rounded-lg border border-border px-3 py-2.5"><IconTile icon={icon} tone={iconTone} /><span className="min-w-0 flex-1"><span className="block text-xs font-bold">{title}</span><span className="block truncate text-[0.6875rem] text-muted-foreground">{note}</span></span><ArrowRight className="size-3.5 shrink-0 text-primary transition-transform group-hover:translate-x-1" /></Link>)}</div>
      </section>
    </div>

    <div className="grid gap-4 lg:grid-cols-[minmax(0,3fr)_minmax(0,1fr)]">
      <div className="space-y-5">
        <div className="health-chart-card rounded-xl border border-border bg-surface p-5 shadow-sm sm:p-6"><div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between"><div className="flex items-center gap-2"><IconTile icon={Activity} tone="bg-accent/10 text-accent" /><div><h2 className="font-display text-lg font-semibold">Blood pressure trend</h2><p className="text-xs text-muted-foreground">Your readings remain inside the healthy range</p></div></div><div className="flex rounded-md bg-muted p-1" aria-label="Chart period">{(["7D", "30D", "6M"] as const).map((item) => <Button key={item} type="button" variant={range === item ? "primary" : "ghost"} size="sm" className="h-7 px-3" onClick={() => setRange(item)} aria-pressed={range === item}>{item}</Button>)}</div></div><HealthCommandChart range={range} /><div className="grid gap-3 border-t border-border pt-4 sm:grid-cols-3"><div className="flex items-center gap-3 rounded-lg border border-border bg-muted/30 p-3"><IconTile icon={HeartPulse} tone="bg-coral/10 text-coral" /><div className="min-w-0"><p className="text-[0.6875rem] text-muted-foreground">Latest reading</p><p className="font-display text-base font-semibold">120/80 <span className="text-xs font-normal text-muted-foreground">mmHg</span></p></div></div><div className="flex items-center gap-3 rounded-lg border border-border bg-muted/30 p-3"><IconTile icon={BarChart3} tone="bg-primary/10 text-primary" /><div className="min-w-0"><p className="text-[0.6875rem] text-muted-foreground">30-day average</p><p className="font-display text-base font-semibold">123/82</p></div></div><div className="flex items-center gap-3 rounded-lg border border-border bg-muted/30 p-3"><IconTile icon={TrendingDown} tone="bg-accent/10 text-accent" /><div className="min-w-0"><p className="text-[0.6875rem] text-muted-foreground">Trend</p><p className="font-display text-base font-semibold text-success">Improving</p></div></div></div></div>

        <div className="grid gap-5 lg:grid-cols-2">
          <section className="patient-panel rounded-xl border border-border bg-surface/90 p-5 shadow-sm"><SectionHeader icon={Zap} title="Quick booking" note="Book common services in seconds." /><div className="mt-4 grid grid-cols-2 gap-2">{quickServices.map(({ icon, title, tone }) => <Link key={title} to="/patient/quick-booking" className="patient-action flex flex-col items-center gap-2 rounded-lg border border-border p-3 text-center"><IconTile icon={icon} tone={tone} size="lg" /><span className="text-xs font-bold leading-tight">{title}</span></Link>)}</div></section>
          <section className="patient-panel rounded-xl border border-border bg-surface/90 p-5 shadow-sm"><SectionHeader icon={TestTube2} title="Recent test results" /><div className="mt-3 divide-y divide-border">{recentResults.map(({ icon, name, date, tone }) => <Link key={name} to="/patient/test-results" className="flex items-center gap-3 py-3"><IconTile icon={icon} tone={tone} size="sm" /><div className="min-w-0 flex-1"><p className="text-sm font-semibold">{name}</p><p className="text-[0.6875rem] text-muted-foreground">{date}</p></div><span className="flex items-center gap-1 text-xs font-semibold text-success"><span className="size-2 rounded-full bg-success" />Normal</span><ArrowRight className="size-3.5 text-muted-foreground" /></Link>)}</div></section>
        </div>

        <section className="patient-panel rounded-xl border border-border bg-surface/90 p-5 shadow-sm"><SectionHeader icon={BrainCircuit} title="Mental health & wellbeing" note="Your mental health matters. Support is always within reach." action="Explore more" /><div className="mt-4 grid gap-3 sm:grid-cols-2">{wellbeing.map(({ icon, title, note, tone }) => <Link key={title} to="/patient/mental-health" className="patient-action flex items-center gap-3 rounded-lg border border-border p-3"><IconTile icon={icon} tone={tone} /><span><span className="block text-sm font-bold">{title}</span><span className="block text-xs text-muted-foreground">{note}</span></span></Link>)}</div></section>
      </div>

      <div className="flex flex-col gap-5">
        <section className="patient-panel rounded-xl border border-border bg-surface p-5 shadow-sm"><SectionHeader icon={Pill} title="Medication today" action="Manage" tone="bg-coral/10 text-coral" /><div className="mt-4 space-y-3">{[["Amlodipine", "5mg · Taken 08:00", true], ["Metformin", "500mg · Due 12:00", false]].map(([name, note, taken]) => <div key={String(name)} className="flex items-center gap-3 rounded-lg border border-border p-3"><span className={cn("flex size-8 shrink-0 items-center justify-center rounded-md", taken ? "bg-accent/10 text-accent" : "bg-coral/10 text-coral")}><Pill className="size-4" /></span><div className="min-w-0 flex-1"><p className="text-xs font-bold">{String(name)}</p><p className="text-[0.625rem] text-muted-foreground">{String(note)}</p></div>{taken ? <span className="flex size-5 shrink-0 items-center justify-center rounded-full bg-success" aria-label="Taken"><Check className="size-3 text-primary-foreground" /></span> : <Button type="button" size="sm" variant="secondary">Take now</Button>}</div>)}</div></section>
        <section className="patient-panel rounded-xl border border-border bg-surface/90 p-5 shadow-sm"><SectionHeader icon={Users} title="My care team" tone="bg-accent/10 text-accent" /><div className="mt-3 divide-y divide-border">{careTeam.map(({ name, role, org, action, ...rest }) => <div key={name} className="flex items-center gap-3 py-3">{"image" in rest ? <img src={rest.image} alt="" className="size-10 rounded-full object-cover object-top" /> : <span className="flex size-10 items-center justify-center rounded-full bg-accent/10 text-xs font-bold text-accent">{rest.initials}</span>}<div className="min-w-0 flex-1"><p className="truncate text-xs font-bold">{name}</p><p className="truncate text-[0.625rem] text-muted-foreground">{role}{org ? ` · ${org}` : ""}</p></div><Button size="sm" variant="ghost" aria-label={`${action} ${name}`}><ArrowRight className="size-4" /></Button></div>)}</div></section>
        <section className="patient-panel rounded-xl border border-border bg-surface/90 p-5 shadow-sm"><SectionHeader icon={MessageCircle} title="Messages" action="View all" /><div className="mt-3 divide-y divide-border">{messagePreviews.map(({ name, note, time, ...rest }) => <Link key={name} to="/patient/messages" className="flex items-center gap-3 py-3">{"image" in rest ? <img src={rest.image} alt="" className="size-9 shrink-0 rounded-full object-cover object-top" /> : <span className="flex size-9 shrink-0 items-center justify-center rounded-full bg-primary/10 text-[0.625rem] font-bold text-primary">{rest.initials}</span>}<div className="min-w-0 flex-1"><p className="truncate text-xs font-bold">{name}</p><p className="truncate text-[0.6875rem] text-muted-foreground">{note}</p></div><span className="shrink-0 text-[0.625rem] text-muted-foreground">{time}</span></Link>)}</div></section>
        <section className="patient-panel flex flex-1 items-center rounded-xl border border-border bg-accent/10 p-5 shadow-sm"><div className="flex w-full items-start gap-4"><GilbertOne className="h-20 w-14" label="" /><div><Badge variant="success">Daily insight</Badge><p className="mt-2 text-sm font-bold">You are trending well</p><p className="mt-1 text-xs leading-relaxed text-muted-foreground">Your average blood pressure improved this month. Keep taking medication as prescribed.</p></div></div></section>
      </div>
    </div>

    <section className="patient-panel rounded-xl border border-border bg-surface/90 p-5 shadow-sm"><SectionHeader icon={Leaf} title="Health tips for you" action="See all" tone="bg-accent/10 text-accent" /><div className="mt-4 grid grid-cols-2 gap-3 lg:grid-cols-4">{healthTips.map(({ tag, title, read, image, tone }) => <article key={title} className="patient-action overflow-hidden rounded-lg border border-border"><img src={image} alt="" className="h-20 w-full object-cover object-top" /><div className="p-3"><Badge variant="neutral" className={cn("text-[0.5625rem]", tone)}>{tag}</Badge><p className="mt-2 text-xs font-bold leading-snug">{title}</p><p className="mt-1.5 flex items-center gap-1 text-[0.625rem] text-muted-foreground"><Clock className="size-3" />{read}</p></div></article>)}</div><div className="mt-4 flex items-center justify-between rounded-lg bg-accent/10 p-4"><p className="font-display text-base font-semibold italic text-primary">"Progress, not perfection."<span className="mt-1 block text-[0.6875rem] font-normal not-italic text-muted-foreground">— A healthier you</span></p><Leaf className="size-8 text-accent" /></div></section>
  </div>;
}

type HealthTab = "overview" | "vitals" | "results" | "medications" | "history" | "goals";

const healthTabs: { id: HealthTab; label: string }[] = [
  { id: "overview", label: "Overview" },
  { id: "vitals", label: "Vitals" },
  { id: "results", label: "Test Results" },
  { id: "medications", label: "Medications" },
  { id: "history", label: "Medical History" },
  { id: "goals", label: "Health Goals" },
];

function MyHealth() {
  const [tab, setTab] = useState<HealthTab>("overview");
  const [range, setRange] = useState<"7D" | "30D" | "6M">("30D");
  return <div className="space-y-5">
    <section className="patient-welcome relative overflow-hidden rounded-xl border border-accent/10 bg-accent/5 px-5 py-5 shadow-sm sm:px-6">
      <span className="patient-welcome__mountain patient-welcome__mountain--one" aria-hidden="true" />
      <span className="patient-welcome__mountain patient-welcome__mountain--two" aria-hidden="true" />
      <div className="relative z-10 grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4">
        <div className="min-w-0"><h1 className="font-display text-3xl font-semibold sm:text-4xl">My Health</h1><p className="mt-1 max-w-2xl text-sm text-muted-foreground">Track your health, understand your progress, and take control of your wellbeing.</p></div>
        <div className="hidden items-center gap-3 sm:flex"><Leaf className="size-12 shrink-0 text-accent/60" /><p className="font-display text-sm font-semibold italic leading-tight text-primary">Small steps.<br />Healthier tomorrows.</p></div>
      </div>
    </section>

    <div className="overflow-x-auto rounded-lg border border-border bg-surface p-1 shadow-sm" role="tablist" aria-label="My Health sections">
      <div className="grid min-w-[42rem] grid-cols-6 gap-1">{healthTabs.map(({ id, label }) => <Button key={id} type="button" role="tab" aria-selected={tab === id} variant={tab === id ? "primary" : "ghost"} size="sm" className="w-full" onClick={() => setTab(id)}>{label}</Button>)}</div>
    </div>

    <div key={tab} className="health-tab-enter">
      {tab === "overview" && <HealthOverview onOpen={setTab} />}
      {tab === "vitals" && <HealthVitals range={range} setRange={setRange} />}
      {tab === "results" && <HealthResults />}
      {tab === "medications" && <HealthMedications />}
      {tab === "history" && <HealthHistory />}
      {tab === "goals" && <HealthGoals />}
    </div>
  </div>;
}

function HealthOverview({ onOpen }: { onOpen: (tab: HealthTab) => void }) {
  return <div className="space-y-5">
    <section className="patient-panel rounded-xl border border-border bg-surface p-5 shadow-sm">
      <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-4"><div><h2 className="font-display text-lg font-semibold">Your latest health stats</h2><p className="text-xs text-muted-foreground">Updated today, 20 Jun 2025</p></div><Badge variant="success" className="shrink-0"><span className="mr-1.5 size-1.5 rounded-full bg-success" />Health data up to date</Badge></div>
      <div className="mt-4 grid grid-cols-2 gap-3 lg:grid-cols-4">{overview.map(({ icon, label, value, unit, status, iconTone }, index) => { const TrendIcon = index === 2 ? TrendingDown : TrendingUp; return <article key={label} className={cn("health-metric rounded-lg border border-border bg-muted/20 p-4", `health-chart-card--${index + 1}`)}><div className="flex items-center justify-between gap-2"><IconTile icon={icon} tone={iconTone} /><Badge variant="success">{status}</Badge></div><p className="mt-4 font-display text-2xl font-semibold">{value}<span className="ml-1 text-[0.625rem] font-medium text-muted-foreground">{unit}</span></p><p className="text-xs text-muted-foreground">{label}</p><div className="mt-3 h-1.5 overflow-hidden rounded-full bg-muted"><span className={cn("health-metric__progress block h-full rounded-full", `health-metric__progress--${index + 1}`)} /></div><p className="mt-2 flex items-center gap-1 text-[0.625rem] font-semibold text-success"><TrendIcon className="size-3" />{index === 2 ? "Down 1.2 kg" : "Within your range"}</p></article>; })}</div>
    </section>
    <section className="grid overflow-hidden rounded-xl bg-primary text-primary-foreground shadow-sm md:grid-cols-[12rem_minmax(0,1fr)_13rem]">
      <div className="m-4 mb-0 min-h-52 overflow-hidden rounded-lg bg-primary-foreground/10 md:mb-4 md:mr-0"><img src={doctorImage} alt="Dr. Ayanda Dlamini" className="h-full w-full object-cover object-top" /></div>
      <div className="p-5"><Badge variant="accent">Your upcoming appointment</Badge><h2 className="mt-3 font-display text-xl font-semibold">Dr. Ayanda Dlamini</h2><p className="text-xs text-primary-foreground/70">General Practitioner</p><div className="mt-4 space-y-2.5 text-xs"><p className="flex gap-2"><Building2 className="size-4 text-highlight" />Rosebank Community Clinic</p><p className="flex gap-2"><MapPin className="size-4 text-highlight" />Consultation Room 2</p><p className="flex gap-2"><Stethoscope className="size-4 text-highlight" />General Consultation</p></div><div className="mt-4 flex items-center gap-2 rounded-lg bg-primary-foreground/10 p-3 text-xs"><CalendarDays className="size-4 text-accent" /><span><strong className="block">Need to reschedule?</strong><span className="text-primary-foreground/70">Change or cancel anytime.</span></span></div></div>
      <div className="m-4 mt-0 flex flex-col rounded-lg bg-primary-foreground/10 p-4 md:ml-0 md:mt-4"><p className="text-xs font-bold uppercase">Wed</p><p className="font-display text-4xl font-semibold">26</p><p className="text-xs font-semibold uppercase">Jun 2025</p><p className="mt-4 flex items-center gap-2 border-t border-primary-foreground/20 pt-4 text-sm font-semibold"><Clock className="size-4" />10:00–10:30</p><p className="pl-6 text-xs text-primary-foreground/70">30 minutes</p><Button className="mt-auto bg-surface text-primary hover:bg-surface/90" trailingIcon={<ArrowRight className="size-4" />}>View appointment</Button><Button variant="ghost" size="sm" className="mt-2 border border-primary-foreground/25 text-primary-foreground">Reschedule</Button></div>
    </section>
    <div className="grid gap-3 sm:grid-cols-3"><Button variant="secondary" onClick={() => onOpen("vitals")} leadingIcon={<Activity className="size-4" />}>Review vitals</Button><Button variant="secondary" onClick={() => onOpen("results")} leadingIcon={<TestTube2 className="size-4" />}>Open test results</Button><Button variant="secondary" onClick={() => onOpen("goals")} leadingIcon={<Target className="size-4" />}>Track health goals</Button></div>
  </div>;
}

function HealthVitals({ range, setRange }: { range: "7D" | "30D" | "6M"; setRange: (range: "7D" | "30D" | "6M") => void }) {
  return <div className="space-y-5"><section className="patient-panel rounded-xl border border-border bg-surface p-5 shadow-sm sm:p-6"><div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between"><div><h2 className="font-display text-2xl font-semibold">Vitals</h2><p className="text-sm text-muted-foreground">Track your vital signs over time.</p></div><Badge variant="success">Health data up to date</Badge></div><div className="mt-5 flex gap-2">{(["7D", "30D", "6M"] as const).map((item) => <Button key={item} size="sm" variant={range === item ? "primary" : "secondary"} onClick={() => setRange(item)}>{item}</Button>)}</div><div className="mt-5 flex items-center gap-2"><IconTile icon={Activity} tone="bg-accent/10 text-accent" /><div><h3 className="font-display text-base font-semibold">Blood pressure trend</h3><p className="text-xs text-muted-foreground">Systolic, diastolic and healthy range</p></div></div><HealthCommandChart range={range} /><div className="grid gap-3 border-t border-border pt-4 sm:grid-cols-3"><HealthStat icon={HeartPulse} label="Latest reading" value="120/80" note="mmHg" tone="bg-coral/10 text-coral" /><HealthStat icon={BarChart3} label="30-day average" value="123/82" tone="bg-primary/10 text-primary" /><HealthStat icon={TrendingDown} label="Trend" value="Improving" tone="bg-accent/10 text-accent" /></div></section><section className="patient-panel rounded-xl border border-border bg-surface p-5 shadow-sm"><h2 className="font-display text-lg font-semibold">Other vitals</h2><div className="mt-4 grid gap-3 sm:grid-cols-3">{overview.slice(1).map(({ icon, label, value, unit, status, iconTone }) => <HealthStat key={label} icon={icon} label={label} value={`${value} ${unit}`} note={status} tone={iconTone} />)}</div></section></div>;
}

function HealthStat({ icon, label, value, note, tone }: { icon: LucideIcon; label: string; value: string; note?: string; tone: string }) { return <div className="health-metric flex items-center gap-3 rounded-lg border border-border bg-muted/20 p-4"><IconTile icon={icon} tone={tone} /><div className="min-w-0"><p className="text-[0.6875rem] text-muted-foreground">{label}</p><p className="font-display text-lg font-semibold">{value}</p>{note && <p className="text-[0.625rem] font-semibold text-success">{note}</p>}</div></div>; }

function HealthResults() { return <section className="patient-panel rounded-xl border border-border bg-surface p-5 shadow-sm sm:p-6"><div className="flex items-start justify-between gap-4"><div><h2 className="font-display text-2xl font-semibold">Test Results</h2><p className="text-sm text-muted-foreground">View your latest test results and track your progress.</p></div><Button variant="ghost" size="sm">View all results</Button></div><div className="mt-5 flex flex-wrap gap-2">{["All", "Blood Tests", "Urine Tests", "Imaging", "Other"].map((label, index) => <Button key={label} size="sm" variant={index === 0 ? "primary" : "secondary"}>{label}</Button>)}</div><div className="mt-5 space-y-3">{recentResults.map(({ icon, name, date, tone }) => <div key={name} className="patient-action grid grid-cols-[auto_minmax(0,1fr)_auto_auto] items-center gap-3 rounded-lg border border-border p-4"><IconTile icon={icon} tone={tone} /><div className="min-w-0"><p className="truncate text-sm font-bold">{name}</p><p className="text-xs text-muted-foreground">{date}</p></div><span className="flex items-center gap-1 text-xs font-semibold text-success"><span className="size-2 rounded-full bg-success" />Normal</span><Button variant="ghost" size="sm">View</Button></div>)}</div><div className="mt-5 grid gap-4 rounded-lg bg-accent/10 p-4 sm:grid-cols-[auto_minmax(0,1fr)_auto] sm:items-center"><IconTile icon={ShieldCheck} tone="bg-accent text-primary" size="lg" /><div><p className="text-sm font-bold">All your results in one place</p><p className="text-xs text-muted-foreground">Track trends, understand your numbers, and share with your doctor.</p></div><Button size="sm" trailingIcon={<ArrowRight className="size-4" />}>View detailed history</Button></div></section>; }

function HealthMedications() { const meds = [["Amlodipine", "5mg · Taken 08:00", true], ["Metformin", "500mg · Due 12:00", false], ["Atorvastatin", "20mg · Taken 08:00", true], ["Vitamin D", "1000 IU · Taken 08:00", true]] as const; return <section className="patient-panel rounded-xl border border-border bg-surface p-5 shadow-sm sm:p-6"><div className="flex items-start justify-between gap-4"><div><h2 className="font-display text-2xl font-semibold">Medications</h2><p className="text-sm text-muted-foreground">Manage your prescriptions and stay on track.</p></div><Button variant="ghost" size="sm">Manage</Button></div><div className="mt-5 flex gap-2"><Button size="sm">Today</Button><Button size="sm" variant="secondary">All Medications</Button><Button size="sm" variant="secondary">Repeat Prescriptions</Button></div><h3 className="mt-6 font-display text-base font-semibold">Today’s medications</h3><div className="mt-3 space-y-3">{meds.map(([name, note, taken], index) => <div key={name} className={cn("patient-action flex items-center gap-3 rounded-lg border p-4", taken ? "border-accent/30 bg-accent/5" : "border-coral/30 bg-coral/5")}><IconTile icon={Pill} tone={index === 3 ? "bg-highlight/25 text-primary" : taken ? "bg-accent/10 text-accent" : "bg-coral/10 text-coral"} /><div className="min-w-0 flex-1"><p className="text-sm font-bold">{name}</p><p className="text-xs text-muted-foreground">{note}</p></div>{taken ? <span className="flex items-center gap-1 text-xs font-semibold text-success"><Check className="size-4" />Taken</span> : <Button size="sm" variant="secondary">Take now</Button>}</div>)}</div><div className="mt-5 flex flex-col gap-3 rounded-lg bg-accent/10 p-4 sm:flex-row sm:items-center"><IconTile icon={FileText} tone="bg-accent text-primary" /><div className="flex-1"><p className="text-sm font-bold">Need a repeat prescription?</p><p className="text-xs text-muted-foreground">Order your repeat prescription quickly and easily.</p></div><Button size="sm" trailingIcon={<ArrowRight className="size-4" />}>Order now</Button></div></section>; }

function HealthHistory() { const events = [["12 Mar", UserRound, "General Consultation", "Dr. Ayanda Dlamini · Rosebank Clinic", "Routine check-up and follow-up"], ["12 Mar", TestTube2, "Blood Tests", "Rosebank Clinic", "Full blood count, cholesterol, HbA1c"], ["15 Jan", Pill, "Medication Review", "Dr. Ayanda Dlamini", "Reviewed chronic medication"], ["3 Oct", Activity, "Diabetes Review", "Dr. Ayanda Dlamini", "Routine diabetes check"], ["12 Jul", ShieldCheck, "Annual Wellness Check", "Dr. Ayanda Dlamini", "General health assessment"]] as const; return <section className="patient-panel rounded-xl border border-border bg-surface p-5 shadow-sm sm:p-6"><h2 className="font-display text-2xl font-semibold">Medical History</h2><p className="text-sm text-muted-foreground">A clear timeline of your care.</p><div className="relative mt-6 space-y-1 before:absolute before:bottom-7 before:left-[4.6rem] before:top-7 before:w-px before:bg-border">{events.map(([date, Icon, title, provider, note], index) => <div key={`${date}-${title}`} className="health-history-item relative grid grid-cols-[3.25rem_auto_minmax(0,1fr)] gap-3 py-4"><p className="pt-2 text-xs font-semibold text-muted-foreground">{date}</p><IconTile icon={Icon} tone={index % 3 === 0 ? "bg-accent/10 text-accent" : index % 3 === 1 ? "bg-primary/10 text-primary" : "bg-coral/10 text-coral"} /><div className="grid gap-2 rounded-lg border border-border p-4 sm:grid-cols-[minmax(0,1fr)_auto]"><div><p className="text-sm font-bold">{title}</p><p className="text-xs text-primary">{provider}</p><p className="mt-1 text-xs text-muted-foreground">{note}</p></div><Button variant="ghost" size="sm">View notes</Button></div></div>)}</div></section>; }

function HealthGoals() { const goals = [[Heart, "Keep blood pressure in range", "120/80 mmHg", "health-goal-progress--1", "bg-accent/10 text-accent", "bg-accent"], [Target, "Maintain healthy weight", "68 kg", "health-goal-progress--2", "bg-primary/10 text-primary", "bg-primary"], [Activity, "Stay active (150 min/week)", "3/5 days", "health-goal-progress--3", "bg-coral/10 text-coral", "bg-coral"], [Leaf, "Eat healthier meals", "4/7 days", "health-goal-progress--4", "bg-highlight/25 text-primary", "bg-highlight"]] as const; return <div className="space-y-5"><section className="patient-panel rounded-xl border border-border bg-surface p-5 shadow-sm sm:p-6"><div className="flex items-start justify-between gap-4"><div><h2 className="font-display text-2xl font-semibold">Health Goals</h2><p className="text-sm text-muted-foreground">Build healthy habits one achievable step at a time.</p></div><Button size="sm" leadingIcon={<Plus className="size-4" />}>New goal</Button></div><div className="mt-6 space-y-3">{goals.map(([Icon, title, value, progressClass, iconTone, barTone]) => <article key={title} className="patient-action flex items-center gap-4 rounded-lg border border-border p-4"><IconTile icon={Icon} tone={iconTone} size="lg" /><div className="min-w-0 flex-1"><div className="flex items-center justify-between gap-3"><p className="text-sm font-bold">{title}</p><Badge variant="success">On track</Badge></div><div className="mt-3 h-2 overflow-hidden rounded-full bg-muted"><span className={cn("health-goal-progress block h-full rounded-full", progressClass, barTone)} /></div></div><p className="hidden shrink-0 text-xs font-semibold text-muted-foreground sm:block">{value}</p></article>)}</div></section><section className="patient-panel overflow-hidden rounded-xl border border-accent/20 bg-accent/10 p-5 shadow-sm"><div className="grid grid-cols-[auto_minmax(0,1fr)] items-center gap-4"><span className="flex size-14 items-center justify-center rounded-lg bg-accent text-primary"><Award className="size-7" /></span><div><p className="font-display text-lg font-semibold">You’re making great progress!</p><p className="text-sm text-muted-foreground">Small steps lead to big results. Keep going!</p></div></div></section></div>; }

const practitioners = [
  { name: "Dr. Ayanda Dlamini", role: "General Practitioner", place: "Rosebank Community Clinic", distance: "1.8 km", image: doctorImage, initials: "AD" },
  { name: "Sister Naledi Mokoena", role: "Practice Nurse", place: "Rosebank Community Clinic", distance: "1.8 km", initials: "NM" },
  { name: "Dr. Thabo Nkosi", role: "Family Physician", place: "Sandton Medical Centre", distance: "2.8 km", image: capeTownImage, initials: "TN" },
  { name: "Dr. Lerato Khumalo", role: "General Practitioner", place: "Alexandra Community Health Centre", distance: "3.8 km", initials: "LK" },
];
const bookingSteps = ["Service", "Practitioner", "Date & time", "Confirm"];
const bookingTimes = ["08:30", "09:15", "10:00", "11:30", "13:00", "14:15", "15:30", "16:45"];

function BookAppointment() {
  const [step, setStep] = useState(0);
  const [query, setQuery] = useState("");
  const [service, setService] = useState<string | null>(null);
  const [practitioner, setPractitioner] = useState<string | null>(null);
  const [mode, setMode] = useState<"In person" | "Video">("In person");
  const [day, setDay] = useState(0);
  const [time, setTime] = useState<string | null>(null);
  const [reason, setReason] = useState("");
  const [booked, setBooked] = useState(false);
  const days = Array.from({ length: 7 }, (_, i) => { const d = new Date(); d.setDate(d.getDate() + i + 1); return d; });
  const dayLabel = (d: Date, opts: Intl.DateTimeFormatOptions) => d.toLocaleDateString("en-ZA", opts);
  const filtered = services.filter((s) => `${s.title} ${s.note}`.toLowerCase().includes(query.toLowerCase()));
  const chosenDoc = practitioners.find((p) => p.name === practitioner);
  const canNext = [!!service, !!practitioner, !!time, true][step];
  const reset = () => { setStep(0); setService(null); setPractitioner(null); setTime(null); setReason(""); setDay(0); setBooked(false); };
  const panel = "patient-panel rounded-xl border border-border bg-surface p-5";

  if (booked && chosenDoc) return <div className="space-y-5"><PageTitle icon={CalendarDays} title="Appointment confirmed" note="We’ve sent the details to your phone and email." /><section className={cn(panel, "text-center")}><span className="mx-auto flex size-14 items-center justify-center rounded-full bg-accent/15 text-accent"><Check className="size-7" /></span><h2 className="mt-4 font-display text-xl font-semibold">You’re booked with {chosenDoc.name}</h2><p className="mt-1 text-sm text-muted-foreground">{service} · {mode} · {dayLabel(days[day], { weekday: "long", day: "numeric", month: "long" })} at {time}</p><p className="text-sm text-muted-foreground">{mode === "Video" ? "Join from your dashboard 5 minutes early." : chosenDoc.place}</p><div className="mt-5 flex flex-wrap justify-center gap-2"><Link to="/patient" className={buttonVariants({ variant: "primary", size: "md" })}>Back to dashboard</Link><Button variant="secondary" onClick={reset}>Book another visit</Button></div></section></div>;

  return <div className="space-y-5"><PageTitle icon={CalendarDays} title="Book an appointment" note="Find and book with trusted healthcare professionals." />
    <section className={panel}><ol className="grid grid-cols-4 gap-2" aria-label="Booking progress">{bookingSteps.map((label, index) => <li key={label} className="text-center" aria-current={index === step ? "step" : undefined}><button type="button" disabled={index > step} onClick={() => setStep(index)} className="mx-auto block disabled:cursor-default"><span className={cn("mx-auto flex size-7 items-center justify-center rounded-full text-xs font-bold transition-colors", index < step ? "bg-accent text-accent-foreground" : index === step ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground")}>{index < step ? <Check className="size-4" /> : index + 1}</span><span className="mt-1 block text-[0.625rem] font-semibold">{label}</span></button></li>)}</ol></section>

    {step === 0 && <section className={panel}><label className="text-sm font-semibold" htmlFor="provider-search">What care do you need?</label><div className="relative mt-2"><Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" /><input id="provider-search" value={query} onChange={(e) => setQuery(e.target.value)} className="h-11 w-full rounded-md border border-input bg-muted/40 pl-10 pr-3 text-sm" placeholder="Search for services" /></div><div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{filtered.map(({ icon, title, note, tone }) => <button key={title} type="button" aria-pressed={service === title} onClick={() => setService(title)} className={cn("patient-action flex items-center gap-3 rounded-lg border p-4 text-left", service === title ? "border-accent bg-accent/5 ring-2 ring-accent/30" : "border-border")}><IconTile icon={icon} tone={tone} size="lg" /><span className="min-w-0"><span className="block text-sm font-bold">{title}</span><span className="block text-xs text-muted-foreground">{note}</span></span></button>)}{filtered.length === 0 && <p className="text-sm text-muted-foreground">No services match “{query}”.</p>}</div></section>}

    {step === 1 && <section className={panel}><SectionHeader icon={Stethoscope} title="Choose a practitioner" /><div className="mt-4 grid gap-3 md:grid-cols-2">{practitioners.map((p) => <button key={p.name} type="button" aria-pressed={practitioner === p.name} onClick={() => setPractitioner(p.name)} className={cn("patient-action flex items-center gap-3 rounded-lg border p-4 text-left", practitioner === p.name ? "border-accent bg-accent/5 ring-2 ring-accent/30" : "border-border")}>{p.image ? <img src={p.image} alt="" className="size-14 rounded-lg object-cover object-top" /> : <span className="flex size-14 items-center justify-center rounded-lg bg-primary/10 font-bold text-primary">{p.initials}</span>}<span className="min-w-0"><span className="block text-sm font-bold">{p.name}</span><span className="block text-xs text-muted-foreground">{p.role}</span><span className="block text-xs text-accent"><MapPin className="mr-1 inline size-3" />{p.place} · {p.distance}</span></span></button>)}</div></section>}

    {step === 2 && <section className={panel}><SectionHeader icon={Clock} title="Pick a date and time" /><div className="mt-4 flex gap-2" role="group" aria-label="Visit type">{(["In person", "Video"] as const).map((m) => <Button key={m} size="sm" variant={mode === m ? "primary" : "secondary"} aria-pressed={mode === m} onClick={() => setMode(m)} leadingIcon={m === "Video" ? <Video className="size-4" /> : <MapPin className="size-4" />}>{m}</Button>)}</div><div className="mt-4 grid grid-cols-4 gap-2 sm:grid-cols-7">{days.map((d, i) => <button key={i} type="button" aria-pressed={day === i} onClick={() => { setDay(i); setTime(null); }} className={cn("rounded-lg border p-2 text-center", day === i ? "border-primary bg-primary text-primary-foreground" : "border-border hover:bg-muted")}><span className="block text-[0.625rem] font-semibold uppercase">{dayLabel(d, { weekday: "short" })}</span><span className="block font-display text-lg font-semibold">{d.getDate()}</span></button>)}</div><div className="mt-4 grid grid-cols-3 gap-2 sm:grid-cols-4">{bookingTimes.map((t, i) => { const full = (i + day) % 5 === 0; return <button key={t} type="button" disabled={full} aria-pressed={time === t} onClick={() => setTime(t)} className={cn("h-10 rounded-md border text-sm font-semibold disabled:cursor-not-allowed disabled:line-through disabled:opacity-40", time === t ? "border-accent bg-accent text-accent-foreground" : "border-border hover:bg-muted")}>{t}</button>; })}</div></section>}

    {step === 3 && chosenDoc && <section className={panel}><SectionHeader icon={ClipboardList} title="Review and confirm" /><dl className="mt-4 grid gap-3 sm:grid-cols-2">{[["Service", service], ["Practitioner", `${chosenDoc.name} · ${chosenDoc.role}`], ["When", `${dayLabel(days[day], { weekday: "long", day: "numeric", month: "long" })} at ${time}`], ["Where", mode === "Video" ? "Video consultation" : chosenDoc.place]].map(([k, v]) => <div key={k} className="rounded-lg border border-border bg-muted/20 p-3"><dt className="text-xs text-muted-foreground">{k}</dt><dd className="text-sm font-bold">{v}</dd></div>)}</dl><label htmlFor="visit-reason" className="mt-4 block text-sm font-semibold">Reason for visit (optional)</label><textarea id="visit-reason" value={reason} maxLength={500} onChange={(e) => setReason(e.target.value)} className="mt-2 min-h-24 w-full rounded-md border border-input bg-surface p-3 text-sm" placeholder="Briefly describe your symptoms or what you’d like to discuss" /></section>}

    <div className="flex justify-between gap-3"><Button variant="secondary" disabled={step === 0} onClick={() => setStep(step - 1)}>Back</Button>{step < 3 ? <Button disabled={!canNext} onClick={() => setStep(step + 1)} trailingIcon={<ArrowRight className="size-4" />}>Continue</Button> : <Button onClick={() => setBooked(true)} leadingIcon={<Check className="size-4" />}>Confirm booking</Button>}</div>
  </div>;
}

function QuickBooking() { return <div className="space-y-5"><PageTitle icon={Calendar} title="Quick booking" note="Book common services in seconds." /><section className="patient-panel rounded-xl border border-border bg-surface p-5"><div className="relative"><Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" /><input className="h-11 w-full rounded-md border border-input bg-muted/40 pl-10 pr-3 text-sm" placeholder="Search for a service..." /></div><div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{services.map(({ icon, title, note, tone }) => <button key={title} type="button" className="patient-action flex items-center gap-3 rounded-lg border border-border p-4 text-left"><IconTile icon={icon} tone={tone} size="lg" /><span><span className="block text-sm font-bold">{title}</span><span className="block text-xs text-muted-foreground">{note}</span></span></button>)}</div></section><section className="patient-panel rounded-xl border border-border bg-surface p-5"><SectionHeader icon={Clock} title="Recent quick bookings" /><div className="mt-3 divide-y divide-border">{services.slice(0, 3).map(({ icon, title, note, tone }, i) => <div key={title} className="flex items-center gap-3 py-3"><IconTile icon={icon} tone={tone} /><div className="flex-1"><p className="text-sm font-bold">{title}</p><p className="text-xs text-muted-foreground">{note} · {i + 2} Jun 2025</p></div><Button size="sm" variant="secondary">Book again</Button></div>)}</div></section></div>; }

function MentalHealth() { return <div className="space-y-5"><PageTitle icon={BrainCircuit} title="Mental health & wellbeing" note="You are not alone. Support is always within reach." /><section className="patient-panel relative overflow-hidden rounded-xl border border-border bg-surface p-6 sm:p-8"><img src={doctorImage} alt="" className="absolute inset-y-0 right-0 hidden w-2/5 object-cover object-top opacity-80 md:block" /><div className="relative max-w-xl"><Badge variant="success">Available now</Badge><h2 className="mt-3 font-display text-3xl font-semibold">A healthier mind.<br />A brighter you.</h2><p className="mt-3 text-sm text-muted-foreground">Get support, guidance and tools for everyday life.</p><Button className="mt-5">Book a session</Button></div></section><section className="patient-panel rounded-xl border border-border bg-surface p-5"><h2 className="font-display text-lg font-semibold">How are you feeling today?</h2><div className="mt-4 grid grid-cols-5 gap-2">{[["Great","bg-accent/10"],["Good","bg-accent/10"],["Okay","bg-highlight/25"],["Low","bg-coral/10"],["Struggling","bg-coral/10"]].map(([label,tone]) => <button key={label} className={cn("rounded-lg p-3 text-xs font-semibold", tone)} type="button"><Smile className="mx-auto mb-2 size-5" />{label}</button>)}</div></section><section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{[[MessageCircle,"Talk to a therapist","Book a virtual or in-person session"],[ShieldCheck,"Crisis support","Get immediate help"],[Leaf,"Self-help tools","Guided programmes"],[BookOpen,"Mindfulness","Breathing and stress relief"]].map(([Icon,title,note]) => { const I=Icon as LucideIcon; return <button key={String(title)} className="patient-panel rounded-xl border border-border bg-surface p-5 text-left" type="button"><IconTile icon={I} /><p className="mt-3 text-sm font-bold">{String(title)}</p><p className="mt-1 text-xs text-muted-foreground">{String(note)}</p></button>; })}</section></div>; }

function TestResults() { return <div className="space-y-5"><PageTitle icon={TestTube2} title="Test results" note="Understand your health. Take the next step." /><section className="patient-panel rounded-xl border border-border bg-surface p-5"><div className="flex gap-5 border-b border-border text-xs font-semibold"><span className="border-b-2 border-accent pb-3 text-primary">Latest results</span><span className="pb-3 text-muted-foreground">Trends</span><span className="pb-3 text-muted-foreground">Explanations</span></div><div className="divide-y divide-border">{results.map(([name,date,status]) => <div key={name} className="flex items-center gap-3 py-4"><IconTile icon={TestTube2} tone="bg-primary/10 text-primary" /><div className="flex-1"><p className="text-sm font-bold">{name}</p><p className="text-xs text-muted-foreground">{date}</p></div><span className="flex items-center gap-1 text-xs font-semibold text-success"><span className="size-2 rounded-full bg-success" />{status}</span><Button variant="ghost" size="sm">View</Button></div>)}</div><div className="mt-3 flex items-center gap-3 rounded-lg bg-primary/5 p-4"><GilbertOne className="h-14 w-10" label="" /><div className="flex-1"><p className="text-sm font-bold">Need help understanding your results?</p><p className="text-xs text-muted-foreground">Ask GilbertOne for a plain-language explanation.</p></div><Button size="sm">Ask a question</Button></div></section><section className="patient-panel rounded-xl border border-border bg-surface p-5"><SectionHeader icon={HeartPulse} title="Blood sugar trend" action="Last 6 months" /><div className="mt-4 h-52"><svg viewBox="0 0 600 180" preserveAspectRatio="none" className="health-chart h-full w-full text-accent" role="img" aria-label="Blood sugar trend from January to June"><path className="health-chart__grid" d="M30 25 H570 M30 70 H570 M30 115 H570 M30 155 H570" /><path className="health-chart__area" d="M30 92 C110 106 150 116 220 96 S350 101 420 82 S510 90 570 63 L570 155 L30 155 Z" /><path className="health-chart__line" pathLength="1" d="M30 92 C110 106 150 116 220 96 S350 101 420 82 S510 90 570 63" /><circle className="health-chart__point" cx="570" cy="63" r="5" /></svg></div></section></div>; }

function Prescriptions() { return <div className="space-y-5"><PageTitle icon={Pill} title="Prescriptions" note="Manage your medication with ease." /><section className="patient-panel rounded-xl border border-border bg-surface p-5"><div className="flex gap-5 border-b border-border text-xs font-semibold"><span className="border-b-2 border-accent pb-3 text-primary">Current</span><span className="pb-3 text-muted-foreground">Past</span><span className="pb-3 text-muted-foreground">Request history</span></div><div className="divide-y divide-border">{prescriptions.map(({name,note,doctor,status}) => <div key={name} className="flex items-center gap-3 py-4"><IconTile icon={Pill} tone="bg-primary/10 text-primary" /><div className="flex-1"><p className="text-sm font-bold">{name}</p><p className="text-xs text-muted-foreground">{note}</p><p className="text-[0.6875rem] text-muted-foreground">{doctor}</p></div><div className="text-right"><Badge variant={status === "Active" ? "success" : "neutral"}>{status}</Badge>{status === "Refill" && <Button size="sm" className="mt-2 block">Refill</Button>}</div></div>)}</div><Button variant="secondary" className="mt-4 w-full" leadingIcon={<Plus className="size-4" />}>Request a new prescription</Button></section><section className="patient-panel flex items-center gap-4 rounded-xl border border-border bg-accent/10 p-5"><IconTile icon={Pill} size="lg" /><div className="flex-1"><h2 className="font-display text-lg font-semibold">Pharmacy delivery</h2><p className="text-xs text-muted-foreground">Get medication delivered to your home.</p></div><Button size="sm">Learn more</Button></section></div>; }

function MedicalRecords() { return <div className="space-y-5"><PageTitle icon={FileText} title="Medical records" note="Your health history, all in one place." /><section className="patient-panel rounded-xl border border-border bg-surface p-5"><div className="flex gap-5 overflow-x-auto border-b border-border text-xs font-semibold"><span className="whitespace-nowrap border-b-2 border-accent pb-3 text-primary">Documents</span><span className="whitespace-nowrap pb-3 text-muted-foreground">Visit history</span><span className="whitespace-nowrap pb-3 text-muted-foreground">Immunisations</span><span className="whitespace-nowrap pb-3 text-muted-foreground">Shared records</span></div><div className="divide-y divide-border">{records.map(([Icon,name,date]) => <div key={name} className="flex items-center gap-3 py-4"><IconTile icon={Icon} tone="bg-primary/10 text-primary" /><div className="flex-1"><p className="text-sm font-bold">{name}</p><p className="text-xs text-muted-foreground">{date}</p></div><Button variant="ghost" size="sm">View</Button><Button variant="ghost" size="sm" aria-label={`Download ${name}`}><Download className="size-4" /></Button></div>)}</div><Button variant="secondary" className="mt-4 w-full" leadingIcon={<Upload className="size-4" />}>Upload a document</Button></section></div>; }

function FamilyCare() { return <div className="space-y-5"><PageTitle icon={Users} title="Family care" note="Manage the health of those you love." /><section className="patient-panel rounded-xl border border-border bg-surface p-5"><div className="flex items-center justify-between"><h2 className="font-display text-lg font-semibold">Family members</h2><Button size="sm" leadingIcon={<Plus className="size-4" />}>Add member</Button></div><div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{family.map(({initials,name,relation}) => <article key={name} className="patient-action rounded-lg border border-border p-4"><span className="flex size-11 items-center justify-center rounded-full bg-accent/10 text-xs font-bold text-accent">{initials}</span><p className="mt-3 text-sm font-bold">{name}</p><p className="text-xs text-muted-foreground">{relation}</p><Button variant="ghost" size="sm" className="mt-2 px-0">View profile</Button></article>)}</div></section><section className="patient-panel relative overflow-hidden rounded-xl border border-border bg-surface p-6"><img src={capeTownImage} alt="" className="absolute inset-y-0 right-0 hidden w-2/5 object-cover sm:block" /><div className="relative max-w-md"><h2 className="font-display text-2xl font-semibold">Care together.<br />Grow healthier.</h2><p className="mt-2 text-sm text-muted-foreground">Manage appointments, track health and support the people you love.</p></div></section></div>; }

function Messages() { return <div className="space-y-5"><PageTitle icon={MessageCircle} title="Messages" note="Connect with your care team." /><section className="patient-panel grid min-h-[560px] overflow-hidden rounded-xl border border-border bg-surface md:grid-cols-[20rem_1fr]"><div className="border-b border-border md:border-b-0 md:border-r"><div className="p-4"><div className="relative"><Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" /><input className="h-10 w-full rounded-md border border-input bg-muted/40 pl-10 pr-3 text-sm" placeholder="Search messages" /></div></div>{conversations.map((item,index) => <button key={item.name} type="button" className={cn("flex w-full items-center gap-3 border-t border-border p-4 text-left", index === 0 && "bg-accent/10")}><span className="flex size-9 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary">{item.initials}</span><span className="min-w-0 flex-1"><span className="flex justify-between gap-2"><span className="truncate text-xs font-bold">{item.name}</span><span className="text-[0.625rem] text-muted-foreground">{item.time}</span></span><span className="block truncate text-[0.6875rem] text-muted-foreground">{item.note}</span></span>{item.unread && <span className="size-2 rounded-full bg-coral" />}</button>)}</div><div className="flex min-h-96 flex-col"><div className="flex items-center gap-3 border-b border-border p-4"><img src={doctorImage} alt="" className="size-10 rounded-full object-cover object-top" /><div className="flex-1"><p className="text-sm font-bold">Dr. Ayanda Dlamini</p><p className="text-xs text-success">Available</p></div><Link to="/patient/consultation" aria-label="Start video call" title="Start video call" className={buttonVariants({variant:"ghost",size:"sm"})}><Video className="size-4" /></Link><Button variant="ghost" size="sm" aria-label="Start phone call"><Phone className="size-4" /></Button></div><div className="flex flex-1 flex-col justify-end gap-3 bg-muted/30 p-5"><div className="max-w-sm rounded-lg bg-surface p-3 text-xs shadow-sm">Good morning, Thandi. Your latest results are within the normal range.</div><div className="ml-auto max-w-sm rounded-lg bg-primary p-3 text-xs text-primary-foreground">Thank you, Doctor. Should I continue with my current medication?</div><div className="max-w-sm rounded-lg bg-surface p-3 text-xs shadow-sm">Yes, please continue as prescribed. We can review it at your appointment on Wednesday.</div></div><div className="flex gap-2 border-t border-border p-4"><Button variant="ghost" size="sm" aria-label="Attach file"><Paperclip className="size-4" /></Button><input className="h-10 flex-1 rounded-md border border-input px-3 text-sm" placeholder="Type a message..." /><Button size="sm" aria-label="Send message"><Send className="size-4" /></Button></div></div></section></div>; }

type ProfileForm = { display_name: string; email: string; phone: string; id_number: string; address: string; language: string; email_notifications: boolean; sms_notifications: boolean };
const fallbackProfile: ProfileForm = { display_name: "Thandi Mokoena", email: "thandi@email.co.za", phone: "+27 82 123 4567", id_number: "800101 0454 08 9", address: "Johannesburg, Gauteng", language: "English", email_notifications: true, sms_notifications: true };

function SettingsPage() {
  const [profile, setProfile] = useState(fallbackProfile);
  const [userId, setUserId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  useEffect(() => {
    void supabase.auth.getUser().then(async ({ data }) => {
      if (!data.user) return;
      setUserId(data.user.id);
      const email = data.user.email ?? fallbackProfile.email;
      const { data: stored } = await supabase.from("profiles").select("display_name, phone, id_number, address, language, email_notifications, sms_notifications").eq("id", data.user.id).maybeSingle();
      if (stored) setProfile({ ...stored, email });
      else setProfile((current) => ({ ...current, display_name: data.user.user_metadata?.display_name ?? current.display_name, email }));
    });
  }, []);
  const update = <K extends keyof ProfileForm>(key: K, value: ProfileForm[K]) => setProfile((current) => ({ ...current, [key]: value }));
  const save = async () => {
    if (!userId) { setMessage("Sign in to save profile changes."); return; }
    setSaving(true); setMessage("");
    const { email: _email, ...values } = profile;
    const { error } = await supabase.from("profiles").upsert({ id: userId, ...values });
    setMessage(error ? "We could not save your changes. Please try again." : "Profile changes saved.");
    setSaving(false);
  };
  return <div className="space-y-5"><PageTitle icon={Settings} title="Settings" note="Manage your profile and preferences." /><section className="patient-panel rounded-xl border border-border bg-surface p-5"><div className="flex gap-5 overflow-x-auto border-b border-border text-xs font-semibold"><span className="whitespace-nowrap border-b-2 border-accent pb-3 text-primary">Profile</span><span className="whitespace-nowrap pb-3 text-muted-foreground">Preferences</span><span className="whitespace-nowrap pb-3 text-muted-foreground">Privacy</span><span className="whitespace-nowrap pb-3 text-muted-foreground">Security</span></div><div className="mt-5 flex items-center gap-4"><img src={doctorImage} alt={profile.display_name} className="size-16 rounded-full object-cover object-top" /><div><p className="font-display text-lg font-semibold">{profile.display_name}</p><p className="text-xs text-muted-foreground">Patient</p><Button variant="ghost" size="sm" className="mt-1 px-0">Change photo</Button></div></div><form className="mt-6 grid gap-4 sm:grid-cols-2" onSubmit={(event) => { event.preventDefault(); void save(); }}>{([['display_name','Full name'],['email','Email'],['phone','Phone'],['id_number','ID number'],['address','Address'],['language','Language']] as const).map(([key, label]) => <label key={key} className="text-xs font-semibold">{label}<input value={profile[key]} disabled={key === 'email'} onChange={(event) => update(key, event.target.value)} className="mt-1.5 h-10 w-full rounded-md border border-input bg-surface px-3 text-sm font-normal disabled:bg-muted disabled:text-muted-foreground" /></label>)}</form><div className="mt-6 divide-y divide-border border-y border-border"><label className="flex items-center justify-between py-4 text-sm font-semibold">Email notifications<input type="checkbox" checked={profile.email_notifications} onChange={(event) => update("email_notifications", event.target.checked)} className="size-4 accent-accent" /></label><label className="flex items-center justify-between py-4 text-sm font-semibold">SMS notifications<input type="checkbox" checked={profile.sms_notifications} onChange={(event) => update("sms_notifications", event.target.checked)} className="size-4 accent-accent" /></label></div><div className="mt-5 flex items-center gap-3"><Button loading={saving} onClick={() => void save()}>Save changes</Button>{message && <p role="status" className="text-xs font-semibold text-muted-foreground">{message}</p>}</div></section></div>;
}

function OnlineConsultation() {
  const [micOn, setMicOn] = useState(true);
  const [cameraOn, setCameraOn] = useState(true);
  const [captionsOn, setCaptionsOn] = useState(false);
  const [ended, setEnded] = useState(false);
  const [seconds, setSeconds] = useState(255);
  useEffect(() => {
    if (ended) return;
    const timer = window.setInterval(() => setSeconds((value) => value + 1), 1000);
    return () => window.clearInterval(timer);
  }, [ended]);
  const elapsed = `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
  const toggleFullscreen = () => {
    const stage = document.getElementById("consultation-stage");
    if (stage?.requestFullscreen) void stage.requestFullscreen();
  };
  return <div className="space-y-4">
    <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <PageTitle icon={Video} title="Online consultation" note="Secure video visit with your care team." />
      <div className="flex items-center gap-2 self-start rounded-full border border-success/25 bg-accent/10 px-3 py-2 text-xs font-semibold text-success"><span className="status-pulse size-2 rounded-full bg-success" />Encrypted connection</div>
    </div>
    <div className="consultation-layout grid gap-4 xl:grid-cols-[minmax(0,1fr)_19rem]">
      <section id="consultation-stage" className="consultation-stage relative isolate min-h-[34rem] overflow-hidden rounded-xl bg-primary text-primary-foreground shadow-md sm:min-h-[42rem]">
        {cameraOn && !ended ? <img src={doctorImage} alt="Dr. Ayanda Dlamini on video" className="absolute inset-0 h-full w-full object-cover object-top" /> : <div className="absolute inset-0 grid place-items-center bg-primary"><div className="text-center"><span className="mx-auto flex size-20 items-center justify-center rounded-full bg-primary-foreground/10 font-display text-2xl font-semibold">AD</span><p className="mt-3 text-sm text-primary-foreground/70">{ended ? "Consultation ended" : "Camera is off"}</p></div></div>}
        <div className="consultation-shade absolute inset-0" aria-hidden="true" />
        <div className="absolute left-4 top-4 flex flex-wrap items-center gap-2 sm:left-5 sm:top-5"><span className="flex items-center gap-2 rounded-full bg-primary/80 px-3 py-2 text-xs font-semibold backdrop-blur"><span className={cn("size-2 rounded-full", ended ? "bg-muted-foreground" : "status-pulse bg-coral")} />{ended ? "Call complete" : `Live · ${elapsed}`}</span><span className="hidden items-center gap-1.5 rounded-full bg-primary/80 px-3 py-2 text-xs font-medium backdrop-blur sm:flex"><Wifi className="size-3.5 text-highlight" />Excellent connection</span></div>
        <div className="absolute right-3 top-3 grid h-32 w-24 place-items-center overflow-hidden rounded-lg border-2 border-primary-foreground/80 bg-surface shadow-md sm:right-5 sm:top-5 sm:h-44 sm:w-32"><span className={cn("flex size-12 items-center justify-center rounded-full bg-accent/10 text-sm font-bold text-primary", !cameraOn && "opacity-45")}>TM</span><span className="absolute bottom-1.5 left-1.5 rounded-sm bg-primary/75 px-1.5 py-1 text-[0.5625rem] font-semibold text-primary-foreground">{cameraOn ? "You" : "Camera off"}</span></div>
        <div className="absolute bottom-28 left-4 right-4 sm:bottom-32 sm:left-6"><p className="font-display text-2xl font-semibold sm:text-3xl">Dr. Ayanda Dlamini</p><p className="mt-1 text-sm text-primary-foreground/80">General Practitioner · Rosebank Community Clinic</p>{captionsOn && !ended && <p className="mt-4 max-w-xl rounded-md bg-primary/80 px-4 py-3 text-sm leading-relaxed backdrop-blur">“Your blood pressure readings look stable. Let’s review how you’ve been feeling this week.”</p>}</div>
        <div className="absolute inset-x-0 bottom-0 flex items-center justify-center gap-2 border-t border-primary-foreground/10 bg-primary/75 px-3 py-4 backdrop-blur sm:gap-3 sm:py-5">
          <IconButton label={micOn ? "Mute microphone" : "Turn on microphone"} aria-pressed={!micOn} onClick={() => setMicOn((value) => !value)} className={cn("rounded-full border border-primary-foreground/20 bg-primary-foreground/10 text-primary-foreground hover:bg-primary-foreground/20", !micOn && "bg-coral hover:bg-coral/90")} size="lg">{micOn ? <Mic className="size-5" /> : <MicOff className="size-5" />}</IconButton>
          <IconButton label={cameraOn ? "Turn off camera" : "Turn on camera"} aria-pressed={!cameraOn} onClick={() => setCameraOn((value) => !value)} className={cn("rounded-full border border-primary-foreground/20 bg-primary-foreground/10 text-primary-foreground hover:bg-primary-foreground/20", !cameraOn && "bg-coral hover:bg-coral/90")} size="lg">{cameraOn ? <Video className="size-5" /> : <VideoOff className="size-5" />}</IconButton>
          <IconButton label="Speaker settings" className="hidden rounded-full border border-primary-foreground/20 bg-primary-foreground/10 text-primary-foreground hover:bg-primary-foreground/20 sm:inline-flex" size="lg"><Volume2 className="size-5" /></IconButton>
          <IconButton label={captionsOn ? "Turn off captions" : "Turn on captions"} aria-pressed={captionsOn} onClick={() => setCaptionsOn((value) => !value)} className={cn("rounded-full border border-primary-foreground/20 bg-primary-foreground/10 text-primary-foreground hover:bg-primary-foreground/20", captionsOn && "bg-accent text-primary")} size="lg"><Captions className="size-5" /></IconButton>
          <IconButton label="Share screen" className="hidden rounded-full border border-primary-foreground/20 bg-primary-foreground/10 text-primary-foreground hover:bg-primary-foreground/20 sm:inline-flex" size="lg"><MonitorUp className="size-5" /></IconButton>
          <IconButton label="Full screen" onClick={toggleFullscreen} className="hidden rounded-full border border-primary-foreground/20 bg-primary-foreground/10 text-primary-foreground hover:bg-primary-foreground/20 md:inline-flex" size="lg"><Maximize2 className="size-5" /></IconButton>
          <Button variant="destructive" size="lg" className="ml-1 rounded-full px-5" leadingIcon={<PhoneOff className="size-5" />} onClick={() => setEnded(true)} disabled={ended}>{ended ? "Ended" : "End"}</Button>
        </div>
      </section>
      <aside className="consultation-rail grid content-start gap-4 sm:grid-cols-2 xl:grid-cols-1">
        <section className="patient-panel rounded-xl border border-border bg-surface p-4 shadow-sm"><div className="flex items-center gap-3"><img src={doctorImage} alt="" className="size-12 rounded-lg object-cover object-top" /><div className="min-w-0"><p className="text-sm font-bold">General consultation</p><p className="text-xs text-muted-foreground">Wed, 26 Jun · 10:00</p></div></div><div className="mt-4 grid grid-cols-2 gap-2 border-t border-border pt-4 text-xs"><div><p className="text-muted-foreground">Patient</p><p className="mt-1 font-semibold">Thandi Mokoena</p></div><div><p className="text-muted-foreground">Duration</p><p className="mt-1 font-semibold">30 minutes</p></div></div></section>
        <section className="patient-panel rounded-xl border border-border bg-surface p-4 shadow-sm"><div className="flex items-center justify-between"><h2 className="font-display text-base font-semibold">Live vitals</h2><Badge variant="success">Current</Badge></div><div className="mt-3 grid grid-cols-2 gap-2"><ConsultationVital label="Blood pressure" value="120/80" note="mmHg" icon={HeartPulse} /><ConsultationVital label="Heart rate" value="74" note="bpm" icon={Activity} /><ConsultationVital label="Blood sugar" value="5.6" note="mmol/L" icon={Droplets} /><ConsultationVital label="BMI" value="24.1" note="healthy" icon={UserRound} /></div></section>
        <section className="patient-panel rounded-xl border border-border bg-surface p-4 shadow-sm"><div className="flex items-center justify-between"><h2 className="font-display text-base font-semibold">Consultation notes</h2><FilePlus2 className="size-4 text-accent" /></div><textarea aria-label="Consultation notes" className="mt-3 min-h-28 w-full resize-none rounded-md border border-input bg-muted/30 p-3 text-xs leading-relaxed" defaultValue="Feeling well overall. Mild headaches reported twice this week. Review current medication and hydration." /><Button variant="secondary" size="sm" className="mt-3 w-full">Save note</Button></section>
        <section className="patient-panel rounded-xl border border-border bg-surface p-4 shadow-sm"><h2 className="font-display text-base font-semibold">Shared during call</h2><div className="mt-3 space-y-2">{[[FileText,"Latest blood results","PDF · 1.8 MB"],[TestTube2,"HbA1c results","12 Mar 2025"]].map(([Icon,name,note]) => { const FileIcon=Icon as LucideIcon; return <button type="button" key={String(name)} className="flex w-full items-center gap-3 rounded-lg border border-border p-3 text-left"><IconTile icon={FileIcon} tone="bg-accent/10 text-accent" size="sm" /><span className="min-w-0 flex-1"><span className="block truncate text-xs font-bold">{String(name)}</span><span className="block text-[0.625rem] text-muted-foreground">{String(note)}</span></span><Download className="size-4 text-muted-foreground" /></button>; })}</div></section>
      </aside>
    </div>
    <section className="consultation-next grid gap-3 rounded-xl border border-accent/20 bg-accent/10 p-4 sm:grid-cols-[auto_minmax(0,1fr)_auto] sm:items-center"><span className="flex size-11 items-center justify-center rounded-lg bg-accent text-primary"><ShieldCheck className="size-5" /></span><div><p className="font-display text-base font-semibold">After your consultation</p><p className="text-xs text-muted-foreground">Your doctor’s summary, prescriptions, and follow-up actions will appear in My Health.</p></div><Link to="/patient/health" className={buttonVariants({variant:"secondary",size:"sm"})}>Open My Health</Link></section>
  </div>;
}

function ConsultationVital({ label, value, note, icon: Icon }: { label: string; value: string; note: string; icon: LucideIcon }) {
  return <div className="rounded-lg border border-border bg-muted/20 p-3"><Icon className="size-4 text-accent" /><p className="mt-3 font-display text-lg font-semibold leading-none">{value}</p><p className="mt-1 text-[0.625rem] font-semibold text-muted-foreground">{note}</p><p className="mt-2 text-[0.625rem] text-muted-foreground">{label}</p></div>;
}

function Field({label,value}:{label:string;value:string}) { return <label className="text-xs font-semibold">{label}<input defaultValue={value} className="mt-1.5 h-10 w-full rounded-md border border-input bg-surface px-3 text-sm font-normal" /></label>; }

const panelClass = "patient-panel rounded-xl border border-border bg-surface p-5 shadow-sm";

function Appointments() {
  const [tab, setTab] = useState<"Upcoming" | "Past">("Upcoming");
  const [cancelled, setCancelled] = useState(false);
  const past = [["12 Mar 2025", "Routine follow-up"], ["15 Jan 2025", "Medication review"], ["03 Oct 2024", "Diabetes review"]] as const;
  return <div className="space-y-5"><div className="flex flex-wrap items-start justify-between gap-3"><PageTitle icon={MyThusoVisitIcon} title="Appointments" note="View, book, reschedule or cancel appointments." /><Link to="/patient/book-appointment" className={buttonVariants({ variant: "primary", size: "md" })}><CalendarPlus className="size-4" />Book new</Link></div>
    <div className="flex gap-2" role="tablist">{(["Upcoming", "Past"] as const).map((t) => <Button key={t} role="tab" aria-selected={tab === t} size="sm" variant={tab === t ? "primary" : "secondary"} onClick={() => setTab(t)}>{t}</Button>)}</div>
    {tab === "Upcoming" ? (cancelled ? <section className={cn(panelClass, "text-center")}><p className="text-sm font-bold">No upcoming appointments</p><p className="text-xs text-muted-foreground">Your appointment on 26 June was cancelled.</p><Link to="/patient/book-appointment" className={cn(buttonVariants({ variant: "primary", size: "sm" }), "mt-4")}>Book a visit</Link></section> :
      <section className={cn(panelClass, "grid gap-4 sm:grid-cols-[auto_minmax(0,1fr)_auto] sm:items-center")}><div className="flex size-20 flex-col items-center justify-center rounded-lg bg-primary text-primary-foreground"><span className="text-[0.625rem] font-bold">WED</span><span className="font-display text-3xl font-semibold leading-none">26</span><span className="text-[0.625rem]">JUN 2025</span></div><div className="flex items-center gap-3"><img src={doctorImage} alt="" className="size-14 rounded-lg object-cover object-top" /><div><p className="text-sm font-bold">Dr. Ayanda Dlamini</p><p className="text-xs text-muted-foreground">General Practitioner · Rosebank Community Clinic</p><p className="mt-1 text-xs text-accent"><Clock className="mr-1 inline size-3" />10:00 – 10:30 (30 min) · General consultation</p></div></div><div className="flex flex-wrap gap-2"><Link to="/patient/consultation" className={buttonVariants({ variant: "primary", size: "sm" })}><Video className="size-4" />Join online</Link><Link to="/patient/book-appointment" className={buttonVariants({ variant: "secondary", size: "sm" })}>Reschedule</Link><Button size="sm" variant="ghost" onClick={() => setCancelled(true)}>Cancel</Button></div></section>)
      : <section className={panelClass}><SectionHeader icon={ClipboardList} title="Past appointments" /><div className="mt-3 divide-y divide-border">{past.map(([date, note]) => <div key={date} className="flex items-center gap-3 py-3"><IconTile icon={CalendarDays} tone="bg-primary/10 text-primary" /><div className="flex-1"><p className="text-sm font-bold">Dr. Ayanda Dlamini</p><p className="text-xs text-muted-foreground">{date} · {note}</p></div><Button size="sm" variant="ghost">View summary</Button></div>)}</div></section>}
  </div>;
}

function Wellness() {
  const tools = [[MyThusoMindIcon, "Mental Health Support", "Talk to a professional", "/patient/mental-health"], [BookOpen, "Self-help Resources", "Articles and tools", "/patient/health-tips"], [Smile, "Mood Check-in", "Track how you’re feeling", "/patient/mental-health"], [Phone, "Crisis Support", "Get help now", "/patient/messages"]] as const;
  return <div className="space-y-5"><PageTitle icon={Leaf} title="Wellness" note="Support for your mental and physical wellbeing." /><div className="grid gap-3 sm:grid-cols-2">{tools.map(([icon, title, note, to], i) => <Link key={title} to={to} className="patient-action flex items-center gap-3 rounded-xl border border-border bg-surface p-4"><IconTile icon={icon} size="lg" tone={["bg-accent/10 text-accent", "bg-primary/10 text-primary", "bg-coral/10 text-coral", "bg-highlight/25 text-primary"][i]} /><span className="flex-1"><span className="block text-sm font-bold">{title}</span><span className="block text-xs text-muted-foreground">{note}</span></span><ArrowRight className="size-4 text-muted-foreground" /></Link>)}</div><section className="patient-panel relative overflow-hidden rounded-xl border border-border bg-primary text-primary-foreground"><div className="grid sm:grid-cols-[14rem_minmax(0,1fr)]"><img src={capeTownImage} alt="" className="h-48 w-full object-cover sm:h-full" /><div className="p-6"><p className="font-display text-2xl font-semibold">“Progress, not perfection.”</p><p className="mt-1 text-sm opacity-80">— A healthier you</p><Link to="/patient/health-tips" className={cn(buttonVariants({ variant: "accent", size: "sm" }), "mt-5")}>Read health tips <ArrowRight className="size-4" /></Link></div></div></section></div>;
}

function HealthTips() {
  const [filter, setFilter] = useState("All");
  const tags = ["All", ...Array.from(new Set(healthTips.map((t) => t.tag)))];
  return <div className="space-y-5"><PageTitle icon={BookOpen} title="Health tips for you" note="Trusted advice for a healthier life." /><div className="flex flex-wrap gap-2">{tags.map((t) => <Button key={t} size="sm" variant={filter === t ? "primary" : "secondary"} onClick={() => setFilter(t)}>{t === "All" ? t : t.charAt(0) + t.slice(1).toLowerCase()}</Button>)}</div><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{healthTips.filter((t) => filter === "All" || t.tag === filter).map((t) => <article key={t.title} className="patient-action overflow-hidden rounded-xl border border-border bg-surface"><img src={t.image} alt="" className="h-36 w-full object-cover" /><div className="p-4"><span className={cn("rounded-sm px-2 py-0.5 text-[0.625rem] font-bold", t.tone)}>{t.tag}</span><h2 className="mt-2 text-sm font-bold">{t.title}</h2><p className="mt-2 text-xs text-muted-foreground"><Clock className="mr-1 inline size-3" />{t.read}</p></div></article>)}</div></div>;
}

type Device = { id: string; name: string; kind: string; icon: LucideIcon; image: string; reading: string; battery: number; synced: string; status: "Connected" | "Syncing" | "Low battery" | "Offline" };
const initialDevices: Device[] = [
  { id: "bp", name: "Omron BP Monitor", kind: "Blood pressure cuff", icon: HeartPulse, image: deviceBpImage, reading: "120/80 mmHg", battery: 82, synced: "2 min ago", status: "Connected" },
  { id: "glucose", name: "Accu-Chek Guide", kind: "Glucose meter", icon: Droplets, image: deviceGlucoseImage, reading: "5.6 mmol/L", battery: 64, synced: "1 h ago", status: "Connected" },
  { id: "watch", name: "Galaxy Watch 6", kind: "Smartwatch · heart rate & steps", icon: Watch, image: deviceWatchImage, reading: "74 bpm · 6 420 steps", battery: 18, synced: "5 min ago", status: "Low battery" },
  { id: "scale", name: "Withings Body+", kind: "Smart scale", icon: Scale, image: deviceScaleImage, reading: "68 kg · BMI 24.1", battery: 91, synced: "Yesterday", status: "Connected" },
  { id: "oxi", name: "Pulse oximeter", kind: "SpO₂ sensor", icon: Activity, image: deviceOxiImage, reading: "—", battery: 0, synced: "4 days ago", status: "Offline" },
];
const statusStyle: Record<Device["status"], string> = { Connected: "bg-success/10 text-success", Syncing: "bg-primary/10 text-primary", "Low battery": "bg-coral/10 text-coral", Offline: "bg-muted text-muted-foreground" };

function ConnectedDevices() {
  const [devices, setDevices] = useState(initialDevices);
  const sync = (id: string) => { setDevices((d) => d.map((x) => x.id === id ? { ...x, status: "Syncing" } : x)); setTimeout(() => setDevices((d) => d.map((x) => x.id === id ? { ...x, status: x.battery === 0 ? "Offline" : x.battery < 20 ? "Low battery" : "Connected", synced: "Just now" } : x)), 1500); };
  const online = devices.filter((d) => d.status !== "Offline").length;
  const alerts = devices.filter((d) => d.status === "Low battery" || d.status === "Offline").length;
  return <div className="space-y-5"><div className="flex flex-wrap items-start justify-between gap-3"><PageTitle icon={Wifi} title="Connected devices" note="Live status of the health devices that feed your records." /><Button leadingIcon={<Plus className="size-4" />}>Pair new device</Button></div>
    <div className="grid gap-3 sm:grid-cols-3"><HealthStat icon={Wifi} label="Devices online" value={`${online} of ${devices.length}`} tone="bg-accent/10 text-accent" /><HealthStat icon={RefreshCw} label="Last sync" value="2 min ago" tone="bg-primary/10 text-primary" /><HealthStat icon={AlertTriangle} label="Needs attention" value={`${alerts} device${alerts === 1 ? "" : "s"}`} tone="bg-coral/10 text-coral" /></div>
    <section className={panelClass}><SectionHeader icon={Bluetooth} title="Your devices" note="Readings sync automatically to My Health" action="Manage" /><div className="mt-4 grid gap-3 md:grid-cols-2">{devices.map((d) => <article key={d.id} className="patient-action rounded-lg border border-border p-4"><div className="flex items-start gap-3"><img src={d.image} alt={d.name} loading="lazy" className={cn("size-20 shrink-0 rounded-lg object-cover", d.status === "Offline" && "opacity-50 grayscale")} /><div className="min-w-0 flex-1"><p className="text-sm font-bold">{d.name}</p><p className="text-xs text-muted-foreground">{d.kind}</p></div><span className={cn("inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[0.625rem] font-bold", statusStyle[d.status])}><span className={cn("size-1.5 rounded-full bg-current", d.status === "Syncing" && "animate-pulse")} />{d.status}</span></div><div className="mt-4 grid grid-cols-3 gap-2 text-xs"><div><p className="text-muted-foreground">Latest</p><p className="font-semibold">{d.reading}</p></div><div><p className="text-muted-foreground">Battery</p><div className="mt-1 h-1.5 overflow-hidden rounded-full bg-muted" role="meter" aria-valuenow={d.battery} aria-valuemin={0} aria-valuemax={100} aria-label={`${d.name} battery`}><span className={cn("block h-full rounded-full", d.battery < 20 ? "bg-coral" : "bg-accent")} style={{ width: `${d.battery}%` }} /></div><p className="mt-0.5 font-semibold">{d.battery}%</p></div><div><p className="text-muted-foreground">Synced</p><p className="font-semibold">{d.synced}</p></div></div><div className="mt-3 flex justify-end"><Button size="sm" variant="secondary" disabled={d.status === "Syncing"} onClick={() => sync(d.id)} leadingIcon={<RefreshCw className={cn("size-3.5", d.status === "Syncing" && "animate-spin")} />}>{d.status === "Offline" ? "Reconnect" : "Sync now"}</Button></div></article>)}</div></section>
  </div>;
}


function PageContent({ page }: { page: PatientPage }) {
  if (page === "consultation") return <OnlineConsultation />;
  if (page === "health") return <MyHealth />;
  if (page === "book") return <BookAppointment />;
  if (page === "quick-booking") return <QuickBooking />;
  if (page === "mental-health") return <MentalHealth />;
  if (page === "test-results") return <TestResults />;
  if (page === "prescriptions") return <Prescriptions />;
  if (page === "records") return <MedicalRecords />;
  if (page === "family") return <FamilyCare />;
  if (page === "messages") return <Messages />;
  if (page === "settings") return <SettingsPage />;
  if (page === "appointments") return <Appointments />;
  if (page === "wellness") return <Wellness />;
  if (page === "health-tips") return <HealthTips />;
  if (page === "devices") return <ConnectedDevices />;
  if (page === "visit-tracker") return <PatientVisitTracker />;
  if (["symptom-checker", "risk-assessment", "vaccinations", "health-timeline", "share-records", "wearables", "reminders", "health-library", "community", "nutrition", "activity", "emergency-info"].includes(page)) return <MoreDestination page={page as MorePage} />;
  return <Dashboard />;
}

export function PatientSpace({ page }: { page: PatientPage }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [signingOut, setSigningOut] = useState(false);
  const [patientName, setPatientName] = useState("Thandi M.");
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  useEffect(() => {
    void supabase.auth.getUser().then(async ({ data }) => {
      if (!data.user) return;
      const { data: stored } = await supabase.from("profiles").select("display_name").eq("id", data.user.id).maybeSingle();
      const name = stored?.display_name || data.user.user_metadata?.display_name || data.user.email?.split("@")[0];
      if (name) setPatientName(name);
    });
  }, []);
  const handleLogout = async () => {
    setSigningOut(true);
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    await navigate({ to: "/", replace: true });
  };
  const activeGroup = navGroups.find((group) => group.items.some((item) => item.page === page))?.label ?? "Overview";
  const [openGroups, setOpenGroups] = useState<string[]>(() => [activeGroup]);
  const toggleGroup = (label: string) => setOpenGroups((groups) => groups.includes(label) ? groups.filter((group) => group !== label) : [...groups, label]);
  const navList = (
    <nav className="flex-1 space-y-1 overflow-y-auto p-3" aria-label="Patient navigation">
      {navGroups.map(({ label: groupLabel, icon: GroupIcon, items }) => {
        const open = openGroups.includes(groupLabel) || groupLabel === activeGroup;
        return <section key={groupLabel} aria-label={`${groupLabel} menu`}>
          <Button type="button" variant="ghost" size="sm" className={cn("w-full justify-start px-3 text-xs font-bold", groupLabel === activeGroup ? "text-primary" : "text-muted-foreground")} aria-expanded={open} onClick={() => toggleGroup(groupLabel)}>
            <GroupIcon className="size-4" /><span className="flex-1 text-left">{groupLabel}</span><ChevronDown className={cn("size-3.5 transition-transform", open && "rotate-180")} />
          </Button>
          {open && <div className="ml-3 mt-1 space-y-0.5 border-l border-border pl-2">{items.map(({ icon: Icon, label, to, page: navPage, badge, count }) => (
            <Link key={label} to={to} onClick={() => setMenuOpen(false)} aria-current={page === navPage ? "page" : undefined} className={cn("patient-nav-item flex min-h-8 items-center gap-2 rounded-md px-2 py-1.5 text-[0.6875rem] font-medium text-muted-foreground hover:bg-muted hover:text-foreground", page === navPage && "bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground")}>
              <Icon className="size-3.5 shrink-0" /><span className="min-w-0 flex-1 truncate">{label}</span>
              {badge && <Badge variant="accent" className="text-[0.5rem]">{badge}</Badge>}
              {count && <span className="flex size-4 items-center justify-center rounded-full bg-coral text-[0.5625rem] font-bold text-white">{count}</span>}
            </Link>
          ))}</div>}
        </section>;
      })}
    </nav>
  );
  const brandBlock = (
    <>
      <img src={mythusoWordmark} alt="MyThuso — Help. Health. Home." width={1657} height={598} className="h-8 w-auto object-contain" />
      <p className="mt-1 text-[0.625rem] text-muted-foreground">For a healthier tomorrow.</p>
    </>
  );
  return (
    <div className="patient-dashboard min-h-screen bg-background">
      <div className="flex">
        <aside className="sticky top-0 hidden h-screen w-52 shrink-0 flex-col border-r border-border bg-surface lg:flex">
          <div className="border-b border-border p-5">{brandBlock}</div>
          {navList}
           <div className="border-t border-border p-3"><Button variant="ghost" className="w-full justify-start text-danger hover:bg-danger/10" leadingIcon={<LogOut className="size-4" />} loading={signingOut} onClick={() => void handleLogout()}>Log out</Button></div>
        </aside>
        <div className="min-w-0 flex-1">
          <header className="sticky top-0 z-40 flex items-center gap-3 border-b border-border bg-surface/95 px-4 py-3 backdrop-blur sm:px-6">
            <Button variant="secondary" size="icon" aria-label="Open menu" aria-expanded={menuOpen} className="rounded-full lg:hidden" onClick={() => setMenuOpen(true)}><Menu className="size-4" /></Button>
            <Link to="/" className="lg:hidden"><img src={mythusoWordmark} alt="MyThuso — Help. Health. Home." width={1657} height={598} className="h-7 w-auto object-contain" /></Link>
            <div className="relative hidden flex-1 sm:block"><Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" /><input type="search" placeholder="Search for doctors, clinics, services or health topics..." className="h-10 w-full max-w-xl rounded-md border border-input bg-muted/50 pl-10 pr-4 text-sm" /></div>
            <div className="ml-auto flex items-center gap-3">
              <Button variant="secondary" size="icon" aria-label="Notifications, 2 unread" className="relative rounded-full"><Bell className="size-4" /><span className="notification-dot absolute right-2 top-2 size-2 rounded-full bg-coral" /></Button>
               <Button variant="secondary" className="h-10 rounded-full py-1 pl-1 pr-3"><img src={doctorImage} alt="" className="size-8 rounded-full object-cover object-top" /><span className="hidden max-w-28 text-left sm:block"><span className="block truncate text-xs font-bold">{patientName}</span><span className="block text-[0.625rem] text-muted-foreground">Patient</span></span><ChevronDown className="size-3.5 text-muted-foreground" /></Button>
              <Button variant="secondary" className="hidden h-10 rounded-full px-3 md:flex"><MapPin className="size-4 text-accent" /><span className="text-xs font-bold">Gauteng</span><ChevronDown className="size-3.5 text-muted-foreground" /></Button>
            </div>
          </header>
          <main className="patient-dashboard-main p-4 sm:p-5"><PageContent page={page} /></main>
          <footer className="flex flex-col items-center justify-between gap-3 border-t border-border px-6 py-5 sm:flex-row">
            <div className="flex items-center gap-2"><img src={mythusoWordmark} alt="MyThuso — Help. Health. Home." width={1657} height={598} className="h-6 w-auto object-contain" /><p className="text-[0.6875rem] text-muted-foreground">© 2026 MyThuso. All rights reserved.</p></div>
            <div className="flex items-center gap-4 text-[0.6875rem] font-medium text-muted-foreground"><span>Privacy</span><span>Terms</span><span>Help Centre</span></div>
          </footer>
        </div>
      </div>
      {menuOpen && (
        <div className="fixed inset-0 z-[60] lg:hidden">
          <button type="button" aria-label="Close menu" className="absolute inset-0 bg-primary/40 backdrop-blur-sm" onClick={() => setMenuOpen(false)} />
          <div className="absolute inset-y-0 left-0 flex w-64 flex-col bg-surface shadow-xl">
            <div className="flex items-center justify-between border-b border-border p-4">
              {brandBlock}
              <Button variant="secondary" size="icon" aria-label="Close menu" className="shrink-0 rounded-full" onClick={() => setMenuOpen(false)}><X className="size-4" /></Button>
            </div>
            {navList}
             <div className="mt-auto border-t border-border p-3"><Button variant="ghost" className="w-full justify-start text-danger hover:bg-danger/10" leadingIcon={<LogOut className="size-4" />} loading={signingOut} onClick={() => void handleLogout()}>Log out</Button></div>
          </div>
        </div>
      )}
      <PanicFloating role="Patient" name="Thandi Molekoa" />{page !== "consultation" && <GilbertChatLauncher />}
    </div>
  );
}
