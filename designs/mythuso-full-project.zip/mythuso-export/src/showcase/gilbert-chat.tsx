import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport, type UIMessage } from "ai";
import { AlertTriangle, ChevronDown, LockKeyhole, MessageCircle, RotateCcw, ShieldCheck, X } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button, GilbertOne } from "@/index";
import { Conversation, ConversationContent, ConversationScrollButton } from "@/components/ai-elements/conversation";
import { Message, MessageContent, MessageResponse } from "@/components/ai-elements/message";
import { PromptInput, PromptInputFooter, PromptInputSubmit, PromptInputTextarea } from "@/components/ai-elements/prompt-input";
import { Shimmer } from "@/components/ai-elements/shimmer";

const suggestions = ["Explain my latest results", "Help me prepare for my visit", "What should I track today?"];

type GilbertPanelProps = { onClose: () => void; onMinimize: () => void };

function GilbertConversation({ initialMessages, onClear }: { initialMessages: UIMessage[]; onClear: () => Promise<void> }) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const transport = useMemo(() => new DefaultChatTransport({
    api: "/api/gilbert-chat",
    fetch: async (input, init) => {
      const { data } = await supabase.auth.getSession();
      const headers = new Headers(init?.headers);
      if (data.session?.access_token) headers.set("Authorization", `Bearer ${data.session.access_token}`);
      return fetch(input, { ...init, headers });
    },
  }), []);
  const { messages, sendMessage, status, stop, error, setMessages } = useChat({
    id: "patient-passport-gilbert-one",
    messages: initialMessages,
    transport,
    onFinish: () => textareaRef.current?.focus(),
  });
  const busy = status === "submitted" || status === "streaming";

  useEffect(() => { textareaRef.current?.focus(); }, []);
  const submit = async ({ text }: { text: string }) => {
    const value = text.trim();
    if (!value || busy) return;
    await sendMessage({ text: value });
    textareaRef.current?.focus();
  };
  const clear = async () => { await onClear(); setMessages([]); textareaRef.current?.focus(); };

  return <>
    <div className="flex items-center justify-between border-b border-border px-4 py-2">
      <span className="inline-flex items-center gap-1.5 text-[0.6875rem] font-semibold text-success"><LockKeyhole className="size-3" />Saved to your patient passport</span>
      <Button variant="ghost" size="sm" onClick={clear} disabled={busy || messages.length === 0} leadingIcon={<RotateCcw className="size-3" />}>Clear</Button>
    </div>
    <Conversation className="min-h-0 bg-background/50">
      <ConversationContent className="gap-4 p-4">
        {messages.length === 0 && <div className="space-y-4 py-2"><div className="flex gap-3"><GilbertOne className="h-16 w-12 shrink-0" label="" /><div><p className="text-sm font-bold">Hello, I’m GilbertOne.</p><p className="mt-1 text-xs leading-relaxed text-muted-foreground">I can explain health information in plain language and help you prepare for care.</p></div></div><div className="grid gap-2">{suggestions.map((suggestion) => <Button key={suggestion} variant="secondary" size="sm" className="justify-start text-left" onClick={() => void submit({ text: suggestion })}>{suggestion}</Button>)}</div></div>}
        {messages.map((message) => <Message key={message.id} from={message.role}><MessageContent className={message.role === "user" ? "bg-primary text-primary-foreground" : undefined}>{message.parts.map((part, index) => part.type === "text" ? <MessageResponse key={`${message.id}-${index}`}>{part.text}</MessageResponse> : null)}</MessageContent></Message>)}
        {status === "submitted" && <div className="flex items-center gap-2"><GilbertOne className="h-9 w-7" label="" /><Shimmer className="text-xs">GilbertOne is thinking…</Shimmer></div>}
        {error && <div role="alert" className="rounded-md border border-danger/30 bg-danger/10 p-3 text-xs text-danger">{error.message || "GilbertOne could not respond. Please try again."}</div>}
      </ConversationContent>
      <ConversationScrollButton />
    </Conversation>
    <div className="border-t border-border p-3">
      <PromptInput onSubmit={submit} className="bg-surface">
        <PromptInputTextarea ref={textareaRef} placeholder="Ask GilbertOne about your health…" aria-label="Message GilbertOne" disabled={busy} />
        <PromptInputFooter className="justify-end"><PromptInputSubmit status={status} onStop={stop} disabled={status === "error"} /></PromptInputFooter>
      </PromptInput>
      <p className="mt-2 text-center text-[0.625rem] text-muted-foreground">GilbertOne can make mistakes. Confirm medical decisions with your care team.</p>
    </div>
  </>;
}

function GilbertPanel({ onClose, onMinimize }: GilbertPanelProps) {
  const [consented, setConsented] = useState(false);
  const [acknowledged, setAcknowledged] = useState(false);
  const [messages, setMessages] = useState<UIMessage[] | null>(null);
  const [signedIn, setSignedIn] = useState<boolean | null>(null);

  useEffect(() => {
    let active = true;
    void supabase.auth.getSession().then(async ({ data }) => {
      if (!active) return;
      const user = data.session?.user;
      setSignedIn(Boolean(user));
      if (!user) { setMessages([]); return; }
      const { data: rows } = await supabase.from("gilbert_chat_messages").select("ai_message_id,role,parts").order("created_at");
      if (!active) return;
      setMessages((rows ?? []).map((row) => ({ id: row.ai_message_id, role: row.role as "user" | "assistant", parts: row.parts as UIMessage["parts"] })));
    });
    return () => { active = false; };
  }, []);

  const clearHistory = async () => {
    const { error } = await supabase.from("gilbert_chat_messages").delete().neq("id", "00000000-0000-0000-0000-000000000000");
    if (error) throw new Error("Your conversation could not be cleared.");
  };

  return <section aria-label="GilbertOne health assistant" className="fixed inset-x-3 bottom-3 z-50 flex h-[min(42rem,calc(100vh-1.5rem))] flex-col overflow-hidden rounded-xl border border-border bg-surface shadow-md sm:inset-x-auto sm:bottom-5 sm:right-5 sm:w-[25rem]">
    <header className="flex items-center gap-3 bg-primary px-4 py-3 text-primary-foreground"><GilbertOne className="h-12 w-9 shrink-0" label="" /><div className="min-w-0 flex-1"><h2 className="font-display text-base font-semibold">GilbertOne</h2><p className="text-[0.6875rem] opacity-75">Your MyThuso health guide</p></div><Button variant="ghost" size="icon" aria-label="Minimize GilbertOne" onClick={onMinimize} className="text-primary-foreground hover:bg-white/10"><ChevronDown className="size-4" /></Button><Button variant="ghost" size="icon" aria-label="Close GilbertOne" onClick={onClose} className="text-primary-foreground hover:bg-white/10"><X className="size-4" /></Button></header>
    {signedIn === null || messages === null ? <div className="flex flex-1 items-center justify-center"><Shimmer className="text-sm">Opening your patient passport…</Shimmer></div> : !signedIn ? <div className="flex flex-1 flex-col items-center justify-center p-8 text-center"><LockKeyhole className="size-8 text-accent" /><h3 className="mt-3 font-display text-lg font-semibold">Patient passport required</h3><p className="mt-2 text-sm text-muted-foreground">Sign in to keep this health conversation private and available across your devices.</p></div> : !consented ? <div className="flex-1 overflow-y-auto p-5"><div className="flex items-start gap-3 rounded-lg bg-highlight/20 p-4"><AlertTriangle className="mt-0.5 size-5 shrink-0 text-primary" /><div><h3 className="text-sm font-bold">Before we start</h3><p className="mt-1 text-xs leading-relaxed text-muted-foreground">GilbertOne is an AI guide, not a doctor. It cannot diagnose conditions or replace professional medical advice.</p></div></div><div className="mt-4 rounded-lg border border-danger/25 bg-danger/5 p-4"><p className="text-xs font-bold text-danger">Emergency?</p><p className="mt-1 text-xs leading-relaxed">Call <strong>112</strong> from a mobile phone or <strong>10177</strong> for an ambulance in South Africa.</p></div><label className="mt-5 flex cursor-pointer items-start gap-3 text-xs leading-relaxed"><input type="checkbox" checked={acknowledged} onChange={(event) => setAcknowledged(event.target.checked)} className="mt-0.5 size-4 accent-accent" /><span>I understand GilbertOne provides general guidance and that this conversation will be stored securely in my patient passport.</span></label><Button className="mt-5 w-full" disabled={!acknowledged} onClick={() => setConsented(true)} leadingIcon={<ShieldCheck className="size-4" />}>Continue to GilbertOne</Button></div> : <GilbertConversation initialMessages={messages} onClear={clearHistory} />}
  </section>;
}

export function GilbertChatLauncher() {
  const [open, setOpen] = useState(false);
  if (open) return <GilbertPanel onClose={() => setOpen(false)} onMinimize={() => setOpen(false)} />;
  return <div className="fixed bottom-5 right-5 z-50 flex items-end gap-2"><Button className="hidden rounded-full shadow-md sm:inline-flex" size="sm" leadingIcon={<MessageCircle className="size-4" />} onClick={() => setOpen(true)}>How can I help you today?</Button><Button variant="ghost" size="icon" className="size-16 overflow-visible rounded-full bg-transparent p-0 hover:bg-transparent" aria-label="Open GilbertOne health assistant" onClick={() => setOpen(true)}><GilbertOne className="h-16 w-12 drop-shadow-lg" label="" /></Button></div>;
}