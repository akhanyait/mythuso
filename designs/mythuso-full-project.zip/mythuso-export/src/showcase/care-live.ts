import { useEffect, useSyncExternalStore } from "react";

/* Preview-only simulated real-time layer: device readings, alarms, safety zones and clinician movement.
   Real device feeds, police risk data and GPS will replace this module through the code engine. */

export type VitalKey = "hr" | "sys" | "spo2" | "glucose" | "temp";
export type Severity = "watch" | "urgent" | "critical";
export type ZoneRisk = "safe" | "caution" | "high";
export type Reading = { t: number; hr: number; sys: number; dia: number; spo2: number; glucose: number; temp: number };
export type LivePatient = { id: string; name: string; age: number; condition: string; zone: string; lat: number; lng: number; device: string; battery: number; base: Omit<Reading, "t">; drift: Partial<Record<VitalKey, number>> };
export type Zone = { id: string; name: string; risk: ZoneRisk; lat: number; lng: number; radiusKm: number; note: string };
export type Clinician = { id: string; name: string; role: "Nurse" | "Doctor"; reg: string; lat: number; lng: number; home: [number, number]; status: "En route" | "On site" | "Virtual" | "Available" | "Off duty"; target?: string; progress: number; driver?: string; companion?: string; vehicle?: string; lastCheckIn: number; panic: boolean };
export type AlarmEvent = { at: number; who: string; text: string };
export type Alarm = { id: string; patientId: string; vital: VitalKey; value: number; severity: Severity; raisedAt: number; status: "open" | "acknowledged" | "responding" | "resolved"; assignedTo?: string; response?: string; events: AlarmEvent[] };

export const vitalMeta: Record<VitalKey, { label: string; unit: string; watch: [number, number]; urgent: [number, number]; critical: [number, number]; band: [number, number] }> = {
  hr: { label: "Heart rate", unit: "bpm", band: [60, 100], watch: [55, 105], urgent: [50, 120], critical: [40, 140] },
  sys: { label: "Systolic BP", unit: "mmHg", band: [100, 139], watch: [95, 150], urgent: [90, 160], critical: [80, 180] },
  spo2: { label: "SpO2", unit: "%", band: [95, 100], watch: [94, 101], urgent: [92, 101], critical: [90, 101] },
  glucose: { label: "Glucose", unit: "mmol/L", band: [4, 10], watch: [4, 11], urgent: [3.5, 13], critical: [3, 20] },
  temp: { label: "Temperature", unit: "°C", band: [36.1, 37.5], watch: [35.5, 38], urgent: [35, 39], critical: [34.5, 39.5] },
};

export function severityOf(key: VitalKey, value: number): Severity | null {
  const m = vitalMeta[key];
  const out = (r: [number, number]) => value < r[0] || value > r[1];
  if (out(m.critical)) return "critical";
  if (out(m.urgent)) return "urgent";
  if (out(m.watch)) return "watch";
  return null;
}

export const zones: Zone[] = [
  { id: "rosebank", name: "Rosebank", risk: "safe", lat: -26.146, lng: 28.041, radiusKm: 2.2, note: "No recent incidents on patient routes" },
  { id: "sandton", name: "Sandton", risk: "safe", lat: -26.107, lng: 28.056, radiusKm: 2.6, note: "Well-lit main routes" },
  { id: "alexandra", name: "Alexandra", risk: "caution", lat: -26.103, lng: 28.097, radiusKm: 2.0, note: "Vehicle crime reported on 2nd Ave after 16:00" },
  { id: "hillbrow", name: "Hillbrow", risk: "high", lat: -26.189, lng: 28.049, radiusKm: 1.6, note: "Armed robbery cluster this week" },
  { id: "soweto", name: "Orlando, Soweto", risk: "caution", lat: -26.235, lng: 27.925, radiusKm: 2.6, note: "Protest action reported near Vilakazi St" },
];

export const livePatients: LivePatient[] = [
  { id: "MT-10234", name: "Thandi M. Molekoa", age: 54, condition: "Hypertension", zone: "rosebank", lat: -26.142, lng: 28.036, device: "Omron BP monitor", battery: 78, base: { hr: 82, sys: 148, dia: 94, spo2: 97, glucose: 6.1, temp: 36.7 }, drift: { sys: 1 } },
  { id: "MT-10251", name: "Sipho N. Dlamini", age: 61, condition: "Type 2 diabetes", zone: "alexandra", lat: -26.105, lng: 28.094, device: "Accu-Chek glucose meter", battery: 41, base: { hr: 91, sys: 136, dia: 86, spo2: 96, glucose: 11.4, temp: 36.9 }, drift: { glucose: 1 } },
  { id: "MT-10288", name: "Lerato K. Maseko", age: 3, condition: "Child immunisation", zone: "soweto", lat: -26.232, lng: 27.931, device: "Smart thermometer", battery: 88, base: { hr: 112, sys: 98, dia: 60, spo2: 98, glucose: 5.2, temp: 37.6 }, drift: { temp: 1 } },
  { id: "MT-10302", name: "Nomvula R. Khumalo", age: 29, condition: "Antenatal · 28 weeks", zone: "sandton", lat: -26.11, lng: 28.06, device: "Smartwatch", battery: 64, base: { hr: 88, sys: 118, dia: 76, spo2: 98, glucose: 5.4, temp: 36.6 }, drift: {} },
  { id: "MT-10317", name: "Jacob T. Nkosi", age: 47, condition: "Asthma", zone: "hillbrow", lat: -26.187, lng: 28.047, device: "Pulse oximeter", battery: 22, base: { hr: 96, sys: 128, dia: 82, spo2: 94, glucose: 5.8, temp: 36.8 }, drift: { spo2: -1 } },
];

const seedClinicians: Clinician[] = [
  { id: "N-01", name: "Sister Naledi Mokoena", role: "Nurse", reg: "SANC 14-882016", lat: -26.16, lng: 28.02, home: [-26.16, 28.02], status: "En route", target: "MT-10234", progress: 0.1, driver: "Thabo Sithole", companion: "Kagiso Mahlangu", vehicle: "Toyota Corolla Cross · GP 44 KX", lastCheckIn: 0, panic: false },
  { id: "N-02", name: "Sister Palesa Khumalo", role: "Nurse", reg: "SANC 12-557310", lat: -26.09, lng: 28.08, home: [-26.09, 28.08], status: "En route", target: "MT-10251", progress: 0.3, driver: "Sizwe Ndlovu", companion: "Lindiwe Zulu", vehicle: "VW Polo Vivo · GP 19 LM", lastCheckIn: 0, panic: false },
  { id: "N-03", name: "Sister Zanele Mthembu", role: "Nurse", reg: "SANC 16-203944", lat: -26.25, lng: 27.9, home: [-26.25, 27.9], status: "Available", progress: 0, driver: "Mandla Khoza", vehicle: "Suzuki Ertiga · GP 07 TN", lastCheckIn: 0, panic: false },
  { id: "D-01", name: "Dr Ayanda Dlamini", role: "Doctor", reg: "HPCSA MP0483217", lat: -26.146, lng: 28.041, home: [-26.146, 28.041], status: "Virtual", progress: 0, driver: "Peter Molefe", companion: "Rethabile Nkosi", vehicle: "Toyota Fortuner · GP 88 DR", lastCheckIn: 0, panic: false },
  { id: "D-02", name: "Dr Kabelo Mashaba", role: "Doctor", reg: "HPCSA MP0519024", lat: -26.2, lng: 27.95, home: [-26.2, 27.95], status: "Available", progress: 0, driver: "Joseph Radebe", vehicle: "Hyundai Creta · GP 31 WQ", lastCheckIn: 0, panic: false },
];

export function distanceKm(a: [number, number], b: [number, number]) {
  const r = (d: number) => (d * Math.PI) / 180;
  const dLat = r(b[0] - a[0]); const dLng = r(b[1] - a[1]);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(r(a[0])) * Math.cos(r(b[0])) * Math.sin(dLng / 2) ** 2;
  return 6371 * 2 * Math.asin(Math.sqrt(h));
}
export const zoneById = (id: string) => zones.find((z) => z.id === id)!;
export const patientById = (id: string) => livePatients.find((p) => p.id === id)!;

/** Travel rules: high risk = virtual only; caution = driver + companion; safe = driver. */
export function visitRule(risk: ZoneRisk) {
  if (risk === "high") return { mode: "Virtual only", canTravel: false, needs: "Physical visits are blocked until the area is reassessed" };
  if (risk === "caution") return { mode: "Travel with escort", canTravel: true, needs: "Driver and companion required, daylight only" };
  return { mode: "Travel allowed", canTravel: true, needs: "Driver required" };
}

export const PROXIMITY_KM = 15;
export function allocationFor(patientId: string, clinicians: Clinician[]) {
  const p = patientById(patientId); const zone = zoneById(p.zone); const rule = visitRule(zone.risk);
  return clinicians.map((c) => {
    const km = distanceKm([c.lat, c.lng], [p.lat, p.lng]);
    const inRange = km <= PROXIMITY_KM;
    const escortOk = zone.risk === "safe" ? !!c.driver : !!c.driver && !!c.companion;
    const eligible = c.status !== "Off duty" && inRange;
    const physical = eligible && rule.canTravel && escortOk;
    return { clinician: c, km, etaMin: Math.round((km / 32) * 60) + 4, inRange, escortOk, eligible, physical };
  }).sort((a, b) => a.km - b.km);
}

/* Deterministic history (no randomness at module scope). */
function wave(seed: number, i: number) { return Math.sin(i * 0.7 + seed) * 0.6 + Math.sin(i * 0.23 + seed * 2) * 0.4; }
export function historyFor(p: LivePatient, points: number, stepMin: number): Reading[] {
  const now = Date.UTC(2026, 8, 28, 16, 0);
  const seed = p.id.charCodeAt(7);
  return Array.from({ length: points }, (_, i) => {
    const w = wave(seed, i); const trend = (i / points);
    return {
      t: now - (points - i) * stepMin * 60000,
      hr: Math.round(p.base.hr + w * 8 + (p.drift.hr ?? 0) * trend * 20),
      sys: Math.round(p.base.sys + w * 10 + (p.drift.sys ?? 0) * trend * 22),
      dia: Math.round(p.base.dia + w * 6),
      spo2: Math.min(100, Math.round(p.base.spo2 + w * 1.2 + (p.drift.spo2 ?? 0) * trend * 3)),
      glucose: +(p.base.glucose + w * 1.4 + (p.drift.glucose ?? 0) * trend * 4).toFixed(1),
      temp: +(p.base.temp + w * 0.3 + (p.drift.temp ?? 0) * trend * 1.2).toFixed(1),
    };
  });
}

type State = { tick: number; live: Record<string, Reading[]>; alarms: Alarm[]; clinicians: Clinician[]; flaggedAreas: { name: string; by: string; note: string }[]; panics: PanicEvent[] };
export type PanicEvent = { id: string; role: string; name: string; kind: string; at: number; status: "active" | "cancelled" | "resolved" };
let state: State = {
  tick: 0,
  live: Object.fromEntries(livePatients.map((p) => [p.id, historyFor(p, 24, 5)])),
  alarms: [{ id: "AL-1001", patientId: "MT-10317", vital: "spo2", value: 91, severity: "urgent", raisedAt: Date.UTC(2026, 8, 28, 15, 48), status: "open", events: [{ at: Date.UTC(2026, 8, 28, 15, 48), who: "Pulse oximeter", text: "SpO2 91% sustained for 4 minutes" }] }],
  clinicians: seedClinicians,
  flaggedAreas: [],
  panics: [],
};
const listeners = new Set<() => void>();
let timer: ReturnType<typeof setInterval> | null = null;
const emit = () => listeners.forEach((l) => l());
function set(next: Partial<State>) { state = { ...state, ...next }; emit(); }

function step() {
  const tick = state.tick + 1;
  const now = Date.now();
  const live = { ...state.live };
  const alarms = [...state.alarms];
  for (const p of livePatients) {
    const series = live[p.id]; const last = series[series.length - 1];
    const jitter = () => (Math.random() - 0.5);
    const spike = tick % 9 === 0 ? 1 : 0;
    const next: Reading = {
      t: now,
      hr: Math.round(clamp(last.hr + jitter() * 6 + (p.id === "MT-10288" ? spike * 30 : 0), p.base.hr - 15, p.base.hr + 40)),
      sys: Math.round(clamp(last.sys + jitter() * 8 + (p.drift.sys ?? 0) * spike * 30, p.base.sys - 15, p.base.sys + 45)),
      dia: Math.round(clamp(last.dia + jitter() * 4, p.base.dia - 10, p.base.dia + 15)),
      spo2: Math.round(clamp(last.spo2 + jitter() * 2 + (p.drift.spo2 ?? 0) * spike * 3, 86, 100)),
      glucose: +clamp(last.glucose + jitter() * 0.8 + (p.drift.glucose ?? 0) * spike * 4, 3.2, 22).toFixed(1),
      temp: +clamp(last.temp + jitter() * 0.2 + (p.drift.temp ?? 0) * spike * 1.4, 35.6, 40).toFixed(1),
    };
    live[p.id] = [...series.slice(-47), next];
    (Object.keys(vitalMeta) as VitalKey[]).forEach((k) => {
      const sev = severityOf(k, next[k]);
      if (sev && sev !== "watch" && !alarms.some((a) => a.patientId === p.id && a.vital === k && a.status !== "resolved")) {
        alarms.unshift({ id: `AL-${1001 + alarms.length + tick}`, patientId: p.id, vital: k, value: next[k], severity: sev, raisedAt: now, status: "open", events: [{ at: now, who: p.device, text: `${vitalMeta[k].label} ${next[k]} ${vitalMeta[k].unit} crossed the ${sev} threshold` }] });
      }
    });
  }
  const clinicians = state.clinicians.map((c) => {
    if (c.status !== "En route" || !c.target) return c;
    const p = patientById(c.target);
    const progress = Math.min(1, c.progress + 0.04);
    const lat = c.home[0] + (p.lat - c.home[0]) * progress; const lng = c.home[1] + (p.lng - c.home[1]) * progress;
    if (progress >= 1) return { ...c, lat, lng, progress: 0, status: "On site" as const };
    return { ...c, lat, lng, progress };
  }).map((c) => (c.status === "On site" && tick % 12 === 0 ? { ...c, status: "En route" as const, lat: c.home[0], lng: c.home[1], progress: 0 } : c));
  set({ tick, live, alarms: alarms.slice(0, 30), clinicians });
}
function clamp(v: number, a: number, b: number) { return Math.max(a, Math.min(b, v)); }

function subscribe(l: () => void) {
  listeners.add(l);
  if (!timer && typeof window !== "undefined") timer = setInterval(step, 2500);
  return () => { listeners.delete(l); if (!listeners.size && timer) { clearInterval(timer); timer = null; } };
}
const getState = () => state;

export function useLive() {
  const s = useSyncExternalStore(subscribe, getState, getState);
  useEffect(() => undefined, []);
  return s;
}

export function updateAlarm(id: string, patch: Partial<Alarm>, event: AlarmEvent) {
  set({ alarms: state.alarms.map((a) => (a.id === id ? { ...a, ...patch, events: [...a.events, event] } : a)) });
}
export function dispatchClinician(clinicianId: string, patientId: string) {
  set({ clinicians: state.clinicians.map((c) => (c.id === clinicianId ? { ...c, status: "En route", target: patientId, home: [c.lat, c.lng], progress: 0 } : c)) });
}
export function setVirtual(clinicianId: string) {
  set({ clinicians: state.clinicians.map((c) => (c.id === clinicianId ? { ...c, status: "Virtual", target: undefined } : c)) });
}
export function checkIn(clinicianId: string) { set({ clinicians: state.clinicians.map((c) => (c.id === clinicianId ? { ...c, lastCheckIn: state.tick, panic: false } : c)) }); }
export function raisePanic(clinicianId: string) { set({ clinicians: state.clinicians.map((c) => (c.id === clinicianId ? { ...c, panic: true } : c)) }); }
export function flagArea(entry: { name: string; by: string; note: string }) { set({ flaggedAreas: [entry, ...state.flaggedAreas] }); }

/** Device auto-triage from the latest reading. */
export function deviceTriage(r: Reading) {
  const sevs = (Object.keys(vitalMeta) as VitalKey[]).map((k) => severityOf(k, r[k]));
  if (sevs.includes("critical")) return { level: "Red", label: "Emergency", tone: "danger" as const };
  if (sevs.includes("urgent")) return { level: "Orange", label: "Very urgent", tone: "danger" as const };
  if (sevs.includes("watch")) return { level: "Yellow", label: "Urgent", tone: "warning" as const };
  return { level: "Green", label: "Routine", tone: "success" as const };
}

/** NEWS2-style early warning score (simplified; preview only). */
export function news2(v: { rr: number; spo2: number; sys: number; hr: number; temp: number; alert: boolean; o2: boolean }) {
  let s = 0;
  s += v.rr <= 8 ? 3 : v.rr <= 11 ? 1 : v.rr <= 20 ? 0 : v.rr <= 24 ? 2 : 3;
  s += v.spo2 <= 91 ? 3 : v.spo2 <= 93 ? 2 : v.spo2 <= 95 ? 1 : 0;
  s += v.o2 ? 2 : 0;
  s += v.sys <= 90 ? 3 : v.sys <= 100 ? 2 : v.sys <= 110 ? 1 : v.sys <= 219 ? 0 : 3;
  s += v.hr <= 40 ? 3 : v.hr <= 50 ? 1 : v.hr <= 90 ? 0 : v.hr <= 110 ? 1 : v.hr <= 130 ? 2 : 3;
  s += v.alert ? 0 : 3;
  s += v.temp <= 35 ? 3 : v.temp <= 36 ? 1 : v.temp <= 38 ? 0 : v.temp <= 39 ? 1 : 2;
  return s;
}

/** Map a lat/lng into the schematic 0-100 viewbox. */
export function project(lat: number, lng: number) {
  return { x: ((lng - 27.86) / (28.14 - 27.86)) * 100, y: ((lat - -26.07) / (-26.27 - -26.07)) * 100 };
}

export function sendPanic(e: { role: string; name: string; kind: string }) {
  const ev: PanicEvent = { id: `SOS-${Date.now().toString().slice(-5)}`, at: Date.now(), status: "active", ...e };
  set({ panics: [ev, ...state.panics] }); return ev.id;
}
export function setPanicStatus(id: string, status: PanicEvent["status"]) { set({ panics: state.panics.map((p) => (p.id === id ? { ...p, status } : p)) }); }
