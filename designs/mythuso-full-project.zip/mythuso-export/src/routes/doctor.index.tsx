import { createFileRoute } from "@tanstack/react-router";
import { DoctorSpace } from "../showcase/doctor-space";

export const Route = createFileRoute("/doctor/")({
  head: () => ({ meta: [
    { title: "Review queue — MyThuso Doctor" },
    { name: "description", content: "Review nurse handovers, flagged observations and records awaiting clinical sign-off." },
    { property: "og:title", content: "Review queue — MyThuso Doctor" },
    { property: "og:description", content: "Review nurse handovers, flagged observations and records awaiting clinical sign-off." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: () => <DoctorSpace page="queue" />,
});