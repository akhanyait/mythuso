import { createFileRoute } from "@tanstack/react-router";
import { NurseSpace } from "../showcase/nurse-space";

export const Route = createFileRoute("/nurse/allocations")({
  head: () => ({ meta: [{ title: "Allocations — MyThuso Nurse" }, { name: "description", content: "Plan patient allocations, home visits and the daily route." }, { property: "og:title", content: "Allocations — MyThuso Nurse" }, { property: "og:description", content: "Plan patient allocations, home visits and the daily route." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: () => <NurseSpace page="allocations" />,
});
