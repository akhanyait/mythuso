import { createFileRoute } from "@tanstack/react-router";
import { NurseSpace } from "../showcase/nurse-space";

export const Route = createFileRoute("/nurse/settings")({
  head: () => ({ meta: [{ title: "Settings — MyThuso Nurse" }, { name: "description", content: "Nurse profile and notification preferences." }, { property: "og:title", content: "Settings — MyThuso Nurse" }, { property: "og:description", content: "Nurse profile and notification preferences." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: () => <NurseSpace page="settings" />,
});
