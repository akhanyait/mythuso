import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/gilbert-chat")({
  server: { handlers: { POST: async ({ request }) => {
    const { handleGilbertChat } = await import("@/lib/gilbert-chat.server");
    return handleGilbertChat(request);
  } } },
});