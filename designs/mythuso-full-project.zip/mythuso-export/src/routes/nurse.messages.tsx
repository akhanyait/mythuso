import { createFileRoute } from "@tanstack/react-router";
import { NurseSpace } from "../showcase/nurse-space";

export const Route = createFileRoute("/nurse/messages")({
  head: () => ({ meta: [{ title: "Messages — MyThuso Nurse" }, { name: "description", content: "Conversations with doctors, pharmacy, labs and your team." }, { property: "og:title", content: "Messages — MyThuso Nurse" }, { property: "og:description", content: "Conversations with doctors, pharmacy, labs and your team." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: () => <NurseSpace page="messages" />,
});
