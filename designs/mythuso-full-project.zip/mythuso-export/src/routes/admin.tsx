import { createFileRoute } from "@tanstack/react-router";
import { AdminDeployment } from "../showcase/care-safety";
export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [{ title: "Control room — MyThuso Admin" }, { name: "description", content: "Live deployment map of nurses and doctors, area risk, alarms and emergency alerts." }, { property: "og:title", content: "Control room — MyThuso Admin" }, { property: "og:description", content: "Live deployment map of nurses and doctors, area risk, alarms and emergency alerts." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: () => <AdminDeployment />,
});
