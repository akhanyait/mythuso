import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import {
  ArrowRight,
  AudioWaveform,
  BadgeCheck,
  BarChart3,
  BrainCircuit,
  BookOpen,
  Building2,
  Check,
  ChevronDown,
  CirclePlay,
  ClipboardCheck,
  FileHeart,
  FileText,
  Heart,
  HeartPulse,
  Hospital,
  Lightbulb,
  LockKeyhole,
  Menu,
  MessageCircle,
  Microscope,
  Pill,
  Puzzle,
  Plus,
  Search,
  ShieldCheck,
  Sparkles,
  Stethoscope,
  Users,
  X,
} from "lucide-react";
import { useEffect, useRef, useState, type ReactNode } from "react";
import doctorImage from "../assets/photography/careline-doctor.jpg";
import capeTownImage from "../assets/photography/cape-town-care.jpg";
import southAfricaImpactImage from "../assets/illustrations/south-africa-impact.png";
import mythusoLogo from "../assets/logos/mythuso-logo.png";
import gilbertOneLogo from "../assets/logos/gilbert-one-logo.png";
import { Badge, Button, Card, GilbertOne, IconButton, Input } from "../index";
import { cn } from "../lib/utils";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "MyThuso — Smarter Healthcare, Connected" },
      { name: "description", content: "A connected healthcare ecosystem combining AI, clinical knowledge, and real-world data." },
      { property: "og:title", content: "MyThuso — Smarter Healthcare, Connected" },
      { property: "og:description", content: "A connected healthcare ecosystem combining AI, clinical knowledge, and real-world data." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: LandingPage,
});

const trustItems = [
  [ShieldCheck, "Secure & compliant", "POPIA + HIPAA-ready"],
  [BadgeCheck, "Built for healthcare", "By healthcare experts"],
  [HeartPulse, "Real-world impact", "Better outcomes, together"],
] as const;

const audiences = [
  [Hospital, "Hospitals", "text-primary bg-primary/10"],
  [HeartPulse, "Clinics", "text-coral bg-coral/10"],
  [Building2, "Health Departments", "text-accent bg-accent/10"],
  [Stethoscope, "Practitioners", "text-accent bg-accent/10"],
  [Pill, "Pharmacies", "text-coral bg-coral/10"],
  [Users, "Research & Academia", "text-highlight bg-highlight/10"],
  [Building2, "NGOs", "text-success bg-success/10"],
] as const;

const solutionCards = [
  { icon: Stethoscope, title: "For Clinicians", tone: "bg-accent", points: ["Evidence-based answers", "Clinical guidance", "Draft notes & referrals", "At your fingertips"] },
  { icon: Building2, title: "For Health Systems", tone: "bg-coral", points: ["Scale quality care", "Improve efficiency", "Unlock insights", "Better resource planning"] },
  { icon: Users, title: "For Communities", tone: "bg-primary", points: ["Better access to care", "Trusted information", "Healthier futures", "Stronger communities"] },
] as const;

const activityItems = [
  [FileHeart, "Hypertension management", "2 minutes ago", "bg-accent/10 text-accent"],
  [FileText, "Draft referral letter", "15 minutes ago", "bg-success/10 text-success"],
  [BookOpen, "TB guideline search", "1 hour ago", "bg-warning/15 text-foreground"],
] as const;

const savedItems = [
  [FileHeart, "Diabetes management", "Clinical guideline · PDF", "bg-coral/10 text-coral"],
  [FileText, "Paediatric dosing", "Quick reference", "bg-warning/15 text-foreground"],
  [BookOpen, "Antenatal care", "Protocol · 2024", "bg-primary/10 text-primary"],
] as const;

const accessRoles = [
  { icon: Users, initials: "", title: "Patient", details: "Book a nurse, follow a visit, and read what was found at home." },
  { icon: Stethoscope, initials: "NM", title: "Nurse", details: "Today’s visits, the order you will do them, and the one still waiting for sign-off." },
  { icon: HeartPulse, initials: "AD", title: "Doctor", details: "Cases waiting to be read. Decision support may draft; only a registered doctor signs." },
  { icon: Pill, initials: "RP", title: "Pharmacy partner", details: "Prescriptions and laboratory orders routed to this partner, and what each is waiting on." },
  { icon: BarChart3, initials: "KM", title: "Control Tower", details: "Where every visit is, which nurses are free, and what is running late." },
  { icon: LockKeyhole, initials: "TW", title: "Back office", details: "Vetting decisions, the catalogue, growth, finance, and what stands between each capability and being real." },
] as const;

function BrandMark({ inverse = false }: { inverse?: boolean }) {
  if (inverse) return (
    <span className="inline-flex items-center rounded-lg bg-surface px-2.5 py-2 shadow-sm">
      <img src={mythusoLogo} alt="MyThuso — Help. Health. Home." width={1657} height={598} className="h-9 w-auto object-contain" />
    </span>
  );
  return <img src={mythusoLogo} alt="MyThuso — Help. Health. Home." width={1657} height={598} className="h-9 w-auto object-contain" />;
}

function SectionLabel({ children }: { children: ReactNode }) {
  return <p className="mb-2 text-xs font-bold uppercase text-primary">{children}</p>;
}

const impactStats = [
  { icon: Hospital, value: 1200, suffix: "+", label: "Healthcare facilities", tone: "bg-success/10 text-success" },
  { icon: Users, value: 25000, suffix: "+", label: "Healthcare professionals", tone: "bg-coral/10 text-coral" },
  { icon: HeartPulse, value: 2, suffix: "M+", label: "People positively impacted", tone: "bg-highlight/20 text-primary" },
] as const;

function useCountUp(target: number, active: boolean, duration = 1500) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    if (!active) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) { setValue(target); return; }
    let frame = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const progress = Math.min(1, (now - start) / duration);
      setValue(Math.round(target * (1 - Math.pow(1 - progress, 3))));
      if (progress < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [active, target, duration]);
  return value;
}

function ImpactStatRow({ icon: Icon, value, suffix, label, tone, active, delay }: { icon: typeof Hospital; value: number; suffix: string; label: string; tone: string; active: boolean; delay: number }) {
  const count = useCountUp(value, active);
  return (
    <div className="impact-stat flex items-center gap-3" style={{ animationDelay: `${delay}s` }}>
      <span className={cn("flex size-9 items-center justify-center rounded-md", tone)}><Icon className="size-4" /></span>
      <div>
        <p className="font-display text-lg font-bold">{count.toLocaleString("en-US")}{suffix}</p>
        <p className="text-[0.6875rem] text-muted-foreground">{label}</p>
      </div>
    </div>
  );
}

function LandingPage() {
  const navigate = useNavigate();
  const [accessOpen, setAccessOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [planAudience, setPlanAudience] = useState<"self" | "mom">("self");
  const impactRef = useRef<HTMLDivElement | null>(null);
  const [impactSeen, setImpactSeen] = useState(false);
  useEffect(() => {
    const el = impactRef.current;
    if (!el || impactSeen) return;
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) { setImpactSeen(true); observer.disconnect(); }
    }, { threshold: 0.35 });
    observer.observe(el);
    return () => observer.disconnect();
  }, [impactSeen]);
  type CarePlan = { name: string; price: string; phase: string; description?: string; comparison?: string; action?: string; featured?: boolean };
  const selfPlans: CarePlan[] = [
    { name: "Chronic Routine", price: "R 199", phase: "Phase 2", description: "Monthly visit, AI-screened vitals, doctor review, script collection, medicine delivery, adherence nudges", featured: true },
    { name: "Family Planning Plan", price: "R 99", phase: "Phase 2", description: "Injection every 2–3 months, reminders, discreet booking" },
    { name: "MyThuso for Mom", price: "R 399", comparison: "to R 1 299 a month", phase: "Phase 2–3", description: "A nurse for a parent every month, fortnight or week, paid for by their children", action: "See the plans for Mom" },
    { name: "Thuso Senior (Gogo)", price: "R 699", phase: "Phase 3", description: "Weekly elderly visit, medication management, fall-risk check, family report" },
  ];
  const momPlans: CarePlan[] = [
    { name: "A nurse every month", price: "R 399", phase: "Phase 2", featured: true },
    { name: "A nurse every fortnight", price: "R 749", phase: "Phase 3" },
    { name: "A nurse every week", price: "R 1 299", phase: "Phase 3" },
  ];
  const activePlans = planAudience === "self" ? selfPlans : momPlans;
  return (
    <div className="min-h-screen overflow-hidden bg-background text-foreground">
      <header className="relative z-50 border-b border-border/60 bg-surface/95">
        <div className="mx-auto flex h-16 max-w-[1180px] items-center px-4 sm:px-6">
          <a href="#top" aria-label="MyThuso home"><BrandMark /></a>
          <nav className="mx-auto hidden items-center gap-8 lg:flex" aria-label="Primary navigation">
            {[["Solutions", "solutions"], ["Who we serve", "solutions"], ["Resources", "platform"], ["About", "impact"]].map(([label, id]) => (
              <a key={label} href={`#${id}`} className="flex items-center gap-1 text-xs font-semibold text-foreground hover:text-primary">{label}<ChevronDown className="size-3" /></a>
            ))}
          </nav>
          <div className="ml-auto hidden items-center gap-3 sm:flex">
            <IconButton label="Search" variant="ghost" size="sm"><Search className="size-4" /></IconButton>
             <Button variant="secondary" size="sm" onClick={() => setAccessOpen(true)}>Sign in</Button>
             <Button variant="ghost" size="sm" onClick={() => setAccessOpen(true)}>Register</Button>
            <Button size="sm" trailingIcon={<ArrowRight className="size-3.5" />}>Book a demo</Button>
          </div>
          <IconButton label={menuOpen ? "Close navigation" : "Open navigation"} variant="ghost" className="ml-auto sm:hidden" onClick={() => setMenuOpen((value) => !value)}>{menuOpen ? <X className="size-4" /> : <Menu className="size-4" />}</IconButton>
        </div>
        {menuOpen && <nav className="grid gap-1 border-t border-border p-4 sm:hidden" aria-label="Mobile navigation">{["Solutions", "Who we serve", "Resources", "About"].map((item) => <a key={item} href="#solutions" onClick={() => setMenuOpen(false)} className="rounded-md px-3 py-2 text-sm font-semibold hover:bg-muted">{item}</a>)}<div className="mt-2 grid grid-cols-2 gap-2"><Button variant="secondary" onClick={() => { setMenuOpen(false); setAccessOpen(true); }}>Sign in</Button><Button onClick={() => { setMenuOpen(false); setAccessOpen(true); }}>Register</Button></div></nav>}
      </header>

      {accessOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-primary/70 p-3 backdrop-blur-md sm:p-6" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setAccessOpen(false); }}>
          <section role="dialog" aria-modal="true" aria-labelledby="access-title" className="relative grid max-h-[94vh] w-full max-w-5xl overflow-auto rounded-xl bg-surface shadow-md lg:grid-cols-[0.78fr_1.22fr]">
            <IconButton label="Close access menu" variant="secondary" size="sm" className="absolute right-4 top-4 z-20 rounded-full" onClick={() => setAccessOpen(false)}><X className="size-4" /></IconButton>
            <div className="relative hidden min-h-[690px] overflow-hidden bg-accent/10 p-10 lg:flex lg:flex-col">
              <BrandMark />
              <p className="mt-3 text-[0.625rem] font-bold uppercase text-primary">For a healthier tomorrow</p>
              <h2 className="mt-12 font-display text-4xl font-semibold leading-[0.9]">One platform.<br />Many roles.<br /><span className="text-accent">Greater care.</span></h2>
              <p className="mt-5 max-w-xs text-sm leading-5 text-muted-foreground">Secure access for everyone in the healthcare ecosystem — so together we can build healthier communities across South Africa.</p>
              <div className="hero-halo absolute -bottom-28 -left-20 size-[430px] rounded-full border border-accent/20" aria-hidden="true" />
              <img src={doctorImage} alt="Smiling healthcare professional" width={1024} height={1024} className="absolute bottom-0 left-0 h-[390px] w-[82%] object-cover object-top [clip-path:polygon(0_8%,100%_0,100%_100%,0_100%)]" />
              <GilbertOne label="" className="absolute bottom-7 right-5 h-28 w-auto drop-shadow-xl" />
              <div className="absolute bottom-7 left-8 flex items-center gap-2 rounded-full bg-surface/90 px-3 py-2 text-[0.625rem] font-bold text-success shadow-sm"><ShieldCheck className="size-4" /> Secure. Simple. Together.</div>
            </div>
            <div className="p-5 pt-14 sm:p-8 sm:pt-12 lg:p-10">
              <p className="text-[0.625rem] font-bold uppercase text-primary">Log in to MyThuso</p>
              <h2 id="access-title" className="mt-2 font-display text-3xl font-semibold leading-none sm:text-4xl">Choose your role</h2>
              <p className="mt-2 text-sm text-muted-foreground">Access your personalised dashboard and get to what matters.</p>
              <div className="mt-5 rounded-lg bg-info/10 p-4">
                <div className="flex gap-3"><span className="flex size-7 shrink-0 items-center justify-center rounded-full bg-surface text-info"><BadgeCheck className="size-4" /></span><div><p className="text-xs font-bold">Quick, secure access</p><p className="mt-1 text-[0.6875rem] leading-4 text-muted-foreground">Select the role that best describes you. You’ll be signed in and taken to your dashboard.</p></div></div>
              </div>
              <div className="mt-3 grid gap-2">
                {accessRoles.map(({ icon: RoleIcon, initials, title, details }) => (
                  <Button key={title} type="button" variant="secondary" className="h-auto w-full justify-start gap-3 px-3 py-3 text-left" onClick={() => { setAccessOpen(false); if (title === "Patient") navigate({ to: "/patient" }); if (title === "Nurse") navigate({ to: "/nurse" }); if (title === "Doctor") navigate({ to: "/doctor" }); if (title === "Pharmacy partner") navigate({ to: "/partner" }); }}>
                    <span className="flex size-10 shrink-0 items-center justify-center rounded-full bg-highlight/20 text-primary">{initials ? <span className="text-xs font-bold">{initials}</span> : <RoleIcon className="size-5" />}</span>
                    <span className="min-w-0 flex-1"><span className="block text-xs font-bold text-foreground">{title}</span><span className="mt-0.5 block whitespace-normal text-[0.625rem] font-normal leading-4 text-muted-foreground">{details}</span></span>
                    <ArrowRight className="size-4 shrink-0 text-primary" />
                  </Button>
                ))}
              </div>
              <p className="mt-4 flex items-center gap-2 border-t border-border pt-4 text-[0.625rem] text-muted-foreground"><LockKeyhole className="size-3.5 text-primary" /> By continuing, you agree to our Privacy Policy and Terms of Use.</p>
            </div>
          </section>
        </div>
      )}

      <main id="top">
        <section className="hero-stage relative isolate border-b border-border bg-surface">
          <div className="hero-plane hero-plane--left" aria-hidden="true" />
          <div className="hero-plane hero-plane--right" aria-hidden="true" />
          <span className="hero-particle hero-particle--lime" aria-hidden="true" />
          <span className="hero-particle hero-particle--teal" aria-hidden="true" />
          <span className="hero-particle hero-particle--orange" aria-hidden="true" />
          <div className="relative mx-auto grid max-w-[1180px] lg:min-h-[500px] lg:grid-cols-[0.86fr_1.14fr]">
            <div className="z-10 px-4 py-12 sm:px-6 lg:py-16">
              <Badge variant="accent" className="hero-badge shadow-sm"><Plus className="size-3" strokeWidth={3} /> AI-powered healthcare ecosystem</Badge>
              <h1 className="mt-5 max-w-xl font-display text-5xl font-semibold leading-[0.94] sm:text-6xl">Smarter care<br />happens <span className="text-accent">here.</span></h1>
              <p className="mt-5 max-w-lg text-base leading-6 text-muted-foreground">MyThuso combines AI, clinical knowledge and real-world data to help healthcare teams make faster, safer decisions — for healthier communities.</p>
              <div className="mt-6 flex flex-wrap gap-3"><Button trailingIcon={<ArrowRight className="size-4" />}>Book a demo</Button><Button variant="secondary" leadingIcon={<CirclePlay className="size-4 fill-primary text-primary" />}>Watch video</Button></div>
              <div className="mt-8 grid gap-4 sm:grid-cols-3">{trustItems.map(([Icon, title, note], index) => <div key={title} className="group flex gap-2.5"><span className={cn("hero-icon-tile flex size-9 shrink-0 items-center justify-center rounded-lg border", index === 1 ? "border-coral/20 bg-coral/10 text-coral" : index === 2 ? "border-highlight/50 bg-highlight/20 text-primary" : "border-accent/20 bg-accent/10 text-success")}><Icon className="size-4" /></span><div><p className="text-xs font-bold">{title}</p><p className="text-[0.6875rem] text-muted-foreground">{note}</p></div></div>)}</div>
            </div>
            <div className="relative min-h-[430px] overflow-visible lg:min-h-0">
              <div className="hero-halo pointer-events-none absolute -left-[4%] top-[5%] z-[2] size-[84%] rounded-full border border-accent/20" aria-hidden="true"><span className="absolute inset-[12%] rounded-full border border-accent/25" /><span className="absolute inset-[27%] rounded-full border border-accent/30" /></div>
              <div className="hero-portrait absolute inset-x-0 bottom-0 top-0 overflow-hidden sm:left-5 lg:left-0 lg:right-2">
                <img src={doctorImage} alt="Smiling healthcare professional" width={1024} height={1024} className="h-full w-full object-cover object-top" />
                <div className="hero-image-wash absolute inset-0" aria-hidden="true" />
              </div>
              <div className="hero-float hero-float--patient absolute left-0 top-[44%] w-36 rounded-lg border border-surface/80 bg-surface/90 p-3 shadow-md backdrop-blur-xl sm:left-4"><span className="hero-icon-tile flex size-9 items-center justify-center rounded-full border border-coral/20 bg-coral/10 text-coral"><HeartPulse className="size-4" /></span><p className="mt-2 text-xs font-bold">Patient insights</p><p className="mt-1 text-[0.6875rem] leading-4 text-muted-foreground">Actionable answers in seconds.</p></div>
              <div className="hero-listening absolute bottom-5 right-[18%] z-30 flex items-center gap-2 rounded-lg border border-surface/80 bg-surface/95 px-3 py-2.5 text-foreground shadow-md backdrop-blur-xl"><span className="relative flex size-8 items-center justify-center rounded-full bg-accent text-accent-foreground"><span className="hero-listening__pulse absolute inset-0 rounded-full" /><AudioWaveform className="relative size-4" /></span><span className="whitespace-nowrap text-xs font-bold">Listening...</span></div>
              <div className="hero-float hero-float--assistant absolute right-6 top-12 z-20 w-56 rounded-xl border border-surface/80 bg-surface/90 p-4 shadow-md backdrop-blur-xl sm:right-10 sm:w-64"><GilbertOne className="absolute -right-3 -top-3 hidden h-32 w-auto drop-shadow-xl lg:block" /><div className="flex items-start gap-2 pr-14 lg:pr-16"><GilbertOne label="" className="h-10 w-8 shrink-0 lg:hidden" /><div><p className="text-xs font-bold">Hello, I’m GilbertOne 👋</p><p className="text-[0.6875rem] text-muted-foreground">Your AI clinical assistant.<br />How can I help today?</p></div></div><div className="mt-5 grid gap-2 lg:mt-7">{[[FileText, "Summarise patient record", "bg-accent/10 text-success"], [ClipboardCheck, "Check guidelines", "bg-highlight/20 text-primary"], [FileHeart, "Draft clinical note", "bg-coral/10 text-coral"], [MessageCircle, "Answer a clinical question", "bg-primary/10 text-primary"]].map(([ActionIcon, action, tone]) => { const Icon = ActionIcon as typeof FileText; return <div key={action as string} className="hero-action flex items-center gap-2 rounded-md border border-border/60 bg-surface/75 px-2 py-1.5 text-[0.6875rem] font-semibold"><span className={cn("flex size-5 shrink-0 items-center justify-center rounded-sm", tone as string)}><Icon className="size-3" /></span>{action as string}</div>; })}</div><p className="mt-3 flex items-center gap-1 text-[0.625rem] text-muted-foreground"><ShieldCheck className="size-3 text-success" /> Trusted. Accurate. Always on.</p></div>
            </div>
          </div>
        </section>

        <div className="border-b border-border bg-surface"><div className="mx-auto grid max-w-[1180px] grid-cols-2 gap-px sm:grid-cols-4 lg:grid-cols-7">{audiences.map(([Icon, label, tone]) => <div key={label} className="flex items-center justify-center gap-2 border-r border-border/70 px-3 py-4 text-center text-[0.6875rem] font-medium text-muted-foreground"><span className={cn("flex size-7 items-center justify-center rounded-full", tone)}><Icon className="size-3.5" /></span>{label}</div>)}</div></div>

        <section id="plans" className="bg-muted py-14 sm:py-20">
          <div className="mx-auto max-w-[1180px] px-4 sm:px-6">
            <SectionLabel>03 &nbsp; Thuso Routine</SectionLabel>
            <h2 className="max-w-4xl font-display text-4xl font-semibold leading-none sm:text-5xl">Care that keeps showing up.</h2>
            <p className="mt-4 max-w-3xl text-sm leading-6 text-muted-foreground">A chronic condition is not managed in a single visit. A plan is designed to cover the visit, the doctor review, the script and the medicine together, from R 99 a month.</p>
            <div className="mt-9 inline-flex rounded-full border border-border bg-surface p-0.5" aria-label="Choose who the care plan is for">
              <Button type="button" size="sm" variant={planAudience === "self" ? "primary" : "ghost"} className="rounded-full px-5" aria-pressed={planAudience === "self"} onClick={() => setPlanAudience("self")}>For me</Button>
              <Button type="button" size="sm" variant={planAudience === "mom" ? "primary" : "ghost"} className="rounded-full px-5" aria-pressed={planAudience === "mom"} onClick={() => setPlanAudience("mom")}>For Mom</Button>
            </div>
            {planAudience === "mom" && <p className="mt-4 max-w-xl text-sm leading-6 text-muted-foreground">The person who pays is usually not the patient. It is the son or daughter in the city, looking after a parent who cannot easily get to a clinic, with the same nurse every time and a report after every visit.</p>}
            <div className={cn("mt-5 grid gap-3", planAudience === "self" ? "md:grid-cols-2 lg:grid-cols-4" : "md:grid-cols-3")}>
              {activePlans.map((plan) => (
                <article key={plan.name} className={cn("flex min-h-56 flex-col rounded-lg border border-border p-5 shadow-sm", plan.featured ? "bg-accent/25" : "bg-surface")}>
                  <div className="flex items-start justify-between gap-4"><span className="flex size-8 items-center justify-center rounded-md bg-accent/15 text-primary"><Heart className="size-4" /></span><Badge variant="neutral">{plan.phase}</Badge></div>
                  <h3 className="mt-4 min-h-10 text-sm font-medium leading-5">{plan.name}</h3>
                  <div className="mt-2 flex items-baseline gap-2"><span className="font-display text-3xl font-medium">{plan.price}</span><span className="text-[0.625rem] text-muted-foreground">a month</span>{plan.comparison && <span className="max-w-20 text-[0.625rem] leading-4 text-muted-foreground">{plan.comparison}</span>}</div>
                  {plan.description && <p className="mt-4 text-xs leading-5 text-muted-foreground">{plan.description}</p>}
                  {plan.action && <Button type="button" variant="secondary" size="sm" className="mt-auto w-full justify-between" trailingIcon={<ArrowRight className="size-3.5" />} onClick={() => setPlanAudience("mom")}>{plan.action}</Button>}
                </article>
              ))}
            </div>
            {planAudience === "mom" && <p className="mt-6 max-w-xl text-xs leading-5 text-muted-foreground">MyThuso for Mom is not medical aid, and no medical scheme pays for it. It pays for no hospital care, test or medicine beyond collecting what has already been prescribed.</p>}
          </div>
        </section>

        <section id="solutions" className="mx-auto max-w-[1180px] border-t-4 border-accent px-4 py-16 sm:px-6">
          <div className="grid gap-8 lg:grid-cols-[0.72fr_1.28fr] lg:items-center">
            <div><SectionLabel>Our solutions</SectionLabel><h2 className="font-display text-3xl font-semibold leading-none sm:text-4xl">A connected ecosystem<br />for modern healthcare</h2><p className="mt-4 max-w-md text-sm leading-6 text-muted-foreground">From clinical decision support to operational intelligence, MyThuso helps healthcare teams do more with trusted AI.</p><a href="#platform" className="mt-5 inline-flex items-center gap-2 text-sm font-bold text-primary">Explore all solutions <ArrowRight className="size-4" /></a></div>
            <div className="grid gap-3 md:grid-cols-3">{solutionCards.map(({ icon: Icon, title, tone, points }) => <Card key={title} padding="md" className="bg-surface"><span className={cn("flex size-11 items-center justify-center rounded-full text-primary-foreground", tone)}><Icon className="size-5" /></span><h3 className="mt-4 font-display text-lg font-semibold">{title}</h3><ul className="mt-3 space-y-1.5">{points.map((point) => <li key={point} className="flex gap-2 text-xs text-muted-foreground"><Sparkles className="mt-0.5 size-3 shrink-0 text-primary" />{point}</li>)}</ul><a href="#platform" className="mt-5 inline-flex items-center gap-1 text-xs font-bold text-success">Learn more <ArrowRight className="size-3" /></a></Card>)}</div>
          </div>
        </section>

        <section id="platform" className="bg-surface-raised py-10 sm:py-16">
          <div className="mx-auto max-w-[1180px] px-4 sm:px-6">
            <div className="grid gap-4 lg:grid-cols-[1fr_280px]">
              <div className="overflow-hidden rounded-lg border border-border bg-surface shadow-md">
                <div className="grid min-h-[430px] md:grid-cols-[150px_1fr]">
                  <aside className="hidden bg-primary p-4 text-primary-foreground md:block"><BrandMark inverse /><nav className="mt-8 grid gap-1">{[[HeartPulse,"Home"],[MessageCircle,"Ask GilbertOne"],[Users,"Patients"],[BookOpen,"Guidelines"],[Lightbulb,"Knowledge"],[BarChart3,"Analytics"]].map(([I,l]) => { const Icon = I as typeof HeartPulse; return <div key={l as string} className={cn("flex items-center gap-2 rounded-md px-3 py-2 text-xs", l === "Home" ? "bg-accent/30 font-bold" : "text-primary-foreground/75")}><Icon className="size-4" />{l as string}</div>; })}</nav></aside>
                  <div className="p-4 sm:p-6"><div className="flex items-center justify-between border-b border-border pb-3"><div className="relative hidden flex-1 sm:block"><Search className="absolute left-3 top-1/2 size-3 -translate-y-1/2 text-muted-foreground" /><Input className="h-8 pl-8 text-xs" placeholder="Search patients, guidelines, or ask a question..." /></div><Badge className="ml-3" variant="neutral">Dr. Nomsa Dlamini</Badge></div><div className="mt-6 flex items-center gap-3"><GilbertOne label="" className="h-11 w-9 shrink-0" /><div><h3 className="font-display text-base font-semibold">Good morning, Dr. Dlamini 👋</h3><p className="text-xs text-muted-foreground">How can GilbertOne help you today?</p></div></div><div className="mt-5 flex gap-2"><Input placeholder="Ask a clinical question..." /><IconButton label="Send question" variant="accent"><ArrowRight className="size-4" /></IconButton></div><div className="mt-3 flex flex-wrap gap-2">{["Summarise patient record", "Draft a clinical note", "Check a guideline"].map((item) => <Badge key={item} variant="neutral">{item}</Badge>)}</div><div className="mt-6 grid gap-4 md:grid-cols-2">{[["Recent activity", activityItems],["Saved", savedItems]].map(([heading, items]) => <div key={heading as string} className="rounded-md border border-border p-3"><div className="mb-3 flex justify-between"><p className="text-xs font-bold">{heading as string}</p><span className="text-[0.625rem] font-bold text-primary">View all</span></div><div className="grid gap-2">{(items as typeof activityItems).map(([ItemIcon, title, note, tone]) => <div key={title} className="flex items-center gap-2 border-b border-border/60 pb-2 last:border-0 last:pb-0"><span className={cn("flex size-7 items-center justify-center rounded-sm", tone)}><ItemIcon className="size-3.5" /></span><div><p className="text-[0.6875rem] font-semibold">{title}</p><p className="text-[0.625rem] text-muted-foreground">{note}</p></div></div>)}</div></div>)}</div></div>
                </div>
              </div>
              <Card padding="lg" className="flex flex-col items-center justify-center text-center"><img src={gilbertOneLogo} alt="GilbertOne" width={1448} height={1086} className="h-28 w-auto object-contain drop-shadow-xl" /><p className="mt-4 text-sm font-semibold text-primary">Reliable answers.<br />Real-world impact.</p><div className="mt-6 w-full space-y-3 text-left">{["Clinical decision support", "Guideline and policy answers", "Draft notes, referrals and letters", "Available anytime, anywhere"].map((item) => <p key={item} className="flex items-center gap-2 text-xs"><Check className="size-4 shrink-0 rounded-full bg-success p-0.5 text-primary-foreground" />{item}</p>)}</div><Button className="mt-7 w-full" trailingIcon={<ArrowRight className="size-4" />}>Start a conversation</Button></Card>
            </div>
          </div>
        </section>

        <section id="impact" className="bg-surface py-12 sm:py-16">
          <div className="mx-auto max-w-[1180px] px-4 sm:px-6">
            <div className="grid gap-8 lg:grid-cols-[1.12fr_0.88fr] lg:items-center">
              <div ref={impactRef} className={cn("impact-panel grid overflow-hidden rounded-lg bg-accent/10 sm:grid-cols-[1.08fr_0.92fr]", impactSeen && "impact-go")}>
                <div className="relative flex min-h-72 items-center justify-center p-4"><span className="impact-halo absolute size-56 rounded-full" aria-hidden="true" /><img src={southAfricaImpactImage} alt="Connected healthcare locations across South Africa" width={1024} height={768} loading="lazy" className="impact-map relative h-64 w-full object-contain" /></div>
                 <div className="impact-stat m-3 rounded-lg bg-surface p-5 shadow-sm" style={{ animationDelay: "0.08s" }}><p className="text-xs font-bold text-success">Real impact</p><h2 className="font-display text-xl font-semibold leading-tight">across South Africa</h2><div className="mt-5 grid gap-4">{impactStats.map(({ icon: Icon, value, suffix, label, tone }, index) => <ImpactStatRow key={label} icon={Icon} value={value} suffix={suffix} label={label} tone={tone} active={impactSeen} delay={0.16 + index * 0.12} />)}</div></div>
              </div>
              <div><SectionLabel>Trusted nationwide</SectionLabel><h2 className="font-display text-3xl font-semibold leading-none">Trusted by healthcare teams<br />across South Africa</h2><p className="mt-3 max-w-lg text-xs leading-5 text-muted-foreground">From rural clinics to major hospitals, MyThuso is helping healthcare professionals deliver better, safer, and more consistent care.</p><a href="#stories" className="mt-3 inline-flex items-center gap-1 text-xs font-bold text-primary">See all stories <ArrowRight className="size-3" /></a><div className="mt-4 flex items-center gap-3 rounded-lg border border-border bg-surface p-3 shadow-sm"><img src={doctorImage} alt="Dr. Nomsa Dlamini" width={1024} height={1024} loading="lazy" className="size-14 shrink-0 rounded-full object-cover object-top" /><div><p className="text-xs leading-5">“MyThuso has transformed the way we work. It gives us quick, reliable guidance right when we need it most.”</p><p className="mt-1 text-[0.6875rem] font-bold">Dr. Nomsa Dlamini</p><p className="text-[0.625rem] text-muted-foreground">District Hospital, KZN</p></div></div></div>
            </div>
             <div id="stories" className="mt-8 grid gap-8 border-t border-border pt-7 lg:grid-cols-[0.78fr_1.22fr] lg:items-start"><div><SectionLabel>Why choose MyThuso</SectionLabel><h2 className="font-display text-3xl font-semibold leading-none">Built for today.<br />Ready for tomorrow.</h2></div><div className="grid grid-cols-2 gap-6 md:grid-cols-4">{[[ClipboardCheck,"Evidence-based AI","Grounded in trusted clinical sources","bg-accent/15 text-success"],[ShieldCheck,"Secure by design","POPIA compliant and future ready","bg-primary/10 text-primary"],[BrainCircuit,"Local context","Built for South Africa, by local experts","bg-highlight/20 text-primary"],[Puzzle,"Continuous innovation","Always learning, always improving","bg-coral/10 text-coral"]].map(([I,title,copy,tone]) => { const Icon = I as typeof ClipboardCheck; return <div key={title as string}><span className={cn("flex size-10 items-center justify-center rounded-full", tone as string)}><Icon className="size-5" strokeWidth={2.5} /></span><h3 className="mt-3 text-xs font-bold">{title as string}</h3><p className="mt-1 text-[0.6875rem] leading-4 text-muted-foreground">{copy as string}</p></div>; })}</div></div>
            <div className="relative mt-8 overflow-hidden rounded-lg bg-primary text-primary-foreground"><img src={capeTownImage} alt="Cape Town and Table Mountain" width={1536} height={512} loading="lazy" className="absolute inset-0 h-full w-full object-cover object-right opacity-60" /><div className="absolute inset-0 bg-primary/45" /><div className="relative flex min-h-36 flex-col justify-center px-7 py-7 sm:px-12"><p className="text-[0.625rem] font-bold uppercase">Let’s build a healthier tomorrow</p><h2 className="mt-2 max-w-md font-display text-2xl font-semibold leading-tight">Ready to see what’s possible<br />with MyThuso?</h2><div className="mt-4 flex flex-wrap items-center gap-4"><Button variant="secondary" size="sm" trailingIcon={<ArrowRight className="size-3.5" />}>Book a demo</Button><span className="text-xs">or contact our team</span><span className="ml-auto hidden size-12 items-center justify-center rounded-full border border-primary-foreground/70 bg-primary/20 md:flex"><CirclePlay className="size-7" /></span></div></div></div>
          </div>
        </section>
      </main>

      <footer className="border-t border-border bg-surface"><div className="mx-auto grid max-w-[1180px] gap-8 px-4 py-10 sm:grid-cols-2 sm:px-6 lg:grid-cols-[1.2fr_repeat(3,0.8fr)_1.4fr]"><div><BrandMark /><p className="mt-2 text-xs text-muted-foreground">For a healthier tomorrow.</p></div>{[["Solutions",["For Clinicians","For Health Systems","For Communities"]],["Resources",["Guidelines","Case Studies","Blogs","Help Centre"]],["About",["Our Story","Careers","Contact"]]].map(([heading,links]) => <div key={heading as string}><p className="text-xs font-bold">{heading as string}</p><div className="mt-3 grid gap-2">{(links as string[]).map((item) => <a key={item} href="#solutions" className="text-xs text-muted-foreground hover:text-primary">{item}</a>)}</div></div>)}<div><p className="text-xs font-bold">Stay updated</p><p className="mt-2 text-xs text-muted-foreground">Get the latest news and product updates.</p><div className="mt-4 flex gap-2"><Input aria-label="Email address" placeholder="Your email address" /><IconButton label="Subscribe" variant="accent"><ArrowRight className="size-4" /></IconButton></div></div></div><div className="border-t border-border"><div className="mx-auto flex max-w-[1180px] flex-wrap items-center justify-between gap-4 px-4 py-5 text-[0.6875rem] text-muted-foreground sm:px-6"><span>© 2026 MyThuso. All rights reserved.</span><div className="flex gap-5"><a href="#top">Privacy</a><a href="#top">Terms</a><Link to="/components">Design system</Link></div></div></div></footer>
    </div>
  );
}