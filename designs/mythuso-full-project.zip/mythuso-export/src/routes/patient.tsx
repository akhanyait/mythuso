import { createFileRoute, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/patient")({ component: PatientLayout });

function PatientLayout() { return <Outlet />; }