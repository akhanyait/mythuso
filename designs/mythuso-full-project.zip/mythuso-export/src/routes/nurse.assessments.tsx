import { createFileRoute } from "@tanstack/react-router";
import { NurseSpace } from "../showcase/nurse-space";

export const Route = createFileRoute("/nurse/assessments")({
  head: () => ({ meta: [{ title: "Assessments — MyThuso Nurse" }, { name: "description", content: "Complete identity, consent, observations, findings and sign-off for a patient visit." }, { property: "og:title", content: "Assessments — MyThuso Nurse" }, { property: "og:description", content: "Complete identity, consent, observations, findings and sign-off for a patient visit." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: () => <NurseSpace page="assessments" />,
});