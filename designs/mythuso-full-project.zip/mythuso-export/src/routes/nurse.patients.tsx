import { createFileRoute } from "@tanstack/react-router";
import { NurseSpace } from "../showcase/nurse-space";

export const Route = createFileRoute("/nurse/patients")({
  head: () => ({ meta: [{ title: "Patients — MyThuso Nurse" }, { name: "description", content: "Search assigned patients and review vitals and care status." }, { property: "og:title", content: "Patients — MyThuso Nurse" }, { property: "og:description", content: "Search assigned patients and review vitals and care status." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: () => <NurseSpace page="patients" />,
});
