import { createFileRoute } from "@tanstack/react-router";
import { NurseSpace } from "../showcase/nurse-space";

export const Route = createFileRoute("/nurse/earnings")({
  head: () => ({ meta: [{ title: "Earnings & Payouts — MyThuso Nurse" }, { name: "description", content: "Review visit earnings, weekly payout status and available shift hours." }, { property: "og:title", content: "Earnings & Payouts — MyThuso Nurse" }, { property: "og:description", content: "Review visit earnings, weekly payout status and available shift hours." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: () => <NurseSpace page="earnings" />,
});