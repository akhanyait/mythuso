import { createFileRoute } from "@tanstack/react-router";
import { PatientSpace } from "../showcase/patient-space";

export const Route = createFileRoute("/patient/")({
  head: () => ({ meta: [{ title: "My Health Space — MyThuso" }, { name: "description", content: "Appointments, results, medication and personal health trends in one secure space." }, { property: "og:title", content: "My Health Space — MyThuso" }, { property: "og:description", content: "Appointments, results, medication and personal health trends in one secure space." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: () => <PatientSpace page="dashboard" />,
});