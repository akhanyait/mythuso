import { createFileRoute } from "@tanstack/react-router";
import { NurseSpace } from "../showcase/nurse-space";

export const Route = createFileRoute("/nurse/kit")({
  head: () => ({ meta: [{ title: "Thuso Kit — MyThuso Nurse" }, { name: "description", content: "Review connected instruments, reading provenance, calibration and held work." }, { property: "og:title", content: "Thuso Kit — MyThuso Nurse" }, { property: "og:description", content: "Review connected instruments, reading provenance, calibration and held work." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: () => <NurseSpace page="kit" />,
});