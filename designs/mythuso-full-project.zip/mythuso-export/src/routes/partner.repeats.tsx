import { createFileRoute } from "@tanstack/react-router";
import { PartnerSpace } from "../showcase/partner-space";
const t = "Substitution & repeats — MyThuso Pharmacy Partner";
const d = "Pharmacy partner workspace: Substitution & repeats for prescriptions and laboratory orders.";
export const Route = createFileRoute("/partner/repeats")({ head: () => ({ meta: [{ title: t }, { name: "description", content: d }, { property: "og:title", content: t }, { property: "og:description", content: d }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }), component: () => <PartnerSpace page="repeats" /> });
