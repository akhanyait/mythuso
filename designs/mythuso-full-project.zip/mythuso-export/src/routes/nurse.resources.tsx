import { createFileRoute } from "@tanstack/react-router";
import { NurseSpace } from "../showcase/nurse-space";

export const Route = createFileRoute("/nurse/resources")({
  head: () => ({ meta: [{ title: "Clinical Resources — MyThuso Nurse" }, { name: "description", content: "Trusted guidelines, patient education and forms." }, { property: "og:title", content: "Clinical Resources — MyThuso Nurse" }, { property: "og:description", content: "Trusted guidelines, patient education and forms." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: () => <NurseSpace page="resources" />,
});
