import { createFileRoute } from "@tanstack/react-router";
import { NurseSpace } from "../showcase/nurse-space";

export const Route = createFileRoute("/nurse/map")({
  head: () => ({ meta: [{ title: "Map View — MyThuso Nurse" }, { name: "description", content: "See allocated patients, clinics and your route on the map." }, { property: "og:title", content: "Map View — MyThuso Nurse" }, { property: "og:description", content: "See allocated patients, clinics and your route on the map." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: () => <NurseSpace page="map" />,
});
