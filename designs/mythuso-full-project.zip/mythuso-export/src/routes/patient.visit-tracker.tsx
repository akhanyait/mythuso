import { createFileRoute } from "@tanstack/react-router";
import { PatientSpace } from "../showcase/patient-space";
export const Route = createFileRoute("/patient/visit-tracker")({
  head: () => ({ meta: [{ title: "Nurse visit tracker — MyThuso" }, { name: "description", content: "See how far your nurse is and verify them at the door with your QR code." }, { property: "og:title", content: "Nurse visit tracker — MyThuso" }, { property: "og:description", content: "See how far your nurse is and verify them at the door with your QR code." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: () => <PatientSpace page="visit-tracker" />,
});
