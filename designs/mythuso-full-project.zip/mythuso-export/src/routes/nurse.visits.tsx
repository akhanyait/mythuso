import { createFileRoute } from "@tanstack/react-router";
import { NurseSpace } from "../showcase/nurse-space";

export const Route = createFileRoute("/nurse/visits")({
  head: () => ({ meta: [{ title: "Log a Patient Visit — MyThuso Nurse" }, { name: "description", content: "Record vitals, care notes and follow-up for a patient visit." }, { property: "og:title", content: "Log a Patient Visit — MyThuso Nurse" }, { property: "og:description", content: "Record vitals, care notes and follow-up for a patient visit." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: () => <NurseSpace page="visits" />,
});
