import { createFileRoute } from "@tanstack/react-router";
import { PatientSpace } from "../showcase/patient-space";

export const Route = createFileRoute("/patient/consultation")({
  head: () => ({
    meta: [
      { title: "Online Consultation — MyThuso" },
      { name: "description", content: "Join a secure MyThuso video consultation with your care team." },
      { property: "og:title", content: "Online Consultation — MyThuso" },
      { property: "og:description", content: "Join a secure MyThuso video consultation with your care team." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => <PatientSpace page="consultation" />,
});