import { createFileRoute } from "@tanstack/react-router";
import { PartnerSpace } from "../showcase/partner-space";
const t = "Orders — MyThuso Pharmacy Partner";
const d = "Pharmacy partner workspace: Orders for prescriptions and laboratory orders.";
export const Route = createFileRoute("/partner/")({ head: () => ({ meta: [{ title: t }, { name: "description", content: d }, { property: "og:title", content: t }, { property: "og:description", content: d }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }), component: () => <PartnerSpace page="orders" /> });
