import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/patient/more")({
  beforeLoad: () => {
    throw redirect({ to: "/patient/wellness", replace: true });
  },
});
