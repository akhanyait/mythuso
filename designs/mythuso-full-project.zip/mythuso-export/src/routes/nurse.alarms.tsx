import { createFileRoute } from "@tanstack/react-router";
import { NurseSpace } from "../showcase/nurse-space";
export const Route = createFileRoute("/nurse/alarms")({
  head: () => ({ meta: [{ title: "Alarms & readings — MyThuso Nurse" }, { name: "description", content: "Live device alarms, triage results and response steps shared with doctors." }, { property: "og:title", content: "Alarms & readings — MyThuso Nurse" }, { property: "og:description", content: "Live device alarms, triage results and response steps shared with doctors." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: () => <NurseSpace page="alarms" />,
});
