import { createFileRoute } from "@tanstack/react-router";
import { DoctorSpace } from "../showcase/doctor-space";
export const Route = createFileRoute("/doctor/triage")({
  head: () => ({ meta: [{ title: "Live triage — MyThuso Doctor" }, { name: "description", content: "Real-time device readings, three-layer triage, alarms and interactive vitals charts." }, { property: "og:title", content: "Live triage — MyThuso Doctor" }, { property: "og:description", content: "Real-time device readings, three-layer triage, alarms and interactive vitals charts." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: () => <DoctorSpace page="triage" />,
});
