import { createFileRoute } from "@tanstack/react-router";
import { NurseLogin } from "../showcase/nurse-space";

export const Route = createFileRoute("/nurse/login")({
  head: () => ({ meta: [{ title: "Nurse Sign In — MyThuso Nurse" }, { name: "description", content: "Secure sign-in for MyThuso nurses." }, { property: "og:title", content: "Nurse Sign In — MyThuso Nurse" }, { property: "og:description", content: "Secure sign-in for MyThuso nurses." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: () => <NurseLogin />,
});
