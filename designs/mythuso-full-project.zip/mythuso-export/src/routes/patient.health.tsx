import { createFileRoute } from "@tanstack/react-router";
import { PatientSpace } from "../showcase/patient-space";

export const Route = createFileRoute("/patient/health")({
  head: () => ({
    meta: [
      { title: "My Health — MyThuso" },
      { name: "description", content: "Track vitals, results, medication, medical history and personal health goals." },
      { property: "og:title", content: "My Health — MyThuso" },
      { property: "og:description", content: "Track vitals, results, medication, medical history and personal health goals." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => <PatientSpace page="health" />,
});