import { createFileRoute } from "@tanstack/react-router";
import { NurseSpace } from "../showcase/nurse-space";

export const Route = createFileRoute("/nurse/team")({
  head: () => ({ meta: [{ title: "Team — MyThuso Nurse" }, { name: "description", content: "See who is on shift and contact colleagues." }, { property: "og:title", content: "Team — MyThuso Nurse" }, { property: "og:description", content: "See who is on shift and contact colleagues." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: () => <NurseSpace page="team" />,
});
