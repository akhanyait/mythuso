import { createFileRoute } from "@tanstack/react-router";
import { NurseSpace } from "../showcase/nurse-space";

export const Route = createFileRoute("/nurse/")({
  head: () => ({ meta: [{ title: "Nurse Dashboard — MyThuso Nurse" }, { name: "description", content: "Your clinic day at a glance: appointments, follow-ups, messages and alerts." }, { property: "og:title", content: "Nurse Dashboard — MyThuso Nurse" }, { property: "og:description", content: "Your clinic day at a glance: appointments, follow-ups, messages and alerts." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: () => <NurseSpace page="dashboard" />,
});
