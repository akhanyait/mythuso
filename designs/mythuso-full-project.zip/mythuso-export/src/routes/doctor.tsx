import { createFileRoute, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/doctor")({
  component: DoctorLayout,
});

function DoctorLayout() { return <Outlet />; }
