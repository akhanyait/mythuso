import { createFileRoute } from "@tanstack/react-router";
import { NurseSpace } from "../showcase/nurse-space";

export const Route = createFileRoute("/nurse/training")({
  head: () => ({ meta: [{ title: "Training & Development — MyThuso Nurse" }, { name: "description", content: "Courses and CPD progress for nurses." }, { property: "og:title", content: "Training & Development — MyThuso Nurse" }, { property: "og:description", content: "Courses and CPD progress for nurses." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: () => <NurseSpace page="training" />,
});
