import { createFileRoute } from "@tanstack/react-router";
import { NurseSpace } from "../showcase/nurse-space";

export const Route = createFileRoute("/nurse/appointments")({
  head: () => ({ meta: [{ title: "Appointments — MyThuso Nurse" }, { name: "description", content: "Manage clinic flow and check patients in." }, { property: "og:title", content: "Appointments — MyThuso Nurse" }, { property: "og:description", content: "Manage clinic flow and check patients in." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: () => <NurseSpace page="appointments" />,
});
