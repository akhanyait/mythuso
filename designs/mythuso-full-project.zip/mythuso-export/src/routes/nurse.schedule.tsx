import { createFileRoute } from "@tanstack/react-router";
import { NurseSpace } from "../showcase/nurse-space";

export const Route = createFileRoute("/nurse/schedule")({
  head: () => ({ meta: [{ title: "Schedule — MyThuso Nurse" }, { name: "description", content: "Plan today’s visits, travel, availability and follow-up care." }, { property: "og:title", content: "Schedule — MyThuso Nurse" }, { property: "og:description", content: "Plan today’s visits, travel, availability and follow-up care." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: () => <NurseSpace page="schedule" />,
});