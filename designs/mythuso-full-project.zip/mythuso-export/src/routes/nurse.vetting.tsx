import { createFileRoute } from "@tanstack/react-router";
import { NurseSpace } from "../showcase/nurse-space";

export const Route = createFileRoute("/nurse/vetting")({
  head: () => ({ meta: [{ title: "Vetting — MyThuso Nurse" }, { name: "description", content: "Review nursing credentials and the checks required before home visits." }, { property: "og:title", content: "Vetting — MyThuso Nurse" }, { property: "og:description", content: "Review nursing credentials and the checks required before home visits." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: () => <NurseSpace page="vetting" />,
});