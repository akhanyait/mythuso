import { createFileRoute } from "@tanstack/react-router";
import { NurseSpace } from "../showcase/nurse-space";

export const Route = createFileRoute("/nurse/reports")({
  head: () => ({ meta: [{ title: "Reports — MyThuso Nurse" }, { name: "description", content: "Clinic activity and care quality reports." }, { property: "og:title", content: "Reports — MyThuso Nurse" }, { property: "og:description", content: "Clinic activity and care quality reports." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: () => <NurseSpace page="reports" />,
});
