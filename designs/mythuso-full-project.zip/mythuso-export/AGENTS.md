# Project Architecture

- Consumer-facing design-system code lives in `src/components`, `src/lib`, and `src/styles`, with `src/index.ts` as the only public barrel, so file-copy attach remains self-contained.
- The permanent showcase lives in `src/showcase` and route files, never in the consumer barrel, so documentation UI cannot leak into attached projects.
- `src/styles/theme.css` is the canonical theme entry and owns all visual tokens, so consumers receive one complete import.
- GilbertOne motion is encapsulated in the exported `GilbertOne` component, so every consumer gets consistent blinking, gaze, and reduced-motion behavior.
- Patient screens share the preview-only shell; tools use grouped Care, Health, Wellness, Devices, Family & Safety, and Account navigation, with private owner-scoped profiles.
- Connected IoT status is a simulated `/patient/devices` demo until integrations exist.
- The My Health workspace uses one `/patient/health` route with in-page tabs, so related clinical views retain context without duplicating the patient shell.
- Branded patient destinations use the exported MyThuso icon family, while Lucide is reserved for universal utility controls, so the product stays distinctive without sacrificing familiarity.
- Brand identity uses the official assets only: `src/assets/logos/mythuso-logo.png` (from mythuso.co.za, never the retired caret wordmark) and `src/assets/logos/gilbert-one-logo.png` for identity spots; the animated `GilbertOne` component stays character-only, never a logo.
- The official GilbertOne logo asset remains separate from the animated GilbertOne assistant component, so identity usage and in-product character behavior cannot be confused.
- Online consultations use `/patient/consultation` inside the shared patient shell, with real-time media represented as an interactive prototype until communication infrastructure is connected.
- GilbertOne uses one patient-passport conversation persisted by authenticated patient identity, so health-chat history is private and follows the patient across devices.
- Nurse operations link the preview queue, plan, and Mapbox-ready map; a schematic fallback works before a public token is added.
- Nurse field work uses distinct preview routes for field workflows within one shell.
- Doctor work uses linked preview routes centred on accountable review, credential gates, and patient context.
