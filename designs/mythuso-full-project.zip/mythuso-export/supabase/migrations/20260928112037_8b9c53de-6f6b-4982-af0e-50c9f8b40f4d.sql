CREATE TABLE public.gilbert_chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  ai_message_id text NOT NULL,
  role text NOT NULL CHECK (role IN ('user', 'assistant')),
  parts jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, ai_message_id)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.gilbert_chat_messages TO authenticated;
GRANT ALL ON public.gilbert_chat_messages TO service_role;

ALTER TABLE public.gilbert_chat_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Patients can view their GilbertOne messages"
ON public.gilbert_chat_messages FOR SELECT TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Patients can add GilbertOne messages"
ON public.gilbert_chat_messages FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Patients can update GilbertOne messages"
ON public.gilbert_chat_messages FOR UPDATE TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Patients can remove GilbertOne messages"
ON public.gilbert_chat_messages FOR DELETE TO authenticated
USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.set_gilbert_chat_message_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER set_gilbert_chat_message_updated_at
BEFORE UPDATE ON public.gilbert_chat_messages
FOR EACH ROW EXECUTE FUNCTION public.set_gilbert_chat_message_updated_at();